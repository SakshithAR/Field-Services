// lib/src/odoo/network_connectivity.dart

import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';

// IMPORTANT: import the canonical interface/enum
import 'package:field_service/src/odoo/odoo_repository/lib/src/network_connection_state.dart';

class NetworkConnectivity implements NetConnState {
  final Connectivity _connectivity = Connectivity();
  final InternetConnection _internet = InternetConnection();

  final _controller = StreamController<netConnState>.broadcast();
  late final StreamSubscription _connSub;
  late final StreamSubscription _internetSub;

  NetworkConnectivity() {
    // seed immediately
    _emitCurrent();

    // interface changes (wifi/mobile/ethernet/vpn/other/none)
    _connSub = _connectivity.onConnectivityChanged.listen((_) => _emitCurrent());

    // true internet reachability changes
    _internetSub = _internet.onStatusChange.listen((status) {
      _controller.add(
        status == InternetStatus.connected
            ? netConnState.online
            : netConnState.offline,
      );
    });
  }

  Future<void> _emitCurrent() async {
    _controller.add(await checkNetConn());
  }

  @override
  Future<netConnState> checkNetConn() async {
    final result = await _connectivity.checkConnectivity();
    final hasInterface = result != ConnectivityResult.none;
    final hasInternet = await _internet.hasInternetAccess;
    return (hasInterface && hasInternet)
        ? netConnState.online
        : netConnState.offline;
  }

  @override
  Stream<netConnState> get onNetConnChanged => _controller.stream;

  void dispose() {
    _connSub.cancel();
    _internetSub.cancel();
    _controller.close();
  }
}
