import 'package:odoo_rpc/odoo_rpc.dart';
import 'package:odoo_rpc/odoo_rpc.dart';

/// Adds missing helpers for older/newer odoo_rpc versions.
extension OdooClientSessionExt on OdooClient {
  /// Equivalent to Odoo web endpoint: /web/session/get_session_info
  Future<Map<String, dynamic>> getSessionInfo() async {
    final res = await callRPC('/web/session/get_session_info', 'call', {});
    return Map<String, dynamic>.from(res as Map);
  }
}

