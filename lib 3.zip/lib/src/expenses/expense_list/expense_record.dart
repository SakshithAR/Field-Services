import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart' show debugPrint;

import '../../odoo/odoo_repository/lib/odoo_repository.dart';

/// Record class for the `hr.expense` model.
class ExpenseRecord extends Equatable implements OdooRecord {
  @override
  final int id;

  final String name;                // description
  final DateTime? date;             // date only
  final String state;               // draft/reported/approved/done/refused (varies)

  final EmployeeRecord employee;
  final ProductRecord product;

  final double quantity;
  final double unitAmount;
  final double totalAmount;

  final String paymentMode;         // own_account / company_account (common)
  final CompanyRecord company;
  final CurrencyRecord currency;

  // Accounting / Project
  final AccountRecord? account;
  final AnalyticAccountRecord? analyticAccount;
  final List<AnalyticTagRecord> analyticTags;
  final List<TaxRecord> taxes;

  // Sheet/report (optional)
  final ExpenseSheetRecord? sheet;

  // Attachments (mail.thread)
  final int attachmentCount;
  final AttachmentRecord? mainAttachment;

  ExpenseRecord({
    required this.id,
    required this.name,
    required this.date,
    required this.state,
    required this.employee,
    required this.product,
    required this.quantity,
    required this.unitAmount,
    required this.totalAmount,
    required this.paymentMode,
    required this.company,
    required this.currency,
    required this.account,
    required this.analyticAccount,
    required this.analyticTags,
    required this.taxes,
    required this.sheet,
    required this.attachmentCount,
    required this.mainAttachment,
  });

  @override
  List<Object?> get props => [
    id,
    name,
    date,
    state,
    employee,
    product,
    quantity,
    unitAmount,
    totalAmount,
    paymentMode,
    company,
    currency,
    account,
    analyticAccount,
    analyticTags,
    taxes,
    sheet,
    attachmentCount,
    mainAttachment,
  ];

  ExpenseRecord copyWith({
    int? id,
    String? name,
    DateTime? date,
    String? state,
    EmployeeRecord? employee,
    ProductRecord? product,
    double? quantity,
    double? unitAmount,
    double? totalAmount,
    String? paymentMode,
    CompanyRecord? company,
    CurrencyRecord? currency,
    AccountRecord? account,
    AnalyticAccountRecord? analyticAccount,
    List<AnalyticTagRecord>? analyticTags,
    List<TaxRecord>? taxes,
    ExpenseSheetRecord? sheet,
    int? attachmentCount,
    AttachmentRecord? mainAttachment,
  }) {
    return ExpenseRecord(
      id: id ?? this.id,
      name: name ?? this.name,
      date: date ?? this.date,
      state: state ?? this.state,
      employee: employee ?? this.employee,
      product: product ?? this.product,
      quantity: quantity ?? this.quantity,
      unitAmount: unitAmount ?? this.unitAmount,
      totalAmount: totalAmount ?? this.totalAmount,
      paymentMode: paymentMode ?? this.paymentMode,
      company: company ?? this.company,
      currency: currency ?? this.currency,
      account: account ?? this.account,
      analyticAccount: analyticAccount ?? this.analyticAccount,
      analyticTags: analyticTags ?? this.analyticTags,
      taxes: taxes ?? this.taxes,
      sheet: sheet ?? this.sheet,
      attachmentCount: attachmentCount ?? this.attachmentCount,
      mainAttachment: mainAttachment ?? this.mainAttachment,
    );
  }

  @override
  Map<String, dynamic> toVals() {
    return {
      'id': id,
      'name': name,
      'date': _dateToOdooDate(date),
      'state': state,
      'employee_id': employee.toVals(),
      'product_id': product.toVals(),
      'quantity': quantity,
      'unit_amount': unitAmount,
      'total_amount': totalAmount,
      'payment_mode': paymentMode,
      'company_id': company.toVals(),
      'currency_id': currency.toVals(),
      'account_id': account?.toVals(),
      'analytic_account_id': analyticAccount?.toVals(),
      'analytic_tag_ids': analyticTags.map((e) => e.toVals()).toList(),
      'tax_ids': taxes.map((e) => e.toVals()).toList(),
      'sheet_id': sheet?.toVals(),
      'message_attachment_count': attachmentCount,
      'message_main_attachment_id': mainAttachment?.toVals(),
    };
  }

  @override
  Map<String, dynamic> toJson() => toVals();

  static ExpenseRecord fromJson(Map<dynamic, dynamic> json) {
    final qty = _parseDouble(json['quantity'], fallback: 1.0);
    final unit = _parseDouble(json['unit_amount'], fallback: 0.0);

    // Odoo often provides total_amount; if missing compute.
    final total = _parseDouble(json['total_amount'], fallback: qty * unit);

    final parsedDate = _parseDate(json['date']);
    if (json['date'] != null) {
      debugPrint('Expense date raw=${json['date']} -> $parsedDate');
    }

    return ExpenseRecord(
      id: json['id'] as int? ?? 0,
      name: _safeString(json['name']),
      date: parsedDate,
      state: _safeString(json['state']),
      employee: EmployeeRecord.parse(json['employee_id']),
      product: ProductRecord.parse(json['product_id']),
      quantity: qty,
      unitAmount: unit,
      totalAmount: total,
      paymentMode: _safeString(json['payment_mode']),
      company: CompanyRecord.parse(json['company_id']),
      currency: CurrencyRecord.parse(json['currency_id']),
      account: AccountRecord.parseNullable(json['account_id']),
      analyticAccount: AnalyticAccountRecord.parseNullable(json['analytic_account_id']),
      analyticTags: AnalyticTagRecord.parseList(json['analytic_tag_ids']),
      taxes: TaxRecord.parseList(json['tax_ids']),
      sheet: ExpenseSheetRecord.parseNullable(json['sheet_id']),
      attachmentCount: _parseInt(json['message_attachment_count'], fallback: 0),
      mainAttachment: AttachmentRecord.parseNullable(json['message_main_attachment_id']),
    );
  }

  // ----------------- helpers -----------------

  static String _safeString(dynamic value) {
    if (value == null || value == false) return '';
    if (value is String) return value;
    return value.toString();
  }

  static int _parseInt(dynamic value, {int fallback = 0}) {
    if (value == null || value == false) return fallback;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value) ?? fallback;
    return fallback;
  }

  static double _parseDouble(dynamic value, {double fallback = 0.0}) {
    if (value == null || value == false) return fallback;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value) ?? fallback;
    return fallback;
  }

  /// Odoo Date field usually comes as 'YYYY-MM-DD'
  static DateTime? _parseDate(dynamic value) {
    if (value == null || value == false) return null;
    if (value is DateTime) return value;

    if (value is String && value.trim().isNotEmpty) {
      final s = value.trim();
      // 'YYYY-MM-DD' -> DateTime local
      final dt = DateTime.tryParse('${s}T00:00:00');
      return dt;
    }
    return null;
  }

  static String? _dateToOdooDate(DateTime? value) {
    if (value == null) return null;
    final y = value.year.toString().padLeft(4, '0');
    final m = value.month.toString().padLeft(2, '0');
    final d = value.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }
}

/* --------------------------- Nested Records --------------------------- */

class EmployeeRecord extends Equatable {
  final int id;
  final String name;
  final String workEmail;
  final String workPhone;
  final String mobilePhone;
  final int departmentId;
  final String departmentName;

  const EmployeeRecord({
    required this.id,
    required this.name,
    this.workEmail = '',
    this.workPhone = '',
    this.mobilePhone = '',
    this.departmentId = 0,
    this.departmentName = '',
  });

  @override
  List<Object?> get props => [id, name, workEmail, workPhone, mobilePhone, departmentId, departmentName];

  Map<String, dynamic> toVals() => {
    'id': id,
    'name': name,
    'work_email': workEmail,
    'work_phone': workPhone,
    'mobile_phone': mobilePhone,
    'department_id': departmentId == 0 ? null : departmentId,
  };

  static EmployeeRecord parse(dynamic raw) {
    if (raw == null || raw == false) {
      return const EmployeeRecord(id: 0, name: '');
    }

    if (raw is Map) {
      final dept = raw['department_id'];
      int deptId = 0;
      String deptName = '';
      if (dept is Map) {
        deptId = dept['id'] as int? ?? 0;
        deptName = _s(dept['name']);
      } else if (dept is List && dept.length >= 2) {
        deptId = int.tryParse(dept[0].toString()) ?? 0;
        deptName = _s(dept[1]);
      }

      return EmployeeRecord(
        id: raw['id'] as int? ?? 0,
        name: _s(raw['name']),
        workEmail: _s(raw['work_email']),
        workPhone: _s(raw['work_phone']),
        mobilePhone: _s(raw['mobile_phone']),
        departmentId: deptId,
        departmentName: deptName,
      );
    }

    if (raw is List && raw.length >= 2) {
      return EmployeeRecord(
        id: int.tryParse(raw[0].toString()) ?? 0,
        name: _s(raw[1]),
      );
    }

    return const EmployeeRecord(id: 0, name: '');
  }

  static String _s(dynamic v) => (v == null || v == false) ? '' : v.toString();
}

class ProductRecord extends Equatable {
  final int id;
  final String name;

  const ProductRecord({required this.id, required this.name});

  @override
  List<Object?> get props => [id, name];

  Map<String, dynamic> toVals() => {'id': id, 'name': name};

  static ProductRecord parse(dynamic raw) {
    if (raw == null || raw == false) return const ProductRecord(id: 0, name: '');
    if (raw is Map) {
      return ProductRecord(
        id: raw['id'] as int? ?? 0,
        name: (raw['display_name'] ?? raw['name'] ?? '').toString(),
      );
    }
    if (raw is List && raw.length >= 2) {
      return ProductRecord(
        id: int.tryParse(raw[0].toString()) ?? 0,
        name: raw[1].toString(),
      );
    }
    return const ProductRecord(id: 0, name: '');
  }
}

class CompanyRecord extends Equatable {
  final int id;
  final String name;
  const CompanyRecord({required this.id, required this.name});

  @override
  List<Object?> get props => [id, name];

  Map<String, dynamic> toVals() => {'id': id, 'name': name};

  static CompanyRecord parse(dynamic raw) {
    if (raw == null || raw == false) return const CompanyRecord(id: 0, name: '');
    if (raw is Map) return CompanyRecord(id: raw['id'] as int? ?? 0, name: (raw['name'] ?? '').toString());
    if (raw is List && raw.length >= 2) {
      return CompanyRecord(id: int.tryParse(raw[0].toString()) ?? 0, name: raw[1].toString());
    }
    return const CompanyRecord(id: 0, name: '');
  }
}

class CurrencyRecord extends Equatable {
  final int id;
  final String name;
  final String symbol;

  const CurrencyRecord({required this.id, required this.name, this.symbol = ''});

  @override
  List<Object?> get props => [id, name, symbol];

  Map<String, dynamic> toVals() => {'id': id, 'name': name, 'symbol': symbol};

  static CurrencyRecord parse(dynamic raw) {
    if (raw == null || raw == false) return const CurrencyRecord(id: 0, name: '');
    if (raw is Map) {
      return CurrencyRecord(
        id: raw['id'] as int? ?? 0,
        name: (raw['name'] ?? '').toString(),
        symbol: (raw['symbol'] ?? '').toString(),
      );
    }
    if (raw is List && raw.length >= 2) {
      return CurrencyRecord(id: int.tryParse(raw[0].toString()) ?? 0, name: raw[1].toString());
    }
    return const CurrencyRecord(id: 0, name: '');
  }
}

class AccountRecord extends Equatable {
  final int id;
  final String name;
  const AccountRecord({required this.id, required this.name});

  @override
  List<Object?> get props => [id, name];

  Map<String, dynamic> toVals() => {'id': id, 'name': name};

  static AccountRecord? parseNullable(dynamic raw) {
    if (raw == null || raw == false) return null;
    if (raw is Map) return AccountRecord(id: raw['id'] as int? ?? 0, name: (raw['name'] ?? '').toString());
    if (raw is List && raw.length >= 2) {
      return AccountRecord(id: int.tryParse(raw[0].toString()) ?? 0, name: raw[1].toString());
    }
    return null;
  }
}

class AnalyticAccountRecord extends Equatable {
  final int id;
  final String name;
  const AnalyticAccountRecord({required this.id, required this.name});

  @override
  List<Object?> get props => [id, name];

  Map<String, dynamic> toVals() => {'id': id, 'name': name};

  static AnalyticAccountRecord? parseNullable(dynamic raw) {
    if (raw == null || raw == false) return null;
    if (raw is Map) return AnalyticAccountRecord(id: raw['id'] as int? ?? 0, name: (raw['name'] ?? '').toString());
    if (raw is List && raw.length >= 2) {
      return AnalyticAccountRecord(id: int.tryParse(raw[0].toString()) ?? 0, name: raw[1].toString());
    }
    return null;
  }
}

class AnalyticTagRecord extends Equatable {
  final int id;
  final String name;
  const AnalyticTagRecord({required this.id, required this.name});

  @override
  List<Object?> get props => [id, name];

  Map<String, dynamic> toVals() => {'id': id, 'name': name};

  static List<AnalyticTagRecord> parseList(dynamic raw) {
    if (raw == null || raw == false) return <AnalyticTagRecord>[];
    if (raw is List) {
      return raw.map((e) {
        if (e is Map) return AnalyticTagRecord(id: e['id'] as int? ?? 0, name: (e['name'] ?? '').toString());
        if (e is List && e.length >= 2) {
          return AnalyticTagRecord(id: int.tryParse(e[0].toString()) ?? 0, name: e[1].toString());
        }
        // if list of ids
        if (e is int) return AnalyticTagRecord(id: e, name: '');
        return const AnalyticTagRecord(id: 0, name: '');
      }).where((t) => t.id != 0).toList();
    }
    return <AnalyticTagRecord>[];
  }
}

class TaxRecord extends Equatable {
  final int id;
  final String name;
  const TaxRecord({required this.id, required this.name});

  @override
  List<Object?> get props => [id, name];

  Map<String, dynamic> toVals() => {'id': id, 'name': name};

  static List<TaxRecord> parseList(dynamic raw) {
    if (raw == null || raw == false) return <TaxRecord>[];
    if (raw is List) {
      return raw.map((e) {
        if (e is Map) return TaxRecord(id: e['id'] as int? ?? 0, name: (e['name'] ?? '').toString());
        if (e is List && e.length >= 2) {
          return TaxRecord(id: int.tryParse(e[0].toString()) ?? 0, name: e[1].toString());
        }
        if (e is int) return TaxRecord(id: e, name: '');
        return const TaxRecord(id: 0, name: '');
      }).where((t) => t.id != 0).toList();
    }
    return <TaxRecord>[];
  }
}

class ExpenseSheetRecord extends Equatable {
  final int id;
  final String name;
  final String state;

  const ExpenseSheetRecord({required this.id, required this.name, required this.state});

  @override
  List<Object?> get props => [id, name, state];

  Map<String, dynamic> toVals() => {'id': id, 'name': name, 'state': state};

  static ExpenseSheetRecord? parseNullable(dynamic raw) {
    if (raw == null || raw == false) return null;
    if (raw is Map) {
      return ExpenseSheetRecord(
        id: raw['id'] as int? ?? 0,
        name: (raw['name'] ?? '').toString(),
        state: (raw['state'] ?? '').toString(),
      );
    }
    if (raw is List && raw.length >= 2) {
      return ExpenseSheetRecord(
        id: int.tryParse(raw[0].toString()) ?? 0,
        name: raw[1].toString(),
        state: '',
      );
    }
    return null;
  }
}

class AttachmentRecord extends Equatable {
  final int id;
  final String name;
  final String mimetype;

  const AttachmentRecord({required this.id, required this.name, this.mimetype = ''});

  @override
  List<Object?> get props => [id, name, mimetype];

  Map<String, dynamic> toVals() => {'id': id, 'name': name, 'mimetype': mimetype};

  static AttachmentRecord? parseNullable(dynamic raw) {
    if (raw == null || raw == false) return null;
    if (raw is Map) {
      return AttachmentRecord(
        id: raw['id'] as int? ?? 0,
        name: (raw['name'] ?? '').toString(),
        mimetype: (raw['mimetype'] ?? '').toString(),
      );
    }
    if (raw is List && raw.length >= 2) {
      return AttachmentRecord(
        id: int.tryParse(raw[0].toString()) ?? 0,
        name: raw[1].toString(),
      );
    }
    return null;
  }
}
