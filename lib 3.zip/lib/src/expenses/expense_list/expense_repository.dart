import 'package:flutter/foundation.dart' show debugPrint;

import '../../odoo/odoo_repository/lib/odoo_repository.dart';
import 'expense_record.dart';

class ExpenseRepository extends OdooRepository<ExpenseRecord> {
  @override
  final String modelName = 'hr.expense';

  @override
  int limit = 200;

  @override
  String order = 'date desc, id desc';

  @override
  Map<String, dynamic> specification = {
    'id': {},
    'name': {},
    'date': {},
    'state': {},
    'payment_mode': {},
    'quantity': {},
    'tax_amount': {},
    'total_amount': {},

    'employee_id': {
      'fields': {
        'id': {},
        'name': {},
        'department_id': {
          'fields': {'id': {}, 'name': {}}
        },
      }
    },

    'product_id': {
      'fields': {'id': {}, 'name': {}, 'display_name': {}}
    },

    'company_id': {
      'fields': {'id': {}, 'name': {}}
    },

    'currency_id': {
      'fields': {'id': {}, 'name': {}, 'symbol': {}}
    },

    // attachments counters (mail.thread)
    'message_attachment_count': {},
  };

  ExpenseRepository(super.env);

  @override
  ExpenseRecord createRecordFromJson(Map<String, dynamic> json) {
    return ExpenseRecord.fromJson(json);
  }

  /// ✅ Pagination using Odoo `web_search_read` + `specification`
  /// pageKey: 1,2,3...
  Future<List<ExpenseRecord>> fetchExpensesPageWithSpecification({
    required int pageKey,          // ✅ 0-based page index
    int pageSize = 20,
    String search = '',
    String? state,
    String? paymentMode,
    String? orderOverride,
  }) async {
    final safePageKey = pageKey < 0 ? 0 : pageKey;
    final offset = safePageKey * pageSize;   // ✅ FIXED

    final List<dynamic> d = [];

    if (search.trim().isNotEmpty) {
      d.add(['name', 'ilike', search.trim()]);
    }
    if (state != null && state.isNotEmpty) {
      d.add(['state', '=', state]);
    }
    if (paymentMode != null && paymentMode.isNotEmpty) {
      d.add(['payment_mode', '=', paymentMode]);
    }

    final domainToUse = d.isEmpty ? [[1, '=', 1]] : d;

    final params = {
      'model': modelName,
      'method': 'web_search_read',
      'args': [],
      'kwargs': {
        'context': {
          'bin_size': true,
          'lang': env.orpc.sessionId?.userLang ?? 'en_US',
        },
        'domain': domainToUse,
        'specification': specification.isEmpty ? OdooRecord.oFields : specification,
        'offset': offset < 0 ? 0 : offset,
        'limit': pageSize < 1 ? 20 : pageSize,                       // ✅ never negative now
        'order': orderOverride ?? order,
      },
    };

    debugPrint('📄 Expense web_search_read pageKey=$pageKey offset=$offset');

    final resp = await env.orpc.callKw(params);

    if (resp is! Map) return <ExpenseRecord>[];

    remoteRecordsCount = (resp['length'] as int?) ?? remoteRecordsCount;

    final recsRaw = resp['records'];
    if (recsRaw is! List) return <ExpenseRecord>[];

    return recsRaw
        .whereType<Map>()
        .map((m) => createRecordFromJson(Map<String, dynamic>.from(m)))
        .toList();
  }
}
