import 'package:flutter/material.dart';

class CreateExpensePage extends StatefulWidget {
  const CreateExpensePage({super.key});

  @override
  State<CreateExpensePage> createState() => _CreateExpensePageState();
}

class _CreateExpensePageState extends State<CreateExpensePage> {
  final _formKey = GlobalKey<FormState>();

  // Controllers
  final _merchantCtl = TextEditingController(text: "Uber");
  final _descriptionCtl = TextEditingController(text: "Airport pickup");
  final _amountCtl = TextEditingController(text: "420");
  final _referenceCtl = TextEditingController(text: "TRIP-DEC");
  final _notesCtl = TextEditingController();

  // Basic fields
  DateTime _date = DateTime(2025, 12, 14);
  String _currency = "INR (₹)";
  String _category = "Travel";
  String _paidBy = "Employee (Reimbursable)";
  String _tax = "No Tax";

  // Accounting / Project (optional)
  bool _showAccounting = true;
  String _company = "My Company";
  String _employee = "Abdul Hakeem";
  String _department = "Sales";
  String _project = "Client Visit - Hyderabad";
  String _analyticAccount = "Sales - South";
  final Set<String> _analyticTags = {"Client", "Travel"};

  // Attachments (static UI; we add dummy items)
  final List<_Attachment> _attachments = [
    _Attachment(name: "receipt_001.jpg", kind: "Image"),
  ];

  // Static pick-lists
  final _currencies = const ["INR (₹)", "USD (\$)", "AED (د.إ)"];
  final _categories = const ["Travel", "Meals", "Supplies", "Utilities", "Mileage", "Other"];
  final _paidByOptions = const ["Employee (Reimbursable)", "Company Paid"];
  final _taxes = const ["No Tax", "GST 5%", "GST 12%", "GST 18%"];

  final _companies = const ["My Company", "My Company - Branch 2"];
  final _employees = const ["Abdul Hakeem", "Ravi Kumar", "Anjali S"];
  final _departments = const ["Sales", "Operations", "Finance", "HR"];
  final _projects = const ["Client Visit - Hyderabad", "Office Setup", "Marketing Event"];
  final _analyticAccounts = const ["Sales - South", "Sales - North", "Operations - Fleet"];
  final _allTags = const ["Client", "Internal", "Travel", "Meals", "Emergency", "Policy Exception"];

  @override
  void dispose() {
    _merchantCtl.dispose();
    _descriptionCtl.dispose();
    _amountCtl.dispose();
    _referenceCtl.dispose();
    _notesCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final amount = double.tryParse(_amountCtl.text.trim()) ?? 0;

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: const Text("New Expense"),
        actions: [
          IconButton(
            tooltip: "Help",
            onPressed: () {},
            icon: const Icon(Icons.help_outline_rounded),
          ),
        ],
      ),
      bottomNavigationBar: _BottomActionBar(
        primaryLabel: "Submit",
        secondaryLabel: "Save Draft",
        onPrimary: _onSubmit,
        onSecondary: _onSaveDraft,
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
            children: [
              // Summary top card
              _SummaryCard(
                amountLabel: "${_currencySymbol(_currency)}${amount.toStringAsFixed(0)}",
                subtitle: "Receipts attached: ${_attachments.length}",
                hint: _attachments.isEmpty ? "Add a bill to avoid rejection." : null,
              ),
              const SizedBox(height: 12),

              // Attachments section
              _SectionTitle(title: "Bill / Receipt"),
              const SizedBox(height: 8),
              _CardShell(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _AttachmentStrip(
                      attachments: _attachments,
                      onRemove: (i) => setState(() => _attachments.removeAt(i)),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => _addAttachment("Scan", "Image"),
                            icon: const Icon(Icons.document_scanner_rounded),
                            label: const Text("Scan"),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => _addAttachment("Gallery", "Image"),
                            icon: const Icon(Icons.photo_library_outlined),
                            label: const Text("Gallery"),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => _addAttachment("File", "PDF"),
                            icon: const Icon(Icons.attach_file_rounded),
                            label: const Text("File"),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Tip: Add multi-page receipts (images/PDF).",
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Basic details
              _SectionTitle(title: "Expense Details"),
              const SizedBox(height: 8),
              _CardShell(
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: _DateField(
                            label: "Date",
                            value: _formatDate(_date),
                            onTap: _pickDate,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _DropField<String>(
                            label: "Category",
                            value: _category,
                            items: _categories,
                            onChanged: (v) => setState(() => _category = v),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _merchantCtl,
                      decoration: const InputDecoration(
                        labelText: "Merchant / Vendor",
                        hintText: "e.g., Uber, Amazon, Hotel…",
                        prefixIcon: Icon(Icons.storefront_rounded),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _descriptionCtl,
                      maxLines: 2,
                      decoration: const InputDecoration(
                        labelText: "Description",
                        hintText: "Purpose / notes for the expense",
                        prefixIcon: Icon(Icons.notes_rounded),
                      ),
                      validator: (v) =>
                      (v == null || v.trim().isEmpty) ? "Description is required" : null,
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: _amountCtl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: "Amount",
                              prefixIcon: Icon(Icons.payments_rounded),
                            ),
                            validator: (v) {
                              final n = double.tryParse((v ?? "").trim());
                              if (n == null || n <= 0) return "Enter a valid amount";
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _DropField<String>(
                            label: "Currency",
                            value: _currency,
                            items: _currencies,
                            onChanged: (v) => setState(() => _currency = v),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _DropField<String>(
                            label: "Paid By",
                            value: _paidBy,
                            items: _paidByOptions,
                            onChanged: (v) => setState(() => _paidBy = v),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _DropField<String>(
                            label: "Taxes",
                            value: _tax,
                            items: _taxes,
                            onChanged: (v) => setState(() => _tax = v),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Accounting / Project (optional)
              _SectionTitle(
                title: "Accounting & Project",
                trailing: Switch.adaptive(
                  value: _showAccounting,
                  onChanged: (v) => setState(() => _showAccounting = v),
                ),
              ),
              const SizedBox(height: 8),
              AnimatedCrossFade(
                firstChild: _CardShell(
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: _DropField<String>(
                              label: "Company",
                              value: _company,
                              items: _companies,
                              onChanged: (v) => setState(() => _company = v),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _DropField<String>(
                              label: "Employee",
                              value: _employee,
                              items: _employees,
                              onChanged: (v) => setState(() => _employee = v),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: _DropField<String>(
                              label: "Department",
                              value: _department,
                              items: _departments,
                              onChanged: (v) => setState(() => _department = v),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _DropField<String>(
                              label: "Project",
                              value: _project,
                              items: _projects,
                              onChanged: (v) => setState(() => _project = v),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      _DropField<String>(
                        label: "Analytic Account",
                        value: _analyticAccount,
                        items: _analyticAccounts,
                        onChanged: (v) => setState(() => _analyticAccount = v),
                      ),
                      const SizedBox(height: 12),
                      _TagMultiSelect(
                        label: "Analytic Tags",
                        tags: _allTags,
                        selected: _analyticTags,
                        onToggle: (tag) {
                          setState(() {
                            if (_analyticTags.contains(tag)) {
                              _analyticTags.remove(tag);
                            } else {
                              _analyticTags.add(tag);
                            }
                          });
                        },
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _referenceCtl,
                        decoration: const InputDecoration(
                          labelText: "Reference",
                          hintText: "Optional internal reference",
                          prefixIcon: Icon(Icons.tag_rounded),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _notesCtl,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          labelText: "Additional Notes",
                          hintText: "Optional notes for approver/accounting",
                          prefixIcon: Icon(Icons.chat_bubble_outline_rounded),
                        ),
                      ),
                    ],
                  ),
                ),
                secondChild: _CardShell(
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline_rounded),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          "Accounting & project fields are turned off. Enable the switch to add project/analytic details.",
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                crossFadeState:
                _showAccounting ? CrossFadeState.showFirst : CrossFadeState.showSecond,
                duration: const Duration(milliseconds: 220),
              ),

              const SizedBox(height: 16),

              // Simple policy note
              _CardShell(
                child: Row(
                  children: [
                    const Icon(Icons.policy_outlined),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        "Make sure the description and receipt are clear. Missing bills often lead to rejection.",
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (picked != null) setState(() => _date = picked);
  }

  void _addAttachment(String source, String kind) {
    setState(() {
      final id = (_attachments.length + 1).toString().padLeft(3, "0");
      _attachments.add(_Attachment(name: "receipt_$id.${kind == "PDF" ? "pdf" : "jpg"}", kind: kind));
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Added $source attachment (demo)")),
    );
  }

  void _onSaveDraft() {
    // UI-only
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Saved as draft (demo)")),
    );
  }

  void _onSubmit() {
    final ok = _formKey.currentState?.validate() ?? false;
    if (!ok) return;

    // UI-only
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Submitted expense (demo)")),
    );
  }

  String _formatDate(DateTime d) {
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    return "${months[d.month - 1]} ${d.day}, ${d.year}";
  }

  String _currencySymbol(String currency) {
    if (currency.contains("₹")) return "₹";
    if (currency.contains("\$")) return "\$";
    if (currency.contains("د.إ")) return "د.إ ";
    return "";
  }
}

/* ------------------------------- UI Bits ------------------------------ */

class _SectionTitle extends StatelessWidget {
  final String title;
  final Widget? trailing;
  const _SectionTitle({required this.title, this.trailing});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
          ),
        ),
        if (trailing != null) trailing!,
      ],
    );
  }
}

class _CardShell extends StatelessWidget {
  final Widget child;
  const _CardShell({required this.child});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
        ),
        padding: const EdgeInsets.all(14),
        child: child,
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String amountLabel;
  final String subtitle;
  final String? hint;

  const _SummaryCard({
    required this.amountLabel,
    required this.subtitle,
    this.hint,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return _CardShell(
      child: Row(
        children: [
          Container(
            height: 48,
            width: 48,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: theme.colorScheme.primaryContainer,
            ),
            child: Icon(
              Icons.payments_rounded,
              color: theme.colorScheme.onPrimaryContainer,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  amountLabel,
                  style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                if (hint != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    hint!,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ]
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DateField extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onTap;

  const _DateField({
    required this.label,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: const Icon(Icons.calendar_today_rounded),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: Text(value),
      ),
    );
  }
}

class _DropField<T> extends StatelessWidget {
  final String label;
  final T value;
  final List<T> items;
  final ValueChanged<T> onChanged;

  const _DropField({
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<T>(
      value: value,
      items: items
          .map((e) => DropdownMenuItem<T>(
        value: e,
        child: Text(e.toString()),
      ))
          .toList(),
      onChanged: (v) {
        if (v == null) return;
        onChanged(v);
      },
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}

class _AttachmentStrip extends StatelessWidget {
  final List<_Attachment> attachments;
  final ValueChanged<int> onRemove;

  const _AttachmentStrip({
    required this.attachments,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (attachments.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: theme.colorScheme.surfaceContainerHighest,
        ),
        child: Row(
          children: [
            const Icon(Icons.receipt_long_rounded),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                "No receipt attached yet",
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      );
    }

    return SizedBox(
      height: 64,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: attachments.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final a = attachments[i];
          return Container(
            width: 240,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: theme.colorScheme.surfaceContainerHighest,
              border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.5)),
            ),
            child: Row(
              children: [
                Icon(a.kind == "PDF" ? Icons.picture_as_pdf_rounded : Icons.image_rounded),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        a.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        a.kind,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: "Remove",
                  onPressed: () => onRemove(i),
                  icon: const Icon(Icons.close_rounded),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _TagMultiSelect extends StatelessWidget {
  final String label;
  final List<String> tags;
  final Set<String> selected;
  final ValueChanged<String> onToggle;

  const _TagMultiSelect({
    required this.label,
    required this.tags,
    required this.selected,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: theme.textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: tags.map((t) {
            final isOn = selected.contains(t);
            return FilterChip(
              label: Text(t),
              selected: isOn,
              onSelected: (_) => onToggle(t),
              labelStyle: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w800),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
              side: BorderSide(color: theme.colorScheme.outlineVariant.withOpacity(0.7)),
            );
          }).toList(),
        ),
      ],
    );
  }
}

class _BottomActionBar extends StatelessWidget {
  final String primaryLabel;
  final String secondaryLabel;
  final VoidCallback onPrimary;
  final VoidCallback onSecondary;

  const _BottomActionBar({
    required this.primaryLabel,
    required this.secondaryLabel,
    required this.onPrimary,
    required this.onSecondary,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
        child: Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: onSecondary,
                child: Text(secondaryLabel),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FilledButton(
                onPressed: onPrimary,
                child: Text(primaryLabel),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/* ------------------------------- Data --------------------------------- */

class _Attachment {
  final String name;
  final String kind; // Image/PDF/etc
  const _Attachment({required this.name, required this.kind});
}
