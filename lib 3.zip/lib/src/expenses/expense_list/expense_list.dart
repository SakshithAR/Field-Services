import 'package:flutter/material.dart';

class ExpensesListPageStatic extends StatefulWidget {
  const ExpensesListPageStatic({super.key});

  @override
  State<ExpensesListPageStatic> createState() => _ExpensesListPageStaticState();
}

class _ExpensesListPageStaticState extends State<ExpensesListPageStatic> {
  final _searchCtl = TextEditingController();

  _ExpenseStatus _selectedStatus = _ExpenseStatus.all;

  // UI-only filter toggles (static)
  bool _onlyMissingReceipt = false;
  _PaymentMode _paymentMode = _PaymentMode.all;
  _SortBy _sortBy = _SortBy.newest;

  // Static demo data
  late final List<_ExpenseRow> _all = <_ExpenseRow>[
    _ExpenseRow(
      title: "Uber / Taxi",
      merchant: "Uber",
      category: "Travel",
      date: DateTime(2025, 12, 12),
      amount: 420,
      currency: "₹",
      status: _ExpenseStatus.pending,
      hasReceipt: true,
      paymentMode: _PaymentMode.reimbursable,
    ),
    _ExpenseRow(
      title: "Client lunch",
      merchant: "BBQ Nation",
      category: "Meals",
      date: DateTime(2025, 12, 11),
      amount: 1250,
      currency: "₹",
      status: _ExpenseStatus.approved,
      hasReceipt: true,
      paymentMode: _PaymentMode.reimbursable,
    ),
    _ExpenseRow(
      title: "Stationery",
      merchant: "Local Store",
      category: "Supplies",
      date: DateTime(2025, 12, 9),
      amount: 380,
      currency: "₹",
      status: _ExpenseStatus.draft,
      hasReceipt: false,
      paymentMode: _PaymentMode.reimbursable,
    ),
    _ExpenseRow(
      title: "Hotel stay",
      merchant: "Trident",
      category: "Travel",
      date: DateTime(2025, 12, 5),
      amount: 6800,
      currency: "₹",
      status: _ExpenseStatus.paid,
      hasReceipt: true,
      paymentMode: _PaymentMode.reimbursable,
    ),
    _ExpenseRow(
      title: "Fuel",
      merchant: "IndianOil",
      category: "Mileage",
      date: DateTime(2025, 12, 4),
      amount: 1500,
      currency: "₹",
      status: _ExpenseStatus.submitted,
      hasReceipt: true,
      paymentMode: _PaymentMode.companyPaid,
    ),
    _ExpenseRow(
      title: "Internet bill",
      merchant: "Airtel",
      category: "Utilities",
      date: DateTime(2025, 12, 2),
      amount: 999,
      currency: "₹",
      status: _ExpenseStatus.rejected,
      hasReceipt: true,
      paymentMode: _PaymentMode.reimbursable,
    ),
    _ExpenseRow(
      title: "Printer ink",
      merchant: "Amazon",
      category: "Supplies",
      date: DateTime(2025, 11, 29),
      amount: 1790,
      currency: "₹",
      status: _ExpenseStatus.posted,
      hasReceipt: true,
      paymentMode: _PaymentMode.reimbursable,
    ),
    _ExpenseRow(
      title: "Coffee with client",
      merchant: "Starbucks",
      category: "Meals",
      date: DateTime(2025, 11, 26),
      amount: 310,
      currency: "₹",
      status: _ExpenseStatus.pending,
      hasReceipt: false,
      paymentMode: _PaymentMode.reimbursable,
    ),
  ];

  @override
  void dispose() {
    _searchCtl.dispose();
    super.dispose();
  }

  List<_ExpenseRow> get _filtered {
    final q = _searchCtl.text.trim().toLowerCase();

    Iterable<_ExpenseRow> items = _all;

    // Status filter
    if (_selectedStatus != _ExpenseStatus.all) {
      items = items.where((e) => e.status == _selectedStatus);
    }

    // Missing receipt filter
    if (_onlyMissingReceipt) {
      items = items.where((e) => !e.hasReceipt);
    }

    // Payment mode filter
    if (_paymentMode != _PaymentMode.all) {
      items = items.where((e) => e.paymentMode == _paymentMode);
    }

    // Search filter
    if (q.isNotEmpty) {
      items = items.where((e) {
        return e.title.toLowerCase().contains(q) ||
            e.merchant.toLowerCase().contains(q) ||
            e.category.toLowerCase().contains(q);
      });
    }

    final list = items.toList();

    // Sort
    list.sort((a, b) {
      return switch (_sortBy) {
        _SortBy.newest => b.date.compareTo(a.date),
        _SortBy.oldest => a.date.compareTo(b.date),
        _SortBy.amountHigh => b.amount.compareTo(a.amount),
        _SortBy.amountLow => a.amount.compareTo(b.amount),
      };
    });

    return list;
  }

  int get _countForStatusDraft => _all.where((e) => e.status == _ExpenseStatus.draft).length;
  int get _countForStatusSubmitted => _all.where((e) => e.status == _ExpenseStatus.submitted).length;
  int get _countForStatusPending => _all.where((e) => e.status == _ExpenseStatus.pending).length;
  int get _countForStatusApproved => _all.where((e) => e.status == _ExpenseStatus.approved).length;
  int get _countForStatusPosted => _all.where((e) => e.status == _ExpenseStatus.posted).length;
  int get _countForStatusPaid => _all.where((e) => e.status == _ExpenseStatus.paid).length;
  int get _countForStatusRejected => _all.where((e) => e.status == _ExpenseStatus.rejected).length;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final items = _filtered;

    final total = items.fold<double>(0, (sum, e) => sum + e.amount);
    final currency = items.isNotEmpty ? items.first.currency : "₹";

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: const Text("Expenses"),
        actions: [
          IconButton(
            onPressed: _openFiltersSheet,
            tooltip: "Filters",
            icon: const Icon(Icons.tune_rounded),
          ),
          IconButton(
            onPressed: () {},
            tooltip: "New Expense",
            icon: const Icon(Icons.add_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Search
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              child: _SearchField(
                controller: _searchCtl,
                onChanged: (_) => setState(() {}),
                onClear: () {
                  _searchCtl.clear();
                  setState(() {});
                },
              ),
            ),

            // Status tabs
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _StatusTab(
                      label: "All",
                      selected: _selectedStatus == _ExpenseStatus.all,
                      count: _all.length,
                      onTap: () => setState(() => _selectedStatus = _ExpenseStatus.all),
                    ),
                    const SizedBox(width: 8),
                    _StatusTab(
                      label: "Draft",
                      selected: _selectedStatus == _ExpenseStatus.draft,
                      count: _countForStatusDraft,
                      onTap: () => setState(() => _selectedStatus = _ExpenseStatus.draft),
                    ),
                    const SizedBox(width: 8),
                    _StatusTab(
                      label: "Submitted",
                      selected: _selectedStatus == _ExpenseStatus.submitted,
                      count: _countForStatusSubmitted,
                      onTap: () => setState(() => _selectedStatus = _ExpenseStatus.submitted),
                    ),
                    const SizedBox(width: 8),
                    _StatusTab(
                      label: "Pending",
                      selected: _selectedStatus == _ExpenseStatus.pending,
                      count: _countForStatusPending,
                      onTap: () => setState(() => _selectedStatus = _ExpenseStatus.pending),
                    ),
                    const SizedBox(width: 8),
                    _StatusTab(
                      label: "Approved",
                      selected: _selectedStatus == _ExpenseStatus.approved,
                      count: _countForStatusApproved,
                      onTap: () => setState(() => _selectedStatus = _ExpenseStatus.approved),
                    ),
                    const SizedBox(width: 8),
                    _StatusTab(
                      label: "Posted",
                      selected: _selectedStatus == _ExpenseStatus.posted,
                      count: _countForStatusPosted,
                      onTap: () => setState(() => _selectedStatus = _ExpenseStatus.posted),
                    ),
                    const SizedBox(width: 8),
                    _StatusTab(
                      label: "Paid",
                      selected: _selectedStatus == _ExpenseStatus.paid,
                      count: _countForStatusPaid,
                      onTap: () => setState(() => _selectedStatus = _ExpenseStatus.paid),
                    ),
                    const SizedBox(width: 8),
                    _StatusTab(
                      label: "Rejected",
                      selected: _selectedStatus == _ExpenseStatus.rejected,
                      count: _countForStatusRejected,
                      onTap: () => setState(() => _selectedStatus = _ExpenseStatus.rejected),
                    ),
                  ],
                ),
              ),
            ),

            // Active filters chips + summary
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            _ChipToggle(
                              label: "Missing receipt",
                              selected: _onlyMissingReceipt,
                              icon: Icons.receipt_long_rounded,
                              onTap: () => setState(() => _onlyMissingReceipt = !_onlyMissingReceipt),
                            ),
                            _ChipMenu(
                              label: "Payment",
                              value: switch (_paymentMode) {
                                _PaymentMode.all => "All",
                                _PaymentMode.reimbursable => "Reimbursable",
                                _PaymentMode.companyPaid => "Company paid",
                              },
                              icon: Icons.account_balance_wallet_rounded,
                              onTap: _openPaymentPickerSheet,
                            ),
                            _ChipMenu(
                              label: "Sort",
                              value: switch (_sortBy) {
                                _SortBy.newest => "Newest",
                                _SortBy.oldest => "Oldest",
                                _SortBy.amountHigh => "Amount ↓",
                                _SortBy.amountLow => "Amount ↑",
                              },
                              icon: Icons.sort_rounded,
                              onTap: _openSortPickerSheet,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          "Showing ${items.length} expenses",
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      Text(
                        "$currency${total.toStringAsFixed(0)}",
                        style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // List
            Expanded(
              child: items.isEmpty
                  ? _EmptyState(
                title: "No expenses found",
                subtitle: "Try clearing filters or changing the search.",
                onClear: _clearAllFilters,
              )
                  : ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, i) => _ExpenseTile(
                  data: items[i],
                  onTap: () {},
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        icon: const Icon(Icons.add_rounded),
        label: const Text("New Expense"),
      ),
    );
  }

  void _clearAllFilters() {
    setState(() {
      _selectedStatus = _ExpenseStatus.all;
      _onlyMissingReceipt = false;
      _paymentMode = _PaymentMode.all;
      _sortBy = _SortBy.newest;
      _searchCtl.clear();
    });
  }

  void _openFiltersSheet() {
    final theme = Theme.of(context);

    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Filters",
                style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 12),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                value: _onlyMissingReceipt,
                onChanged: (v) => setState(() => _onlyMissingReceipt = v),
                title: const Text("Only missing receipt"),
                subtitle: const Text("Show expenses without bill attachment"),
              ),
              const SizedBox(height: 6),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.account_balance_wallet_rounded),
                title: const Text("Payment mode"),
                subtitle: Text(
                  switch (_paymentMode) {
                    _PaymentMode.all => "All",
                    _PaymentMode.reimbursable => "Reimbursable",
                    _PaymentMode.companyPaid => "Company paid",
                  },
                ),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () {
                  Navigator.pop(ctx);
                  _openPaymentPickerSheet();
                },
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.sort_rounded),
                title: const Text("Sort by"),
                subtitle: Text(
                  switch (_sortBy) {
                    _SortBy.newest => "Newest",
                    _SortBy.oldest => "Oldest",
                    _SortBy.amountHigh => "Amount (high to low)",
                    _SortBy.amountLow => "Amount (low to high)",
                  },
                ),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () {
                  Navigator.pop(ctx);
                  _openSortPickerSheet();
                },
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _clearAllFilters();
                      },
                      child: const Text("Clear"),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text("Apply"),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  void _openPaymentPickerSheet() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        return _RadioSheet<_PaymentMode>(
          title: "Payment mode",
          value: _paymentMode,
          items: const [
            _RadioItem(value: _PaymentMode.all, label: "All"),
            _RadioItem(value: _PaymentMode.reimbursable, label: "Reimbursable"),
            _RadioItem(value: _PaymentMode.companyPaid, label: "Company paid"),
          ],
          onChanged: (v) => setState(() => _paymentMode = v),
        );
      },
    );
  }

  void _openSortPickerSheet() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        return _RadioSheet<_SortBy>(
          title: "Sort by",
          value: _sortBy,
          items: const [
            _RadioItem(value: _SortBy.newest, label: "Newest"),
            _RadioItem(value: _SortBy.oldest, label: "Oldest"),
            _RadioItem(value: _SortBy.amountHigh, label: "Amount (high to low)"),
            _RadioItem(value: _SortBy.amountLow, label: "Amount (low to high)"),
          ],
          onChanged: (v) => setState(() => _sortBy = v),
        );
      },
    );
  }
}

/* ------------------------------ Components ----------------------------- */

class _SearchField extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;

  const _SearchField({
    required this.controller,
    required this.onChanged,
    required this.onClear,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return TextField(
      controller: controller,
      onChanged: onChanged,
      textInputAction: TextInputAction.search,
      decoration: InputDecoration(
        hintText: "Search expenses…",
        prefixIcon: const Icon(Icons.search_rounded),
        suffixIcon: controller.text.isEmpty
            ? null
            : IconButton(
          onPressed: onClear,
          icon: const Icon(Icons.close_rounded),
          tooltip: "Clear",
        ),
        filled: true,
        fillColor: theme.colorScheme.surfaceContainerHighest,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}

class _StatusTab extends StatelessWidget {
  final String label;
  final int count;
  final bool selected;
  final VoidCallback onTap;

  const _StatusTab({
    required this.label,
    required this.count,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ChoiceChip(
      label: Text("$label ($count)"),
      selected: selected,
      onSelected: (_) => onTap(),
      labelStyle: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w800),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
      side: BorderSide(color: theme.colorScheme.outlineVariant.withOpacity(0.7)),
    );
  }
}

class _ChipToggle extends StatelessWidget {
  final String label;
  final bool selected;
  final IconData icon;
  final VoidCallback onTap;

  const _ChipToggle({
    required this.label,
    required this.selected,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.7)),
          color: selected ? theme.colorScheme.secondaryContainer : theme.colorScheme.surface,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w800),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChipMenu extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final VoidCallback onTap;

  const _ChipMenu({
    required this.label,
    required this.value,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.7)),
          color: theme.colorScheme.surface,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16),
            const SizedBox(width: 8),
            Text(
              "$label: $value",
              style: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.expand_more_rounded, size: 18),
          ],
        ),
      ),
    );
  }
}

class _ExpenseTile extends StatelessWidget {
  final _ExpenseRow data;
  final VoidCallback onTap;

  const _ExpenseTile({required this.data, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final dateText = _formatDate(data.date);

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
          ),
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                height: 46,
                width: 46,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: theme.colorScheme.primaryContainer,
                ),
                child: Icon(
                  data.hasReceipt ? Icons.receipt_rounded : Icons.receipt_long_rounded,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            data.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900),
                          ),
                        ),
                        const SizedBox(width: 8),
                        _StatusChip(status: data.status),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      "${data.merchant} • ${data.category}",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Text(
                          dateText,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        const SizedBox(width: 10),
                        if (!data.hasReceipt)
                          Text(
                            "Receipt missing",
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        const Spacer(),
                        Text(
                          "${data.currency}${data.amount.toStringAsFixed(0)}",
                          style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime d) {
    const months = [
      "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"
    ];
    return "${months[d.month - 1]} ${d.day}, ${d.year}";
  }
}

class _StatusChip extends StatelessWidget {
  final _ExpenseStatus status;
  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final label = switch (status) {
      _ExpenseStatus.all => "All",
      _ExpenseStatus.draft => "Draft",
      _ExpenseStatus.submitted => "Submitted",
      _ExpenseStatus.pending => "Pending",
      _ExpenseStatus.approved => "Approved",
      _ExpenseStatus.posted => "Posted",
      _ExpenseStatus.paid => "Paid",
      _ExpenseStatus.rejected => "Rejected",
    };

    final icon = switch (status) {
      _ExpenseStatus.all => Icons.list_alt_rounded,
      _ExpenseStatus.draft => Icons.edit_note_rounded,
      _ExpenseStatus.submitted => Icons.send_rounded,
      _ExpenseStatus.pending => Icons.hourglass_top_rounded,
      _ExpenseStatus.approved => Icons.verified_rounded,
      _ExpenseStatus.posted => Icons.account_balance_rounded,
      _ExpenseStatus.paid => Icons.payments_rounded,
      _ExpenseStatus.rejected => Icons.block_rounded,
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14),
          const SizedBox(width: 6),
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback onClear;

  const _EmptyState({
    required this.title,
    required this.subtitle,
    required this.onClear,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inbox_rounded, size: 42, color: theme.colorScheme.onSurfaceVariant),
            const SizedBox(height: 10),
            Text(
              title,
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: onClear,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text("Clear filters"),
            ),
          ],
        ),
      ),
    );
  }
}

/* ---------------------------- Bottom Sheets ---------------------------- */

class _RadioItem<T> {
  final T value;
  final String label;
  const _RadioItem({required this.value, required this.label});
}

class _RadioSheet<T> extends StatelessWidget {
  final String title;
  final T value;
  final List<_RadioItem<T>> items;
  final ValueChanged<T> onChanged;

  const _RadioSheet({
    required this.title,
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          for (final it in items)
            RadioListTile<T>(
              value: it.value,
              groupValue: value,
              onChanged: (v) {
                if (v == null) return;
                onChanged(v);
                Navigator.pop(context);
              },
              title: Text(it.label),
              contentPadding: EdgeInsets.zero,
            ),
        ],
      ),
    );
  }
}

/* ------------------------------- Data --------------------------------- */

enum _ExpenseStatus { all, draft, submitted, pending, approved, posted, paid, rejected }
enum _PaymentMode { all, reimbursable, companyPaid }
enum _SortBy { newest, oldest, amountHigh, amountLow }

class _ExpenseRow {
  final String title;
  final String merchant;
  final String category;
  final DateTime date;
  final double amount;
  final String currency;
  final _ExpenseStatus status;
  final bool hasReceipt;
  final _PaymentMode paymentMode;

  const _ExpenseRow({
    required this.title,
    required this.merchant,
    required this.category,
    required this.date,
    required this.amount,
    required this.currency,
    required this.status,
    required this.hasReceipt,
    required this.paymentMode,
  });
}
