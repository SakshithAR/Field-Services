import 'dart:async';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:provider/provider.dart';

import 'expense_repository.dart';
import 'expense_record.dart';
import 'package:flutter/cupertino.dart';
import 'package:field_service/src/odoo/odoo_repository/lib/odoo_repository.dart';

class ExpensesListPage extends StatefulWidget {

  const ExpensesListPage({
    super.key,
  });

  @override
  State<ExpensesListPage> createState() => _ExpensesListPageState();
}

class _ExpensesListPageState extends State<ExpensesListPage> {
  static const int _pageSize = 20;

  late ExpenseRepository _repository;
  late final PagingController<int, ExpenseRecord> _pagingController;

  final TextEditingController _searchCtl = TextEditingController();
  Timer? _debounce;

  String? _filterState;
  String? _filterPaymentMode;

  @override
  void initState() {
    super.initState();

    final env = context.read<OdooEnvironment>();
    env.add(ExpenseRepository(env));
    _repository = env.of<ExpenseRepository>();

    _pagingController = PagingController<int, ExpenseRecord>(
      getNextPageKey: (state) {
        // ✅ First load must start at 0
        if (state.pages == null || state.pages!.isEmpty) return 0;

        final lastPage = state.pages!.last;

        // ✅ If server returned fewer than pageSize => last page
        if (lastPage.length < _pageSize) return null;

        // ✅ Next page index (0,1,2...)
        return state.pages!.length;
      },
      fetchPage: (pageIndex) async {
        debugPrint("📌 fetchPage pageIndex=$pageIndex pageSize=$_pageSize");
        return _repository.fetchExpensesPageWithSpecification(
          pageKey: pageIndex,   // ✅ 0-based
          pageSize: _pageSize,
          search: _searchCtl.text,
          state: _filterState,
          paymentMode: _filterPaymentMode,
        );
      },
    );

  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtl.dispose();
    _pagingController.dispose();
    super.dispose();
  }

  void _onSearchChanged(String _) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () {
      _pagingController.refresh();
      setState(() {});
    });
  }

  void _clearSearch() {
    _searchCtl.clear();
    _pagingController.refresh();
    setState(() {});
  }

  void _openFilterSheet() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        String? tempState = _filterState;
        String? tempPay = _filterPaymentMode;

        return StatefulBuilder(
          builder: (context, setModal) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Filters",
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 12),

                  DropdownButtonFormField<String?>(
                    value: tempState,
                    items: const [
                      DropdownMenuItem(value: null, child: Text("All Status")),
                      DropdownMenuItem(value: "draft", child: Text("Draft")),
                      DropdownMenuItem(value: "submitted", child: Text("Submitted")),
                      DropdownMenuItem(value: "approved", child: Text("Approved")),
                      DropdownMenuItem(value: "paid", child: Text("Paid")),
                      DropdownMenuItem(value: "refused", child: Text("Rejected")),
                    ],
                    onChanged: (v) => setModal(() => tempState = v),
                    decoration: InputDecoration(
                      labelText: "Status",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  DropdownButtonFormField<String?>(
                    value: tempPay,
                    items: const [
                      DropdownMenuItem(value: null, child: Text("All Payment Modes")),
                      DropdownMenuItem(
                        value: "own_account",
                        child: Text("Employee (Reimbursable)"),
                      ),
                      DropdownMenuItem(
                        value: "company_account",
                        child: Text("Company Paid"),
                      ),
                    ],
                    onChanged: (v) => setModal(() => tempPay = v),
                    decoration: InputDecoration(
                      labelText: "Payment mode",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),

                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () {
                            setState(() {
                              _filterState = null;
                              _filterPaymentMode = null;
                            });
                            Navigator.pop(ctx);
                            _pagingController.refresh();
                          },
                          child: const Text("Clear"),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton(
                          onPressed: () {
                            setState(() {
                              _filterState = tempState;
                              _filterPaymentMode = tempPay;
                            });
                            Navigator.pop(ctx);
                            _pagingController.refresh();
                          },
                          child: const Text("Apply"),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _openSortSnack() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Sort UI later (backend connection pending)")),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: const Text("Expenses"),
        actions: [
          IconButton(
            tooltip: "Filter",
            onPressed: _openFilterSheet,
            icon: const Icon(Icons.tune_rounded),
          ),
          IconButton(
            tooltip: "Sort",
            onPressed: _openSortSnack,
            icon: const Icon(Icons.sort_rounded),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(58),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: TextField(
              controller: _searchCtl,
              onChanged: _onSearchChanged,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: "Search expenses…",
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _searchCtl.text.isEmpty
                    ? null
                    : IconButton(
                  tooltip: "Clear",
                  icon: const Icon(Icons.close_rounded),
                  onPressed: _clearSearch,
                ),
                filled: true,
                fillColor: theme.colorScheme.surfaceContainerHighest,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ),
      ),

      // ✅ Body ONLY contains the list
      body: RefreshIndicator(
        onRefresh: () => Future.sync(() => _pagingController.refresh()),
        child: PagingListener<int, ExpenseRecord>(
          controller: _pagingController,
          builder: (context, state, fetchNextPage) {
            return PagedListView<int, ExpenseRecord>.separated(
              state: state,
              fetchNextPage: fetchNextPage,
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              builderDelegate: PagedChildBuilderDelegate<ExpenseRecord>(
                itemBuilder: (context, item, index) => _ExpenseTile(expense: item),

                // optional
                animateTransitions: true,
                transitionDuration: const Duration(milliseconds: 300),

                firstPageProgressIndicatorBuilder: (_) =>
                const _CenterLoader(label: "Loading expenses…"),
                newPageProgressIndicatorBuilder: (_) =>
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 14),
                  child: _CenterLoader(label: "Loading more…"),
                ),

                firstPageErrorIndicatorBuilder: (_) => _ErrorState(
                  title: "Failed to load expenses",
                  subtitle: state.error?.toString(),
                  onTryAgain: () => fetchNextPage(),
                ),
                newPageErrorIndicatorBuilder: (_) => _ErrorState(
                  title: "Failed to load more",
                  subtitle: state.error?.toString(),
                  onTryAgain: () => fetchNextPage(),
                ),

                noItemsFoundIndicatorBuilder: (_) => const _EmptyState(),
                noMoreItemsIndicatorBuilder: (_) => const _NoMoreItems(),
              ),
              separatorBuilder: (_, __) => const SizedBox(height: 10),
            );
          },
        ),
      ),
    );
  }
}

/* ------------------------------ UI Widgets ------------------------------ */

class _ExpenseTile extends StatelessWidget {
  final ExpenseRecord expense;
  const _ExpenseTile({required this.expense});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final symbol = expense.currency.symbol.isNotEmpty
        ? expense.currency.symbol
        : (expense.currency.name.contains("INR") ? "₹" : "");

    final title = expense.name.isEmpty ? "Expense #${expense.id}" : expense.name;

    final subtitle = [
      if (expense.employee.name.isNotEmpty) expense.employee.name,
      if (expense.date != null) _fmtDate(expense.date!),
      if (expense.product.name.isNotEmpty) expense.product.name,
    ].where((e) => e.trim().isNotEmpty).join(" • ");

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {},
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
          ),
          child: Row(
            children: [
              Container(
                height: 44,
                width: 44,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: theme.colorScheme.primaryContainer,
                ),
                child: Icon(
                  expense.attachmentCount > 0
                      ? Icons.receipt_rounded
                      : Icons.receipt_long_rounded,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
              ),
              const SizedBox(width: 12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    "$symbol${expense.totalAmount.toStringAsFixed(0)}",
                    style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 6),
                  _StatusChip(state: expense.state),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  static String _fmtDate(DateTime d) {
    const m = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    return "${m[d.month - 1]} ${d.day}, ${d.year}";
  }
}

class _StatusChip extends StatelessWidget {
  final String state;
  const _StatusChip({required this.state});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final label = switch (state) {
      "draft" => "Draft",
      "reported" => "Submitted",
      "approved" => "Approved",
      "done" => "Done",
      "refused" => "Rejected",
      _ => state.isEmpty ? "—" : state,
    };

    final icon = switch (state) {
      "draft" => Icons.edit_note_rounded,
      "reported" => Icons.send_rounded,
      "approved" => Icons.verified_rounded,
      "done" => Icons.payments_rounded,
      "refused" => Icons.block_rounded,
      _ => Icons.info_outline_rounded,
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14),
          const SizedBox(width: 6),
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }
}

class _CenterLoader extends StatelessWidget {
  final String label;
  const _CenterLoader({required this.label});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 6),
            const CircularProgressIndicator(),
            const SizedBox(height: 12),
            Text(label),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inbox_rounded, size: 44, color: theme.colorScheme.onSurfaceVariant),
            const SizedBox(height: 10),
            Text(
              "No expenses found",
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Text(
              "Try a different search or clear filters.",
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}

class _NoMoreItems extends StatelessWidget {
  const _NoMoreItems();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Center(
        child: Text(
          "No more expenses",
          style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String title;
  final String? subtitle;
  final VoidCallback onTryAgain;

  const _ErrorState({
    required this.title,
    required this.subtitle,
    required this.onTryAgain,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.wifi_off_rounded, size: 44, color: theme.colorScheme.onSurfaceVariant),
            const SizedBox(height: 10),
            Text(title, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
            if (subtitle != null && subtitle!.trim().isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                subtitle!,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: onTryAgain,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text("Try again"),
            ),
          ],
        ),
      ),
    );
  }
}
