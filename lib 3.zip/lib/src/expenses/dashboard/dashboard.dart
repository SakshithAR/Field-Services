import 'package:flutter/material.dart';

class ExpenseDashboardPage extends StatelessWidget {
  const ExpenseDashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // ---- Static demo data ----
    const kpis = <_KpiData>[
      _KpiData(title: "To Submit", value: "3", icon: Icons.edit_note_rounded),
      _KpiData(title: "Pending Approval", value: "2", icon: Icons.hourglass_top_rounded),
      _KpiData(title: "Approved", value: "6", icon: Icons.verified_rounded),
      _KpiData(title: "Reimbursed (Month)", value: "₹12,450", icon: Icons.payments_rounded),
    ];

    const quickActions = <_QuickActionData>[
      _QuickActionData(title: "Scan Receipt", icon: Icons.document_scanner_rounded),
      _QuickActionData(title: "New Expense", icon: Icons.add_circle_outline_rounded),
      _QuickActionData(title: "Mileage", icon: Icons.route_rounded),
      _QuickActionData(title: "Reports", icon: Icons.bar_chart_rounded),
    ];

    const alerts = <_AlertData>[
      _AlertData(
        title: "Missing receipt",
        message: "1 expense needs a bill attachment.",
        icon: Icons.receipt_long_rounded,
      ),
      _AlertData(
        title: "Rejected expense",
        message: "Taxi - add purpose note and resubmit.",
        icon: Icons.error_outline_rounded,
      ),
    ];

    const categorySpend = <_CategorySpend>[
      _CategorySpend(name: "Travel", amount: 8420),
      _CategorySpend(name: "Meals", amount: 3120),
      _CategorySpend(name: "Supplies", amount: 1780),
      _CategorySpend(name: "Other", amount: 620),
    ];

    const recentExpenses = <_ExpenseRowData>[
      _ExpenseRowData(
        title: "Uber / Taxi",
        date: "Dec 12, 2025",
        amount: "₹420",
        status: _ExpenseStatus.pending,
        hasReceipt: true,
      ),
      _ExpenseRowData(
        title: "Client lunch",
        date: "Dec 11, 2025",
        amount: "₹1,250",
        status: _ExpenseStatus.approved,
        hasReceipt: true,
      ),
      _ExpenseRowData(
        title: "Stationery",
        date: "Dec 09, 2025",
        amount: "₹380",
        status: _ExpenseStatus.draft,
        hasReceipt: false,
      ),
      _ExpenseRowData(
        title: "Hotel stay",
        date: "Dec 05, 2025",
        amount: "₹6,800",
        status: _ExpenseStatus.reimbursed,
        hasReceipt: true,
      ),
    ];

    // ---- Derived values for simple chart-like list ----
    final maxSpend = categorySpend.map((e) => e.amount).fold<int>(0, (a, b) => a > b ? a : b);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        elevation: 0,
        centerTitle: false,
        title: const Text("Expenses"),
        actions: [
          IconButton(
            onPressed: () {},
            tooltip: "Notifications",
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          const SizedBox(width: 4),
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: CircleAvatar(
              radius: 16,
              child: Text(
                "AH",
                style: theme.textTheme.labelLarge?.copyWith(
                  color: theme.colorScheme.onPrimary,
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        icon: const Icon(Icons.add_rounded),
        label: const Text("New"),
      ),
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: _HeaderCard(
                  name: "Abdul Hakeem",
                  subtitle: "Here’s your expense summary for this month",
                  primaryText: "₹18,940",
                  secondaryText: "Total submitted (Dec)",
                ),
              ),
            ),

            // Alerts
            if (alerts.isNotEmpty)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _SectionTitle(title: "Alerts"),
                      const SizedBox(height: 10),
                      SizedBox(
                        height: 112,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: alerts.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 12),
                          itemBuilder: (context, i) => _AlertCard(data: alerts[i]),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            // KPI grid
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _SectionTitle(title: "Overview"),
                    const SizedBox(height: 10),
                    LayoutBuilder(
                      builder: (context, c) {
                        final isWide = c.maxWidth >= 520;
                        final crossAxisCount = isWide ? 4 : 2;

                        return GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: kpis.length,
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: crossAxisCount,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                            childAspectRatio: isWide ? 1.6 : 1.55,
                          ),
                          itemBuilder: (context, i) => _KpiCard(data: kpis[i]),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),

            // Quick actions
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _SectionTitle(title: "Quick actions"),
                    const SizedBox(height: 10),
                    Row(
                      children: quickActions.map((a) {
                        return Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: _QuickActionButton(data: a),
                          ),
                        );
                      }).toList()
                        ..removeLast(), // remove extra right padding on last
                    ),
                  ],
                ),
              ),
            ),

            // Spend by category (simple bar list)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _SectionTitle(title: "Spend by category"),
                    const SizedBox(height: 10),
                    Card(
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          children: [
                            for (final c in categorySpend) ...[
                              _CategoryBarRow(
                                name: c.name,
                                amountLabel: "₹${c.amount}",
                                progress: maxSpend == 0 ? 0 : c.amount / maxSpend,
                              ),
                              if (c != categorySpend.last) const SizedBox(height: 10),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Recent expenses
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Row(
                  children: [
                    Expanded(child: _SectionTitle(title: "Recent expenses")),
                    TextButton(
                      onPressed: () {},
                      child: const Text("View all"),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverList.separated(
                itemCount: recentExpenses.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, i) => _ExpenseTile(data: recentExpenses[i]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/* ------------------------------- Widgets ------------------------------- */

class _HeaderCard extends StatelessWidget {
  final String name;
  final String subtitle;
  final String primaryText;
  final String secondaryText;

  const _HeaderCard({
    required this.name,
    required this.subtitle,
    required this.primaryText,
    required this.secondaryText,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
        ),
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Hi, $name 👋",
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    primaryText,
                    style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    secondaryText,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Container(
              height: 56,
              width: 56,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: theme.colorScheme.primaryContainer,
              ),
              child: Icon(
                Icons.account_balance_wallet_rounded,
                color: theme.colorScheme.onPrimaryContainer,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Text(
      title,
      style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
    );
  }
}

class _KpiCard extends StatelessWidget {
  final _KpiData data;
  const _KpiCard({required this.data});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {},
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
          ),
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 38,
                width: 38,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: theme.colorScheme.secondaryContainer,
                ),
                child: Icon(
                  data.icon,
                  size: 20,
                  color: theme.colorScheme.onSecondaryContainer,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      data.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      data.value,
                      style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickActionButton extends StatelessWidget {
  final _QuickActionData data;
  const _QuickActionButton({required this.data});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () {},
      child: Container(
        height: 74,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
        ),
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(data.icon, size: 22),
            const SizedBox(height: 6),
            Text(
              data.title,
              textAlign: TextAlign.center,
              style: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }
}

class _AlertCard extends StatelessWidget {
  final _AlertData data;
  const _AlertCard({required this.data});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SizedBox(
      width: 320,
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
          ),
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: theme.colorScheme.tertiaryContainer,
                ),
                child: Icon(
                  data.icon,
                  color: theme.colorScheme.onTertiaryContainer,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      data.title,
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      data.message,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.chevron_right_rounded, color: theme.colorScheme.onSurfaceVariant),
            ],
          ),
        ),
      ),
    );
  }
}

class _CategoryBarRow extends StatelessWidget {
  final String name;
  final String amountLabel;
  final double progress;

  const _CategoryBarRow({
    required this.name,
    required this.amountLabel,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        SizedBox(
          width: 90,
          child: Text(
            name,
            style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w700),
          ),
        ),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: progress.clamp(0, 1),
              minHeight: 10,
              backgroundColor: theme.colorScheme.surfaceContainerHighest,
            ),
          ),
        ),
        const SizedBox(width: 10),
        SizedBox(
          width: 78,
          child: Text(
            amountLabel,
            textAlign: TextAlign.right,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}

class _ExpenseTile extends StatelessWidget {
  final _ExpenseRowData data;
  const _ExpenseTile({required this.data});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {},
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
          ),
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                height: 44,
                width: 44,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: theme.colorScheme.primaryContainer,
                ),
                child: Icon(
                  data.hasReceipt ? Icons.receipt_rounded : Icons.receipt_long_rounded,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      data.title,
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          data.date,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        const SizedBox(width: 10),
                        if (!data.hasReceipt)
                          Text(
                            "Receipt missing",
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    data.amount,
                    style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 6),
                  _StatusChip(status: data.status),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final _ExpenseStatus status;
  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final label = switch (status) {
      _ExpenseStatus.draft => "Draft",
      _ExpenseStatus.pending => "Pending",
      _ExpenseStatus.approved => "Approved",
      _ExpenseStatus.reimbursed => "Paid",
      _ExpenseStatus.rejected => "Rejected",
    };

    final icon = switch (status) {
      _ExpenseStatus.draft => Icons.edit_note_rounded,
      _ExpenseStatus.pending => Icons.hourglass_top_rounded,
      _ExpenseStatus.approved => Icons.verified_rounded,
      _ExpenseStatus.reimbursed => Icons.payments_rounded,
      _ExpenseStatus.rejected => Icons.block_rounded,
    };

    // Use neutral container + icon to keep theme-friendly without hard-coded colors
    final bg = theme.colorScheme.surfaceContainerHighest;
    final fg = theme.colorScheme.onSurface;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.6)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: fg),
          const SizedBox(width: 6),
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w800, color: fg),
          ),
        ],
      ),
    );
  }
}

/* ------------------------------- Models ------------------------------- */

class _KpiData {
  final String title;
  final String value;
  final IconData icon;
  const _KpiData({required this.title, required this.value, required this.icon});
}

class _QuickActionData {
  final String title;
  final IconData icon;
  const _QuickActionData({required this.title, required this.icon});
}

class _AlertData {
  final String title;
  final String message;
  final IconData icon;
  const _AlertData({required this.title, required this.message, required this.icon});
}

class _CategorySpend {
  final String name;
  final int amount;
  const _CategorySpend({required this.name, required this.amount});
}

enum _ExpenseStatus { draft, pending, approved, reimbursed, rejected }

class _ExpenseRowData {
  final String title;
  final String date;
  final String amount;
  final _ExpenseStatus status;
  final bool hasReceipt;

  const _ExpenseRowData({
    required this.title,
    required this.date,
    required this.amount,
    required this.status,
    required this.hasReceipt,
  });
}
