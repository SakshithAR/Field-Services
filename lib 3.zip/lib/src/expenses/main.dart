import 'package:field_service/src/expenses/expense_list/create_expense.dart';
import 'package:field_service/src/expenses/expense_list/expense_list.dart';
import 'package:field_service/src/expenses/expense_list/expense_paged_list_page.dart';
import 'package:flutter/material.dart';

// ✅ Use your existing pages (paste the pages you created earlier into these files)
import 'dashboard/dashboard.dart';

class MainExpenseShell extends StatefulWidget {
  const MainExpenseShell({super.key});

  @override
  State<MainExpenseShell> createState() => _MainExpenseShellState();
}

class _MainExpenseShellState extends State<MainExpenseShell> {
  int _index = 0;

  final _pages = const [
    ExpenseDashboardPage(),
    ExpensesListPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: _pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) async {
          // Center "New" opens Create Expense page (doesn't switch tab)
          if (i == 2) {
            await Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const CreateExpensePage()),
            );
            return;
          }
          setState(() => _index = i);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard_rounded),
            label: "Dashboard",
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long_rounded),
            label: "Expenses",
          ),
          NavigationDestination(
            icon: Icon(Icons.add_circle_outline_rounded),
            selectedIcon: Icon(Icons.add_circle_rounded),
            label: "New",
          ),
        ],
      ),
    );
  }
}
