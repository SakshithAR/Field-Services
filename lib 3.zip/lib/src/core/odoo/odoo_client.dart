import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:cookie_jar/cookie_jar.dart';
import '../../config/app_config.dart';
import '../storage/local_store.dart';

class OdooClient {
  final AppConfig config;
  final LocalStore store;
  final Dio _dio;
  final CookieJar _cookieJar = CookieJar();
  bool _sessionSeeded = false;

  Future<void> ensureSession() => _ensureSession();

  OdooClient(this.config, this.store)
      : _dio = Dio(BaseOptions(
          baseUrl: config.baseUrl,
          connectTimeout: const Duration(seconds: 20),
          receiveTimeout: const Duration(seconds: 30),
          headers: {"Content-Type": "application/json"},
        )) {
    _dio.interceptors.add(CookieManager(_cookieJar));
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        // Optional: X-API-Key header if your server methods check it
        // options.headers['X-API-Key'] = config.resumeApiKey;
        // DO NOT set options.headers['Cookie'] here — let CookieManager send cookies
        handler.next(options);
      },
    ));
  }

  // ADD: internal ensure + verify
  Future<void> _ensureSession() async {
    // Seed cookie once from LocalStore
    if (!_sessionSeeded) {
      final data = await store.readAuth();
      final sid = data['sessionId'] as String?;
      if (sid != null && sid.isNotEmpty) {
        await seedSessionCookie(sid);
        _sessionSeeded = true;
      }
    }
    // Verify session; if dead, try reseed once from store
    final alive = await _isSessionAlive();
    if (!alive) {
      final data = await store.readAuth();
      final sid = data['sessionId'] as String?;
      if (sid != null && sid.isNotEmpty) {
        await seedSessionCookie(sid);         // reseed
        _sessionSeeded = true;
      }
      // final check
      final ok = await _isSessionAlive();
      if (!ok) {
        throw Exception('Session expired. Please log in again.');
      }
    }
  }

  Future<bool> _isSessionAlive() async {
    try {
      final info = await getSessionInfo();
      return info.$1 && (info.$2 != null);
    } catch (_) {
      return false;
    }
  }


  Future<Response> _jsonRpc(String path, Map<String, dynamic> payload) async {
    await _ensureSession();
    return _dio.post(path, data: jsonEncode({"jsonrpc": "2.0", "params": payload}));
  }

  // Auth
  // CHANGE: authenticate() to read session_id from cookies
  Future<(bool ok, String? sessionId, int? uid, String? login, String? error)> authenticate({
    required String login,
    required String password,
    String? db,
  }) async {
    try {
      final res = await _dio.post("/web/session/authenticate",
          data: jsonEncode({
            "jsonrpc": "2.0",
            "params": {"db": db ?? config.dbName, "login": login, "password": password}
          }));

      final data = res.data;
      final result = data['result'];
      if (result != null && result['uid'] != null) {
        // Prefer cookie jar (authoritative); fall back to result['session_id']
        final sidFromJar = await _extractSessionIdFromCookies();
        final sid = sidFromJar ?? (result['session_id'] as String?);
        return (true, sid, result['uid'] as int?, login, null);
      } else {
        return (false, null, null, null,
        (data['error']?['data']?['message'] ?? 'Login failed').toString());
      }
    } catch (e) {
      return (false, null, null, null, e.toString());
    }
  }

  // ADD: extract session_id from CookieJar after login
  Future<String?> _extractSessionIdFromCookies() async {
    final cookies = await _cookieJar.loadForRequest(_baseUri);
    for (final c in cookies) {
      if (c.name == 'session_id' && (c.value.isNotEmpty)) {
        return c.value;
      }
    }
    return null;
  }

  // ADD: seed session cookie into CookieJar on app start
  Future<void> seedSessionCookie(String sessionId) async {
    await _cookieJar.saveFromResponse(_baseUri, [
      Cookie('session_id', sessionId)
        ..httpOnly = true
        ..path = '/'
    ]);
  }

  // ADD: normalize base url -> Uri for cookie jar use
  Uri get _baseUri {
    final u = Uri.parse(config.baseUrl);
    // Ensure path '/' so cookies match
    return Uri(scheme: u.scheme, host: u.host, port: u.port, path: '/');
  }


  // ADD: getSessionInfo helper (JSON-RPC)
  Future<(bool ok, int? uid, String? login, String? displayName)> getSessionInfo() async {
    try {
      final res = await _dio.post(
        "/web/session/get_session_info",
        data: jsonEncode({"jsonrpc": "2.0", "params": {}}),
      );
      final r = res.data?['result'];
      if (r != null) {
        final uid = r['uid'] as int?;
        final login = (r['username'] ?? r['login']) as String?;
        final display =
        (r['partner_display_name'] ?? r['display_name'] ?? r['name']) as String?;
        return (true, uid, login, display);
      }
      return (false, null, null, null);
    } catch (_) {
      return (false, null, null, null);
    }
  }

  // ========== call_kw helpers ==========
  Future<dynamic> callKw(String model, String method, List<dynamic> args, {Map<String, dynamic>? kwargs}) async {
    final res = await _jsonRpc("/web/dataset/call_kw/" + model + "/" + method, {
      "model": model,
      "method": method,
      "args": args,
      "kwargs": kwargs ?? {},
    });
    if (res.data is Map && res.data['result'] != null) return res.data['result'];
    if (res.data['error'] != null) throw Exception(res.data['error'].toString());
    return res.data;
  }

  Future<List<dynamic>> searchRead(String model, {List<dynamic>? domain, List<String>? fields, int? limit, String? order}) async {
    final result = await callKw(model, "search_read", [], kwargs: {
      "domain": domain ?? [],
      "fields": fields ?? [],
      "limit": limit ?? 80,
      "order": order ?? "id desc",
    });
    return (result as List).cast<dynamic>();
  }

  Future<int> create(String model, Map<String, dynamic> values) async {
    final result = await callKw(model, "create", [values]);
    return (result as int);
  }

  Future<bool> write(String model, List<int> ids, Map<String, dynamic> values) async {
    final result = await callKw(model, "write", [ids, values]);
    return result == true;
  }

  Future<List<dynamic>> read(String model, List<int> ids, List<String> fields) async {
    final result = await callKw(model, "read", [ids, fields]);
    return (result as List).cast<dynamic>();
  }

  // ======= Resume-specific helpers using call_kw =======
  Future<int> upsertResume(Map<String, dynamic> payload, {int? profileId}) async {
    // Convert your payload (profile + lines) to Odoo write/create values with o2m commands
    final p = payload["profile"] ?? {};
    final lines = (payload["lines"] ?? {}) as Map<String, dynamic>;

    Map<String, dynamic> vals = {
      "name": p["name"],
      "job_title": p["job_title"],
      "email": p["email"],
      "phone": p["phone"],
      "summary": p["summary"],
      "style": p["style"],
      "color_hex": p["color_hex"],
    };

    List<dynamic> exp = [];
    for (final e in (lines["experience"] ?? [])) {
      exp.add([0, 0, {
        "company": e["company"],
        "job_title": e["job_title"],
        "location": e["location"],
        "achievements": e["achievements"],
        "date_from": e["date_from"],
        "date_to": e["date_to"],
        "current": e["current"] ?? false,
      }]);
    }
    if (exp.isNotEmpty) vals["experience_ids"] = exp;

    List<dynamic> edu = [];
    for (final e in (lines["education"] ?? [])) {
      edu.add([0, 0, {
        "school": e["school"],
        "degree": e["degree"],
        "field_of_study": e["field_of_study"],
        "date_from": e["date_from"],
        "date_to": e["date_to"],
        "current": e["current"] ?? false,
      }]);
    }
    if (edu.isNotEmpty) vals["education_ids"] = edu;

    List<dynamic> skills = [];
    for (final s in (lines["skills"] ?? [])) {
      skills.add([0, 0, {
        "name": s["name"],
        "level": s["level"],
        "years": s["years"],
      }]);
    }
    if (skills.isNotEmpty) vals["skill_ids"] = skills;

    if (profileId == null) {
      final id = await create("taq.resume.profile", vals);
      return id;
    } else {
      await write("taq.resume.profile", [profileId], vals);
      return profileId;
    }
  }

  Future<String?> generateAI(int profileId) async {
    final result = await callKw("taq.resume.profile", "action_generate_ai_resume", [[profileId]]);
    // Expect a dict with 'text' or write to field; adjust per your server method
    if (result is Map && result.containsKey("text")) return result["text"] as String?;
    return null;
  }

  Future<String?> generatePDF(int profileId) async {
    final result = await callKw("taq.resume.profile", "action_render_pdf", [[profileId]]);
    // Expect a dict with 'download_url' or an ir.actions.report; handle common cases
    if (result is Map && result.containsKey("download_url")) {
      return config.baseUrl + (result["download_url"] as String);
    }
    return null;
  }
}
