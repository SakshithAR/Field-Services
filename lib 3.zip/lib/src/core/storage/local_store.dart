import 'package:shared_preferences/shared_preferences.dart';

class LocalStore {
  static const _keySessionId = 'odoo_session_id';
  static const _keyUid = 'odoo_uid';
  static const _keyLogin = 'odoo_login';
  static const _keyLastProfileId = 'last_profile_id';
  static const _keyDisplayName = 'odoo_display_name';

  Future<SharedPreferences> get _prefs async => await SharedPreferences.getInstance();

  Future<void> saveAuth({
    required String sessionId,
    required int uid,
    required String login,
    String? displayName, // <-- NEW
  }) async {
    final p = await _prefs;
    await p.setString(_keySessionId, sessionId);
    await p.setInt(_keyUid, uid);
    await p.setString(_keyLogin, login);
    if (displayName != null) {
      await p.setString(_keyDisplayName, displayName);
    }
  }

// CHANGE: include displayName in the returned map
  Future<Map<String, dynamic>> readAuth() async {
    final p = await _prefs;
    return {
      'sessionId': p.getString(_keySessionId),
      'uid': p.getInt(_keyUid),
      'login': p.getString(_keyLogin),
      'displayName': p.getString(_keyDisplayName), // <- NEW
    };
  }

// CHANGE: also clear display name
  Future<void> clearAuth() async {
    final p = await _prefs;
    await p.remove(_keySessionId);
    await p.remove(_keyUid);
    await p.remove(_keyLogin);
    await p.remove(_keyDisplayName); // <- NEW
  }

  Future<void> saveLastProfileId(int id) async {
    final p = await _prefs;
    await p.setInt(_keyLastProfileId, id);
  }

  Future<int?> getLastProfileId() async {
    final p = await _prefs;
    return p.getInt(_keyLastProfileId);
  }
}
