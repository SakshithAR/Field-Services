import 'package:flutter/material.dart';

class AppSettingsState {
  final ThemeMode themeMode;
  final String seedColorHex; // "#RRGGBB"
  final String localeCode;   // e.g. "en_US"
  final double textScale;    // 0.85..1.30
  final bool haptics;

  const AppSettingsState({
    this.themeMode = ThemeMode.system,
    this.seedColorHex = '#1565C0',
    this.localeCode = 'en_US',
    this.textScale = 1.00,
    this.haptics = true,
  });

  AppSettingsState copyWith({
    ThemeMode? themeMode,
    String? seedColorHex,
    String? localeCode,
    double? textScale,
    bool? haptics,
  }) => AppSettingsState(
    themeMode: themeMode ?? this.themeMode,
    seedColorHex: seedColorHex ?? this.seedColorHex,
    localeCode: localeCode ?? this.localeCode,
    textScale: textScale ?? this.textScale,
    haptics: haptics ?? this.haptics,
  );
}

