import 'dart:async';
import 'package:flutter/foundation.dart';

import 'package:field_service/src/odoo/odoo_repository/lib/odoo_repository.dart';
import 'package:odoo_rpc/odoo_rpc.dart';

// ✅ IMPORTANT: import the extension we created
import 'package:field_service/src/odoo/extensions/odoo_client_session.dart';

class AuthController extends ChangeNotifier {
  final OdooEnvironment env;
  final String sessionCacheKey;

  bool initialized = false;
  bool isAuthenticated = false;

  int? uid;
  String? login;
  String? displayName;

  StreamSubscription<OdooLoginEvent>? _loginSub;

  AuthController(this.env, this.sessionCacheKey);

  Future<void> init() async {
    // keep cache in sync on logout events
    _loginSub?.cancel();
    _loginSub = env.orpc.loginStream.listen((evt) async {
      if (evt == OdooLoginEvent.loggedOut) {
        await _clearSession();
        notifyListeners();
      }
    });

    // ✅ 1) probe current client session (if injected from main)
    if (await _probeSession()) {
      initialized = true;
      isAuthenticated = true;
      notifyListeners();
      return;
    }

    // ✅ 2) restore from cache, then probe again
    final cached = env.cache.get(sessionCacheKey, defaultValue: null) as OdooSession?;
    if (cached != null && cached.dbName == env.dbName && env.orpc.sessionId == null) {
      final old = env.orpc;

      final newClient = OdooClient(
        old.baseURL,
        sessionId: cached,
        httpClient: old.httpClient,
        isWebPlatform: old.isWebPlatform,
      );

      old.close();
      env.orpc = newClient;

      // re-wire env listener
      newClient.loginStream.listen(env.loginStateChanged);

      if (await _probeSession()) {
        initialized = true;
        isAuthenticated = true;
        notifyListeners();
        return;
      }
    }

    // ✅ 3) not logged in
    isAuthenticated = false;
    initialized = true;
    notifyListeners();
  }

  Future<bool> loginWithPassword({
    required String login,
    required String password,
  }) async {
    try {
      final session = await env.orpc.authenticate(env.dbName, login, password);

      // persist session
      await env.cache.put(sessionCacheKey, session);

      // fetch user info (safe)
      await _loadSessionInfo();

      isAuthenticated = true;
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint("❌ loginWithPassword failed: $e");
      await _clearSession();
      notifyListeners();
      return false;
    }
  }

  Future<void> logout() async {
    try {
      await env.orpc.destroySession();
    } catch (_) {}
    await _clearSession();
    notifyListeners();
  }

  // ---------------- helpers ----------------

  Future<void> _clearSession() async {
    await env.cache.delete(sessionCacheKey);
    uid = null;
    login = null;
    displayName = null;
    isAuthenticated = false;
  }

  Future<bool> _probeSession() async {
    try {
      // ✅ this uses our extension now
      final info = await env.orpc.getSessionInfo();

      final hasUid = (info['uid'] is int) && ((info['uid'] as int) != 0);
      if (!hasUid) return false;

      uid = info['uid'] as int?;
      login = (info['username'] ?? info['login']) as String?;
      displayName = (info['partner_display_name'] ??
          info['display_name'] ??
          info['name'])
      as String?;

      isAuthenticated = true;
      return true;
    } catch (e) {
      debugPrint("⚠️ probeSession failed: $e");
      return false;
    }
  }

  Future<void> _loadSessionInfo() async {
    try {
      final info = await env.orpc.getSessionInfo();

      uid = info['uid'] as int?;
      login = (info['username'] ?? info['login']) as String?;
      displayName = (info['partner_display_name'] ??
          info['display_name'] ??
          info['name'])
      as String?;
    } catch (_) {
      uid = null;
      login = null;
      displayName = null;
    }
  }

  @override
  void dispose() {
    _loginSub?.cancel();
    super.dispose();
  }
}
