import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'settings_state.dart';

class SettingsController extends ChangeNotifier {
  AppSettingsState _state = const AppSettingsState();
  AppSettingsState get state => _state;

  late final SharedPreferences _prefs;
  bool _ready = false;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _state = AppSettingsState(
      themeMode: _decodeTheme(_prefs.getString('theme') ?? 'system'),
      seedColorHex: _prefs.getString('seedColorHex') ?? '#1565C0',
      localeCode: _prefs.getString('locale') ?? 'en_US',
      textScale: (_prefs.getDouble('textScale') ?? 1.0).clamp(0.85, 1.30),
      haptics: _prefs.getBool('haptics') ?? true,
    );
    _ready = true;
    notifyListeners();
  }

  // Setters
  Future<void> setThemeMode(ThemeMode m) async {
    _state = _state.copyWith(themeMode: m);
    notifyListeners();
    await _prefs.setString('theme', _encodeTheme(m));
  }
  Future<void> setSeedColorHex(String hex) async {
    _state = _state.copyWith(seedColorHex: hex);
    notifyListeners();
    await _prefs.setString('seedColorHex', hex);
  }
  Future<void> setLocale(String code) async {
    _state = _state.copyWith(localeCode: code);
    notifyListeners();
    await _prefs.setString('locale', code);
  }
  Future<void> setTextScale(double v) async {
    final clamped = v.clamp(0.85, 1.30);
    _state = _state.copyWith(textScale: clamped);
    notifyListeners();
    await _prefs.setDouble('textScale', clamped);
  }
  Future<void> setHaptics(bool v) async {
    _state = _state.copyWith(haptics: v);
    notifyListeners();
    await _prefs.setBool('haptics', v);
  }

  // Helpers
  String _encodeTheme(ThemeMode m) => switch (m) {
    ThemeMode.light => 'light',
    ThemeMode.dark => 'dark',
    _ => 'system',
  };
  ThemeMode _decodeTheme(String s) => switch (s) {
    'light' => ThemeMode.light,
    'dark' => ThemeMode.dark,
    _ => ThemeMode.system,
  };

  bool get ready => _ready;
}

