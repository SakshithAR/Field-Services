import 'package:field_service/l10n/app_localizations.dart';
import 'package:field_service/src/attendance/attendance_details_page.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:provider/provider.dart';

import 'attendance_record.dart';
import 'attendance_repository.dart';

import 'package:field_service/src/odoo/odoo_repository/lib/odoo_repository.dart';

class AttendanceListPage extends StatefulWidget {
  const AttendanceListPage({super.key});

  @override
  State<AttendanceListPage> createState() => _AttendanceListPageState();
}

class _AttendanceListPageState extends State<AttendanceListPage> {
  static const int _pageSize = 20;

  // Filter value keys (localized labels are in ARB)
  static const List<String> _rangeKeys = ["today", "week", "month", "all"];
  static const List<String?> _statusKeys = [null, "open", "closed"];

  late AttendanceRepository _repository;
  late final PagingController<int, AttendanceRecord> _pagingController;

  /// Filters
  String? _filterStatus; // null | "open" | "closed"
  String _filterRange = "month"; // "today" | "week" | "month" | "all"

  @override
  void initState() {
    super.initState();

    final env = context.read<OdooEnvironment>();
    env.add(AttendanceRepository(env));
    _repository = env.of<AttendanceRepository>();

    _pagingController = PagingController<int, AttendanceRecord>(
      getNextPageKey: (state) {
        final items = state.items;
        if (items == null) return 0;
        if (items.length < _pageSize) return null;
        return items.length; // offset-based paging
      },
      fetchPage: (pageKey) async {
        final range = _resolveRange(_filterRange);
        return _repository.fetchAttendancesPageWithSpecification(
          pageKey: pageKey,
          pageSize: _pageSize,
          status: _filterStatus,
          dateFrom: range.$1,
          dateTo: range.$2,
        );
      },
    );
  }

  @override
  void dispose() {
    _pagingController.dispose();
    super.dispose();
  }

  (DateTime?, DateTime?) _resolveRange(String key) {
    final now = DateTime.now();
    if (key == "all") return (null, null);

    if (key == "today") {
      final start = DateTime(now.year, now.month, now.day);
      final end = DateTime(now.year, now.month, now.day, 23, 59, 59);
      return (start, end);
    }

    if (key == "week") {
      final weekday = now.weekday; // Mon=1
      final start = DateTime(now.year, now.month, now.day)
          .subtract(Duration(days: weekday - 1));
      final end =
      start.add(const Duration(days: 6, hours: 23, minutes: 59, seconds: 59));
      return (start, end);
    }

    // month
    final start = DateTime(now.year, now.month, 1);
    final nextMonth = (now.month == 12)
        ? DateTime(now.year + 1, 1, 1)
        : DateTime(now.year, now.month + 1, 1);
    final end = nextMonth.subtract(const Duration(seconds: 1));
    return (start, end);
  }

  String _rangeLabel(AppLocalizations l10n, String key) {
    switch (key) {
      case "today":
        return l10n.attFilterRangeToday;
      case "week":
        return l10n.attFilterRangeWeek;
      case "month":
        return l10n.attFilterRangeMonth;
      case "all":
      default:
        return l10n.attFilterRangeAll;
    }
  }

  String _statusLabel(AppLocalizations l10n, String? key) {
    switch (key) {
      case "open":
        return l10n.statusOpen; // already exists in your attendance details ARB
      case "closed":
        return l10n.statusClosed; // already exists in your attendance details ARB
      case null:
      default:
        return l10n.attFilterStatusAll;
    }
  }

  void _openFilterSheet() {
    final l10n = AppLocalizations.of(context)!;

    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        String? tempStatus = _filterStatus;
        String tempRange = _filterRange;

        return StatefulBuilder(
          builder: (context, setModal) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    l10n.attFiltersTitle,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),

                  Text(
                    l10n.attDateRangeLabel,
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  const SizedBox(height: 8),

                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: _rangeKeys.map((k) {
                      return ChoiceChip(
                        label: Text(_rangeLabel(l10n, k)),
                        selected: tempRange == k,
                        onSelected: (selected) {
                          if (selected) setModal(() => tempRange = k);
                        },
                      );
                    }).toList(),
                  ),

                  const SizedBox(height: 8),

                  Text(
                    l10n.attStatusLabel,
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  const SizedBox(height: 8),

                  ..._statusKeys.map((k) {
                    final label = (k == null)
                        ? l10n.attFilterStatusAll
                        : (k == "open"
                        ? l10n.attFilterStatusOpen
                        : l10n.attFilterStatusClosed);

                    return RadioListTile<String?>(
                      visualDensity: VisualDensity.compact,
                      title: Text(label),
                      value: k,
                      groupValue: tempStatus,
                      onChanged: (v) => setModal(() => tempStatus = v),
                    );
                  }),

                  const SizedBox(height: 8),
                  const Divider(height: 0, thickness: 0.5),
                  const SizedBox(height: 4),

                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () {
                            setState(() {
                              _filterStatus = null;
                              _filterRange = "month";
                            });
                            Navigator.pop(ctx);
                            _pagingController.refresh();
                          },
                          child: Text(l10n.attClearFilters),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton(
                          onPressed: () {
                            setState(() {
                              _filterStatus = tempStatus;
                              _filterRange = tempRange;
                            });
                            Navigator.pop(ctx);
                            _pagingController.refresh();
                          },
                          child: Text(l10n.attApplyFilters),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    final statusText = _statusLabel(l10n, _filterStatus);
    final rangeText = _rangeLabel(l10n, _filterRange);

    // Note: your ARB placeholders are {status} and {range}
    final filterDescription = l10n.attFilterDescription(statusText, rangeText);

    final isFilterActive = (_filterStatus != null || _filterRange != "month");

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              l10n.attendanceTitle,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            Text(
              filterDescription,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: l10n.attFilterTooltip,
            onPressed: _openFilterSheet,
            icon: Icon(
              Icons.tune_rounded,
              color: isFilterActive ? theme.colorScheme.primary : null,
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => Future.sync(() => _pagingController.refresh()),
        child: PagingListener<int, AttendanceRecord>(
          controller: _pagingController,
          builder: (context, state, fetchNextPage) {
            return PagedListView<int, AttendanceRecord>.separated(
              state: state,
              fetchNextPage: fetchNextPage,
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              builderDelegate: PagedChildBuilderDelegate<AttendanceRecord>(
                itemBuilder: (context, item, index) =>
                    _AttendanceTile(item: item),

                animateTransitions: true,
                transitionDuration: const Duration(milliseconds: 300),

                firstPageProgressIndicatorBuilder: (_) =>
                    _CenterLoader(label: l10n.attLoadingAttendance),
                newPageProgressIndicatorBuilder: (_) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  child: _CenterLoader(label: l10n.attLoadingMore),
                ),

                firstPageErrorIndicatorBuilder: (_) => _ErrorState(
                  title: l10n.attFailedToLoad,
                  subtitle: state.error?.toString(),
                  onTryAgain: fetchNextPage,
                ),
                newPageErrorIndicatorBuilder: (_) => _ErrorState(
                  title: l10n.attFailedToLoadMore,
                  subtitle: state.error?.toString(),
                  onTryAgain: fetchNextPage,
                ),

                // ✅ FIX: cannot be const (it reads l10n)
                noItemsFoundIndicatorBuilder: (_) => const _EmptyState(),
                noMoreItemsIndicatorBuilder: (_) =>
                    _NoMoreItems(text: l10n.attNoMoreItems),
              ),
            );
          },
        ),
      ),
    );
  }
}

/* -------------------------- Tile Widgets --------------------------- */

class _AttendanceTile extends StatelessWidget {
  final AttendanceRecord item;
  const _AttendanceTile({required this.item});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    final title = item.employee.name.isNotEmpty
        ? item.employee.name
        : l10n.employeeFallback(item.employee.id.toString());

    final dateLine = _fmtDate(item.checkIn);
    final inTime = _fmtTime(item.checkIn);
    final outTime = item.checkOut == null ? "—" : _fmtTime(item.checkOut!);

    final isOpen = item.checkOut == null;

    final worked = item.workedHours > 0
        ? l10n.hoursValue(item.workedHours.toStringAsFixed(1))
        : "—";

    final tileColor = isOpen
        ? theme.colorScheme.tertiaryContainer
        : theme.colorScheme.surface;

    final iconColor = isOpen
        ? theme.colorScheme.onTertiaryContainer
        : theme.colorScheme.primary;

    return Card(
      margin: EdgeInsets.zero,
      elevation: isOpen ? 2 : 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: isOpen
              ? theme.colorScheme.tertiary.withOpacity(0.5)
              : theme.colorScheme.outlineVariant,
          width: isOpen ? 1.5 : 1,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AttendanceDetailsPage(record: item),
            ),
          );
        },
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: tileColor,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 48,
                width: 48,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: isOpen
                      ? theme.colorScheme.tertiary
                      : theme.colorScheme.primaryContainer,
                ),
                child: Icon(
                  isOpen
                      ? Icons.access_time_filled_rounded
                      : Icons.check_circle_outline_rounded,
                  color: iconColor,
                  size: 28,
                ),
              ),
              const SizedBox(width: 16),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      dateLine,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "${l10n.checkInTitle}: $inTime • ${l10n.checkOutTitle}: $outTime",
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 10),

              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    worked,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: isOpen
                          ? theme.colorScheme.tertiary
                          : theme.colorScheme.primary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  _AttendanceStatusChip(isOpen: isOpen),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  static String _fmtTime(DateTime d) {
    int h = d.hour;
    final m = d.minute.toString().padLeft(2, '0');
    final ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12;
    if (h == 0) h = 12;
    return "$h:$m $ampm";
  }

  static String _fmtDate(DateTime d) {
    const m = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return "${m[d.month - 1]} ${d.day}, ${d.year}";
  }
}

class _AttendanceStatusChip extends StatelessWidget {
  final bool isOpen;
  const _AttendanceStatusChip({required this.isOpen});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    final label = isOpen ? l10n.statusOpen : l10n.statusClosed;
    final icon = isOpen ? Icons.circle : Icons.check_circle_rounded;

    final color = isOpen
        ? theme.colorScheme.errorContainer
        : theme.colorScheme.secondaryContainer;

    final onColor = isOpen
        ? theme.colorScheme.onErrorContainer
        : theme.colorScheme.onSecondaryContainer;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: onColor),
          const SizedBox(width: 4),
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              fontWeight: FontWeight.bold,
              color: onColor,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}

/* -------------------------- List State Widgets -------------------------- */

class _CenterLoader extends StatelessWidget {
  final String label;
  const _CenterLoader({required this.label});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 12),
            Text(label, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inbox_rounded,
                size: 48, color: theme.colorScheme.onSurfaceVariant),
            const SizedBox(height: 12),
            Text(
              l10n.attNoAttendanceTitle,
              style: theme.textTheme.titleLarge
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              l10n.attNoAttendanceSubtitle,
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}

class _NoMoreItems extends StatelessWidget {
  final String text;
  const _NoMoreItems({required this.text});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 24),
      child: Center(
        child: Text(
          text,
          style: theme.textTheme.bodySmall
              ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String title;
  final String? subtitle;
  final VoidCallback onTryAgain;

  const _ErrorState({
    required this.title,
    required this.subtitle,
    required this.onTryAgain,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline_rounded,
                size: 48, color: theme.colorScheme.error),
            const SizedBox(height: 12),
            Text(
              title,
              style: theme.textTheme.titleLarge
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
            if (subtitle != null && subtitle!.trim().isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                subtitle!,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: onTryAgain,
              icon: const Icon(Icons.refresh_rounded),
              label: Text(l10n.attTryAgain),
            ),
          ],
        ),
      ),
    );
  }
}
