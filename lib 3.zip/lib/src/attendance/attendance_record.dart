import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart' show debugPrint;

import '../odoo/odoo_repository/lib/src/odoo_record.dart';

/// Record class for Odoo model: `hr.attendance`
class AttendanceRecord extends Equatable implements OdooRecord {
  @override
  final int id;

  /// Many2one: hr.employee
  final EmployeeRecord employee;

  /// Odoo datetime strings -> parsed to local DateTime
  final DateTime checkIn;
  final DateTime? checkOut;

  /// Odoo float (hours)
  final double workedHours;

  /// ✅ Missing fields from your specification
  final double? validatedOvertimeHours;

  final double? inLatitude;
  final double? inLongitude;
  final double? outLatitude;
  final double? outLongitude;

  final String? inIpAddress;
  final String? outIpAddress;

  const AttendanceRecord({
    required this.id,
    required this.employee,
    required this.checkIn,
    this.checkOut,
    required this.workedHours,

    this.validatedOvertimeHours,

    this.inLatitude,
    this.inLongitude,
    this.outLatitude,
    this.outLongitude,

    this.inIpAddress,
    this.outIpAddress,
  });

  bool get isOpen => checkOut == null;

  @override
  List<Object?> get props => [
    id,
    employee,
    checkIn,
    checkOut,
    workedHours,
    validatedOvertimeHours,
    inLatitude,
    inLongitude,
    outLatitude,
    outLongitude,
    inIpAddress,
    outIpAddress,
  ];

  AttendanceRecord copyWith({
    int? id,
    EmployeeRecord? employee,
    DateTime? checkIn,
    DateTime? checkOut,
    double? workedHours,

    double? validatedOvertimeHours,

    double? inLatitude,
    double? inLongitude,
    double? outLatitude,
    double? outLongitude,

    String? inIpAddress,
    String? outIpAddress,
  }) {
    return AttendanceRecord(
      id: id ?? this.id,
      employee: employee ?? this.employee,
      checkIn: checkIn ?? this.checkIn,
      checkOut: checkOut ?? this.checkOut,
      workedHours: workedHours ?? this.workedHours,

      validatedOvertimeHours: validatedOvertimeHours ?? this.validatedOvertimeHours,

      inLatitude: inLatitude ?? this.inLatitude,
      inLongitude: inLongitude ?? this.inLongitude,
      outLatitude: outLatitude ?? this.outLatitude,
      outLongitude: outLongitude ?? this.outLongitude,

      inIpAddress: inIpAddress ?? this.inIpAddress,
      outIpAddress: outIpAddress ?? this.outIpAddress,
    );
  }

  @override
  Map<String, dynamic> toVals() => {
    'id': id,
    'employee_id': employee.toVals(),
    'check_in': _dateToOdooString(checkIn),
    'check_out': checkOut == null ? null : _dateToOdooString(checkOut!),
    'worked_hours': workedHours,

    // ✅ missing fields
    'validated_overtime_hours': validatedOvertimeHours,
    'in_latitude': inLatitude,
    'in_longitude': inLongitude,
    'out_latitude': outLatitude,
    'out_longitude': outLongitude,
    'in_ip_address': inIpAddress,
    'out_ip_address': outIpAddress,
  };

  @override
  Map<String, dynamic> toJson() => toVals();

  static AttendanceRecord fromJson(Map<dynamic, dynamic> json) {
    return AttendanceRecord(
      id: _parseInt(json['id']),
      employee: _parseEmployee(json['employee_id']),
      checkIn: _parseDateTimeRequired(json['check_in']),
      checkOut: _parseDateTimeNullable(json['check_out']),
      workedHours: _parseDouble(json['worked_hours']),

      // ✅ missing fields
      validatedOvertimeHours: _parseDoubleNullable(json['validated_overtime_hours']),
      inLatitude: _parseDoubleNullable(json['in_latitude']),
      inLongitude: _parseDoubleNullable(json['in_longitude']),
      outLatitude: _parseDoubleNullable(json['out_latitude']),
      outLongitude: _parseDoubleNullable(json['out_longitude']),
      inIpAddress: _parseStringNullable(json['in_ip_address']),
      outIpAddress: _parseStringNullable(json['out_ip_address']),
    );
  }

  // ----------------- helpers -----------------

  static int _parseInt(dynamic v) {
    if (v is int) return v;
    if (v is String) return int.tryParse(v) ?? 0;
    return 0;
  }

  static EmployeeRecord _parseEmployee(dynamic raw) {
    if (raw == null || raw == false) {
      return const EmployeeRecord(id: 0, name: '');
    }

    // Nested: {'id':..., 'name':...}
    if (raw is Map) {
      return EmployeeRecord.fromJson(raw as Map<dynamic, dynamic>);
    }

    // Many2one: [id, "Name"]
    if (raw is List && raw.length >= 2) {
      final id = raw[0] is int ? raw[0] as int : int.tryParse(raw[0].toString()) ?? 0;
      final name = (raw[1] ?? '').toString();
      return EmployeeRecord(id: id, name: name);
    }

    return const EmployeeRecord(id: 0, name: '');
  }

  static String? _parseStringNullable(dynamic value) {
    if (value == null || value == false) return null;
    final s = value.toString().trim();
    return s.isEmpty ? null : s;
  }

  static double _parseDouble(dynamic value) {
    if (value == null || value == false) return 0.0;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }

  static double? _parseDoubleNullable(dynamic value) {
    if (value == null || value == false) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  /// Parse Odoo datetime ('YYYY-MM-DD HH:MM:SS') and return LOCAL time
  static DateTime _parseDateTimeRequired(dynamic value) {
    final dt = _parseDateTimeNullable(value);
    return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
  }

  static DateTime? _parseDateTimeNullable(dynamic value) {
    if (value == null || value == false) return null;
    if (value is DateTime) return value;

    if (value is String && value.isNotEmpty) {
      // Odoo: 'YYYY-MM-DD HH:MM:SS' (usually UTC)
      final base = value.replaceFirst(' ', 'T'); // 2025-12-03T05:32:00
      final utc = DateTime.tryParse('${base}Z');
      if (utc == null) return null;

      final local = utc.toLocal();
      debugPrint('Attendance parseDateTime raw=$value -> utc=$utc -> local=$local');
      return local;
    }
    return null;
  }

  static String _dateToOdooString(DateTime value) {
    final v = value.toUtc();
    return v.toIso8601String().replaceFirst('T', ' ').split('.').first;
  }
}

/// Nested record for hr.employee (employee_id)
class EmployeeRecord extends Equatable {
  final int id;
  final String name;

  const EmployeeRecord({
    required this.id,
    required this.name,
  });

  @override
  List<Object?> get props => [id, name];

  Map<String, dynamic> toVals() => {'id': id, 'name': name};

  static EmployeeRecord fromJson(Map<dynamic, dynamic> json) {
    return EmployeeRecord(
      id: json['id'] as int? ?? 0,
      name: json['name'] as String? ?? '',
    );
  }
}
