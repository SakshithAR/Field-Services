import 'package:field_service/l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import 'attendance_record.dart';

class AttendanceDetailsPage extends StatelessWidget {
  final AttendanceRecord record;

  const AttendanceDetailsPage({super.key, required this.record});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    final isClosed = record.checkOut != null;

    return Scaffold(
      backgroundColor: theme.colorScheme.surfaceContainerLowest,
      appBar: AppBar(
        title: Text(l10n.attDetailsTitle),
        centerTitle: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // -------------------------------------------------------
            // 1. Header Card (Employee & Summary)
            // -------------------------------------------------------
            Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: theme.colorScheme.outlineVariant),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    // Employee Info
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 24,
                          backgroundColor: theme.colorScheme.primaryContainer,
                          child: Text(
                            record.employee.name.isNotEmpty
                                ? record.employee.name[0].toUpperCase()
                                : "#",
                            style: TextStyle(
                              color: theme.colorScheme.onPrimaryContainer,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                l10n.attEmployeeLabel,
                                style: theme.textTheme.labelMedium?.copyWith(
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                              Text(
                                record.employee.name.isNotEmpty
                                    ? record.employee.name
                                    : l10n.employeeFallback(record.employee.id.toString()),
                                style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Status Chip
                        _StatusBadge(isOpen: !isClosed),
                      ],
                    ),
                    const Divider(height: 32),

                    // Stats Row
                    IntrinsicHeight(
                      child: Row(
                        children: [
                          _StatItem(
                            label: l10n.attWorkedTimeLabel,
                            value: "${record.workedHours.toStringAsFixed(2)} hrs",
                            icon: Icons.timer_outlined,
                          ),
                          const VerticalDivider(),
                          _StatItem(
                            label: l10n.attExtraHoursLabel,
                            value: _formatOvertime(l10n, record.validatedOvertimeHours),
                            icon: Icons.more_time_rounded,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            // -------------------------------------------------------
            // 2. Check In Section
            // -------------------------------------------------------
            _SectionHeader(title: l10n.attCheckInSection),
            const SizedBox(height: 8),
            _DetailCard(
              time: record.checkIn,
              ipAddress: record.inIpAddress,
              lat: record.inLatitude,
              long: record.inLongitude,
              isCheckIn: true,
            ),

            const SizedBox(height: 24),

            // -------------------------------------------------------
            // 3. Check Out Section
            // -------------------------------------------------------
            _SectionHeader(title: l10n.attCheckOutSection),
            const SizedBox(height: 8),
            if (record.checkOut != null)
              _DetailCard(
                time: record.checkOut!,
                ipAddress: record.outIpAddress,
                lat: record.outLatitude,
                long: record.outLongitude,
                isCheckIn: false,
              )
            else
              _MissingCheckoutCard(),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  String _formatOvertime(AppLocalizations l10n, double? val) {
    if (val == null) return "00:00";
    return "${val.toStringAsFixed(2)} hrs";
  }
}

// ---------------------------------------------------------------------------
// 🧩 Helper Widgets
// ---------------------------------------------------------------------------

class _DetailCard extends StatelessWidget {
  final DateTime time;
  final String? ipAddress;
  final double? lat;
  final double? long;
  final bool isCheckIn;

  const _DetailCard({
    required this.time,
    required this.ipAddress,
    required this.lat,
    required this.long,
    required this.isCheckIn,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    final dateFormat = DateFormat("MM/dd/yyyy HH:mm:ss"); // e.g. "MM/dd/yyyy HH:mm:ss"
    final formattedDate = dateFormat.format(time);

    final ipText = (ipAddress == null || ipAddress!.trim().isEmpty)
        ? l10n.attUnknownValue
        : ipAddress!.trim();

    final gpsText = (lat != null && long != null)
        ? "${lat!.toStringAsFixed(6)} , ${long!.toStringAsFixed(6)}"
        : l10n.attNotAvailableValue;

    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        children: [
          // Top strip with Time
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainer,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: Row(
              children: [
                Icon(
                  isCheckIn ? Icons.login_rounded : Icons.logout_rounded,
                  size: 20,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 12),
                Text(
                  formattedDate,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _DetailRow(
                  label: l10n.attIpAddressLabel,
                  value: ipText,
                ),
                const SizedBox(height: 12),
                _DetailRow(
                  label: l10n.attGpsCoordinatesLabel,
                  value: gpsText,
                ),
                if (lat != null && long != null) ...[
                  const SizedBox(height: 16),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final url =
                            'https://www.google.com/maps/search/?api=1&query=$lat,$long';
                        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
                      },
                      icon: const Icon(Icons.map_outlined, size: 18),
                      label: Text(l10n.attViewOnMaps),
                      style: OutlinedButton.styleFrom(
                        visualDensity: VisualDensity.compact,
                      ),
                    ),
                  )
                ]
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;

  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 120,
          child: Text(
            label,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }
}

class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _StatItem({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: theme.colorScheme.primary, size: 20),
          const SizedBox(height: 4),
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final bool isOpen;
  const _StatusBadge({required this.isOpen});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    final color = isOpen ? theme.colorScheme.tertiary : theme.colorScheme.secondary;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Text(
        isOpen ? l10n.statusOpen : l10n.statusClosed,
        style: theme.textTheme.labelSmall?.copyWith(
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Text(
      title,
      style: theme.textTheme.labelLarge?.copyWith(
        color: theme.colorScheme.onSurfaceVariant,
        fontWeight: FontWeight.bold,
        letterSpacing: 1.2,
      ),
    );
  }
}

class _MissingCheckoutCard extends StatelessWidget {
  const _MissingCheckoutCard();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    return Card(
      elevation: 0,
      color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.3),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: theme.colorScheme.outlineVariant.withOpacity(0.5)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            children: [
              Icon(Icons.hourglass_empty_rounded,
                  color: theme.colorScheme.onSurfaceVariant),
              const SizedBox(height: 8),
              Text(
                l10n.attNotCheckedOutYet,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
