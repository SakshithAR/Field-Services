import 'package:flutter/material.dart';
import 'package:field_service/l10n/app_localizations.dart';

import 'package:field_service/src/attendance/attendance_home.dart';
import 'attendance_list_page.dart';

class AttendanceMainPage extends StatefulWidget {
  const AttendanceMainPage({super.key});

  @override
  State<AttendanceMainPage> createState() => _AttendanceMainPageState();
}

class _AttendanceMainPageState extends State<AttendanceMainPage> {
  int _index = 0;

  late final List<Widget> _pages = const [
    AttendanceActionPage(),
    AttendanceListPage(),
  ];

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: _pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        height: 70,
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.how_to_reg_rounded),
            selectedIcon: const Icon(Icons.how_to_reg_rounded),
            label: l10n.attNavAttendance, // ✅ localized
          ),
          NavigationDestination(
            icon: const Icon(Icons.list_alt_rounded),
            selectedIcon: const Icon(Icons.list_alt_rounded),
            label: l10n.attNavHistory, // ✅ localized
          ),
        ],
      ),
    );
  }
}
