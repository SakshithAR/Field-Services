import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui';

import 'package:field_service/src/features/profile_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import 'package:field_service/l10n/app_localizations.dart';
import 'package:field_service/src/odoo/odoo_repository/lib/odoo_repository.dart';

import 'attendance_record.dart';
import 'attendance_repository.dart';

class AttendanceActionPage extends StatefulWidget {
  const AttendanceActionPage({super.key});

  @override
  State<AttendanceActionPage> createState() => _AttendanceActionPageState();
}

class _AttendanceActionPageState extends State<AttendanceActionPage>
    with TickerProviderStateMixin {
  late AttendanceRepository _repo;

  AttendanceRecord? _open;
  bool _busy = false;
  bool _gettingLocation = false;

  Timer? _timer;
  Duration _sinceCheckIn = Duration.zero;

  // GPS Data
  Position? _currentPos;
  String? _currentAddress;

  // Animations
  late AnimationController _fadeController;

  final ImagePicker _picker = ImagePicker();
  Uint8List? _lastSelfieBytes;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    final env = context.read<OdooEnvironment>();
    env.add(AttendanceRepository(env));
    _repo = env.of<AttendanceRepository>();

    _initLoad();
  }

  Future<void> _initLoad() async {
    await _loadOpen();
    unawaited(_refreshLocation(silent: true));
    _fadeController.forward();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> _loadOpen() async {
    setState(() => _busy = true);
    try {
      final open = await _repo.getOpenAttendance();
      _open = open;

      _timer?.cancel();
      if (_open != null) {
        _startTimer(_open!.checkIn);
      } else {
        _sinceCheckIn = Duration.zero;
      }
    } catch (e) {
      _showError(e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _startTimer(DateTime checkInLocal) {
    void tick() {
      final now = DateTime.now();
      final diff = now.difference(checkInLocal);
      if (!mounted) return;
      setState(() => _sinceCheckIn = diff.isNegative ? Duration.zero : diff);
    }

    tick();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => tick());
  }

  Future<void> _refreshLocation({bool silent = false}) async {
    if (_gettingLocation) return;

    if (!silent) setState(() => _gettingLocation = true);

    try {
      final l10n = AppLocalizations.of(context)!;

      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) {
        throw Exception(l10n.locationServicesDisabled);
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        throw Exception(l10n.locationPermissionDenied);
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 10),
      );

      final addr = await _reverseGeocode(pos.latitude, pos.longitude);

      if (!mounted) return;
      setState(() {
        _currentPos = pos;
        _currentAddress = addr;
      });
    } catch (e) {
      if (!silent) _showError(e.toString());
    } finally {
      if (mounted) setState(() => _gettingLocation = false);
    }
  }

  Future<String?> _reverseGeocode(double lat, double lng) async {
    try {
      final placemarks = await placemarkFromCoordinates(lat, lng);
      if (placemarks.isEmpty) return null;
      final p = placemarks.first;

      final parts = <String>[
        if ((p.street ?? '').isNotEmpty) p.street!,
        if ((p.subLocality ?? '').isNotEmpty) p.subLocality!,
        if ((p.locality ?? '').isNotEmpty) p.locality!,
      ];

      return parts.isEmpty ? null : parts.join(', ');
    } catch (_) {
      return null;
    }
  }

  Future<void> _handleSwipeAction() async {
    HapticFeedback.mediumImpact();
    final l10n = AppLocalizations.of(context)!;

    if (_currentPos == null) {
      await _refreshLocation();
      if (_currentPos == null) {
        _showError(l10n.attendanceLocationRequired);
        return;
      }
    }

    setState(() => _busy = true);

    try {
      if (_open == null) {
        // CHECK IN
        await _repo.checkInWithGps(
          latitude: _currentPos!.latitude,
          longitude: _currentPos!.longitude,
          inLocation: _currentAddress,
        );
        if (mounted) _showSuccess(l10n.attendanceCheckInSuccess);
      } else {
        // CHECK OUT
        await _repo.checkOutWithGps(
          attendanceId: _open!.id,
          latitude: _currentPos!.latitude,
          longitude: _currentPos!.longitude,
          outLocation: _currentAddress,
        );
        if (mounted) _showSuccess(l10n.attendanceCheckOutSuccess);
      }

      await _loadOpen();
    } catch (e) {
      _showError(e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<String?> _captureSelfieBase64() async {
    final l10n = AppLocalizations.of(context)!;

    try {
      final x = await _picker.pickImage(
        source: ImageSource.camera,
        preferredCameraDevice: CameraDevice.front,
        imageQuality: 82,
        maxWidth: 1080,
      );
      if (x == null) return null;

      final bytes = await x.readAsBytes();
      if (mounted) setState(() => _lastSelfieBytes = bytes);

      return base64Encode(bytes);
    } catch (e) {
      _showError("${l10n.attendanceCameraError}: $e");
      return null;
    }
  }

  Future<void> _takeAndUploadSelfie() async {
    if (_busy) return;
    final l10n = AppLocalizations.of(context)!;

    final attendanceId = _open?.id;
    if (attendanceId == null) {
      _showError(l10n.attendanceCheckInFirst);
      return;
    }

    try {
      final base64 = await _captureSelfieBase64();
      if (base64 == null) return;

      setState(() => _busy = true);

      await _repo.addSelfieAttachment(
        attendanceId: attendanceId,
        base64Image: base64,
        fileName: "selfie_${DateTime.now().millisecondsSinceEpoch}.jpg",
      );

      if (!mounted) return;
      _showSuccess(l10n.attendanceSelfieUploaded);
    } catch (e) {
      _showError("${l10n.attendanceUploadFailed}: $e");
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showError(String msg) {
    final theme = Theme.of(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.error_outline, color: theme.colorScheme.onError),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                msg,
                style: TextStyle(color: theme.colorScheme.onError),
              ),
            ),
          ],
        ),
        backgroundColor: theme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showSuccess(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: Colors.green.shade700,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;

    final isOpen = _open != null;

    final activeColor = isOpen
        ? (isDark ? const Color(0xFFFFB74D) : Colors.orange.shade800)
        : (isDark ? const Color(0xFF4DB6AC) : const Color(0xFF00BFA6));

    final bgStart = isOpen
        ? (isDark ? const Color(0xFF4E342E) : Colors.orange.shade50)
        : (isDark ? const Color(0xFF004D40) : const Color(0xFFE0F7FA));

    final bgEnd = isDark ? colorScheme.surface : Colors.white;

    return Scaffold(
      backgroundColor: bgEnd,
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [bgStart, bgEnd],
                  stops: const [0.0, 0.5],
                ),
              ),
            ),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _fadeController,
              child: Column(
                children: [
                  _buildHeader(theme, isOpen, l10n),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        children: [
                          const SizedBox(height: 20),
                          _buildTimerCard(theme, isOpen, activeColor, isDark, l10n),
                          const SizedBox(height: 16),
                          _buildLocationCard(theme, isDark, l10n),
                          const SizedBox(height: 120),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 30),
              decoration: BoxDecoration(
                color: isDark ? colorScheme.surfaceContainer : Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(isDark ? 0.3 : 0.05),
                    blurRadius: 20,
                    offset: const Offset(0, -5),
                  ),
                ],
                borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: SafeArea(
                child: ModernSwipeButton(
                  isCheckIn: !isOpen,
                  isLoading: _busy,
                  enabled: !_busy,
                  onSwipe: _handleSwipeAction,
                  color: activeColor,
                  isDark: isDark,
                  label: isOpen ? l10n.attendanceSwipeToCheckOut : l10n.attendanceSwipeToCheckIn,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(ThemeData theme, bool isOpen, AppLocalizations l10n) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                DateFormat('EEEE, d MMMM').format(DateTime.now()),
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                isOpen ? l10n.attendanceOnDuty : l10n.attendanceOffDuty,
                style: theme.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                  color: theme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ProfilePage()),
              );
            },
            child: Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: theme.colorScheme.outlineVariant,
                  width: 2,
                ),
              ),
              child: CircleAvatar(
                radius: 22,
                backgroundColor: theme.colorScheme.surfaceContainerHighest,
                child: Icon(Icons.person, color: theme.colorScheme.onSurfaceVariant),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimerCard(
      ThemeData theme,
      bool isOpen,
      Color activeColor,
      bool isDark,
      AppLocalizations l10n,
      ) {
    final timeStr = _fmtHMS(_sinceCheckIn);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: isDark ? theme.colorScheme.surfaceContainer : Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          if (!isDark)
            BoxShadow(
              color: activeColor.withOpacity(0.15),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
        ],
        border: Border.all(
          color: isDark ? activeColor.withOpacity(0.3) : activeColor.withOpacity(0.1),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Icon(
            isOpen ? Icons.timer_outlined : Icons.coffee_outlined,
            size: 40,
            color: activeColor,
          ),
          const SizedBox(height: 16),
          Text(
            isOpen ? timeStr : "--:--:--",
            style: TextStyle(
              fontSize: 42,
              fontWeight: FontWeight.w700,
              fontFeatures: const [FontFeature.tabularFigures()],
              color: theme.colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            isOpen ? l10n.attendanceStartedAt(_fmtTime(_open!.checkIn)) : l10n.attendanceReadyToStart,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLocationCard(ThemeData theme, bool isDark, AppLocalizations l10n) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? theme.colorScheme.surfaceContainerHigh : Colors.grey.shade50,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: theme.colorScheme.outlineVariant.withOpacity(0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.location_on_rounded, size: 18, color: theme.colorScheme.primary),
              const SizedBox(width: 8),
              Text(
                l10n.attendanceCurrentLocation,
                style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
              ),
              const Spacer(),
              if (_gettingLocation)
                SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: theme.colorScheme.primary,
                  ),
                )
              else
                InkWell(
                  onTap: () => _refreshLocation(),
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.all(6.0),
                    child: Text(
                      l10n.attendanceRefresh,
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: theme.colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const Divider(height: 24),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _currentAddress ?? l10n.attendanceFetchingAddress,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurface,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _currentPos == null
                          ? l10n.attendanceWaitingForGps
                          : l10n.attendanceLatLng(
                        _currentPos!.latitude.toStringAsFixed(4),
                        _currentPos!.longitude.toStringAsFixed(4),
                      ),
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton.filledTonal(
                tooltip: l10n.attendanceUploadSelfie,
                onPressed: _busy ? null : _takeAndUploadSelfie,
                icon: const Icon(Icons.camera_alt_rounded),
                style: IconButton.styleFrom(
                  backgroundColor: theme.colorScheme.surfaceContainerHighest,
                  foregroundColor: theme.colorScheme.primary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _fmtHMS(Duration d) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    final mm = twoDigits(d.inMinutes.remainder(60));
    final ss = twoDigits(d.inSeconds.remainder(60));
    return "${twoDigits(d.inHours)}:$mm:$ss";
  }

  String _fmtTime(DateTime dt) => DateFormat('h:mm a').format(dt);
}

class ModernSwipeButton extends StatefulWidget {
  final bool isCheckIn;
  final bool isLoading;
  final bool enabled;
  final VoidCallback onSwipe;
  final Color color;
  final bool isDark;
  final String label;

  const ModernSwipeButton({
    super.key,
    required this.isCheckIn,
    required this.isLoading,
    required this.enabled,
    required this.onSwipe,
    required this.color,
    required this.isDark,
    required this.label,
  });

  @override
  State<ModernSwipeButton> createState() => _ModernSwipeButtonState();
}

class _ModernSwipeButtonState extends State<ModernSwipeButton> {
  double _dragValue = 0.0;
  final double _height = 60.0;
  final double _padding = 4.0;

  @override
  Widget build(BuildContext context) {
    final icon = widget.isCheckIn ? Icons.arrow_forward : Icons.stop_rounded;
    final trackColor = widget.color.withOpacity(widget.isDark ? 0.2 : 0.1);
    final borderColor = widget.color.withOpacity(0.3);

    return LayoutBuilder(
      builder: (context, constraints) {
        final maxWidth = constraints.maxWidth;
        final knobSize = _height - (_padding * 2);
        final maxDrag = maxWidth - knobSize - (_padding * 2);

        return Container(
          height: _height,
          decoration: BoxDecoration(
            color: trackColor,
            borderRadius: BorderRadius.circular(100),
            border: Border.all(color: borderColor),
          ),
          child: Stack(
            children: [
              Center(
                child: widget.isLoading
                    ? SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation(widget.color),
                  ),
                )
                    : Opacity(
                  opacity: (1 - (_dragValue / maxDrag)).clamp(0.0, 1.0),
                  child: Text(
                    widget.label,
                    style: TextStyle(
                      color: widget.color,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: _padding + _dragValue,
                top: _padding,
                child: GestureDetector(
                  onHorizontalDragUpdate: widget.enabled
                      ? (details) {
                    setState(() {
                      _dragValue =
                          (_dragValue + details.delta.dx).clamp(0.0, maxDrag);
                    });
                  }
                      : null,
                  onHorizontalDragEnd: widget.enabled
                      ? (details) {
                    if (_dragValue > maxDrag * 0.7) {
                      widget.onSwipe();
                      setState(() => _dragValue = maxDrag);
                      Future.delayed(const Duration(milliseconds: 200), () {
                        if (mounted) setState(() => _dragValue = 0);
                      });
                    } else {
                      setState(() => _dragValue = 0.0);
                    }
                  }
                      : null,
                  child: Container(
                    height: knobSize,
                    width: knobSize,
                    decoration: BoxDecoration(
                      color: widget.color,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: widget.color.withOpacity(0.4),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        )
                      ],
                    ),
                    child: Icon(icon, color: Colors.white),
                  ),
                ),
              )
            ],
          ),
        );
      },
    );
  }
}
