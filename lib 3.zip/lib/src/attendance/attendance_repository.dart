  import 'dart:convert';
  import 'package:flutter/foundation.dart' show debugPrint;
  import 'dart:convert';
  import 'package:http/http.dart' as http;
  import 'package:network_info_plus/network_info_plus.dart';
  import '../odoo/odoo_repository/lib/src/odoo_environment.dart';
  import '../odoo/odoo_repository/lib/src/odoo_repository.dart';
  import 'attendance_record.dart';

  /// Repository for Odoo model: `hr.attendance`
  class AttendanceRepository extends OdooRepository<AttendanceRecord> {
    @override
    final String modelName = 'hr.attendance';

    /// Fields & nested relations to fetch
    Map<String, dynamic> specification = {
      'id': {},
      'employee_id': {
        'fields': {
          'id': {},
          'name': {},
        }
      },
      'check_in': {},
      'check_out': {},
      'worked_hours': {},
      'validated_overtime_hours': {},
      'in_latitude': {},
      'in_longitude': {},
      'out_latitude': {},
      'out_longitude': {},
      'in_ip_address': {},
      'out_ip_address': {},
    };

    AttendanceRepository(OdooEnvironment odoo) : super(odoo);

    @override
    AttendanceRecord createRecordFromJson(Map<String, dynamic> json) {
      return AttendanceRecord.fromJson(json);
    }

    /// Get latest OPEN attendance for an employee (check_out = false)
    Future<AttendanceRecord?> getOpenAttendance() async {
      final result = await env.orpc.callKw({
        'model': modelName,
        'method': 'search_read',
        'args': [
          [
            ['check_out', '=', false],
          ],
          ['id', 'employee_id', 'check_in', 'check_out', 'worked_hours'],
        ],
        'kwargs': {'limit': 1, 'order': 'check_in desc'},
      });

      if (result is List && result.isNotEmpty) {
        return AttendanceRecord.fromJson(result.first as Map<dynamic, dynamic>);
      }
      return null;
    }

    /// Create CHECK-IN (new attendance row)
    Future<int> checkIn({
      DateTime? at,
    }) async {
      final dt = at ?? DateTime.now();
      final vals = {
        'check_in': _formatOdooDateTime(dt),
      };

      debugPrint('✅ checkIn vals: ${jsonEncode(vals)}');

      final res = await env.orpc.callKw({
        'model': modelName,
        'method': 'create',
        'args': [vals],
        'kwargs': {},
      });

      if (res is int) return res;
      if (res is List && res.isNotEmpty) return res.first as int;
      throw Exception('Unexpected result from hr.attendance create: $res');
    }

    /// Set CHECK-OUT for an existing attendance row
    Future<void> checkOut({
      required int attendanceId,
      DateTime? at,
    }) async {
      final dt = at ?? DateTime.now();
      final vals = {'check_out': _formatOdooDateTime(dt)};

      debugPrint('✅ checkOut attendanceId=$attendanceId vals: ${jsonEncode(vals)}');

      await env.orpc.callKw({
        'model': modelName,
        'method': 'write',
        'args': [
          [attendanceId],
          vals,
        ],
        'kwargs': {},
      });
    }

    /// Fetch recent attendances for an employee (limit)
    Future<List<AttendanceRecord>> fetchRecent({
      required int employeeId,
      int limit = 20,
    }) async {
      final result = await env.orpc.callKw({
        'model': modelName,
        'method': 'search_read',
        'args': [
          [
            ['employee_id', '=', employeeId],
          ],
          ['id', 'employee_id', 'check_in', 'check_out', 'worked_hours'],
        ],
        'kwargs': {'limit': limit, 'order': 'check_in desc'},
      });

      if (result is! List) return [];
      return result
          .whereType<Map>()
          .map((e) => AttendanceRecord.fromJson(e as Map<dynamic, dynamic>))
          .toList();
    }

    /// Helper: Odoo datetime 'YYYY-MM-DD HH:MM:SS' (UTC)
    String _formatOdooDateTime(DateTime dt) {
      final utc = dt.toUtc();
      final y = utc.year.toString().padLeft(4, '0');
      final m = utc.month.toString().padLeft(2, '0');
      final d = utc.day.toString().padLeft(2, '0');
      final h = utc.hour.toString().padLeft(2, '0');
      final min = utc.minute.toString().padLeft(2, '0');
      final s = utc.second.toString().padLeft(2, '0');
      return '$y-$m-$d $h:$min:$s';
    }

    Future<List<AttendanceRecord>> fetchAttendancesPageWithSpecification({
      required int pageKey, // 0-based page index
      required int pageSize,
      String? status, // null | "open" | "closed"
      DateTime? dateFrom,
      DateTime? dateTo,
      int? employeeId,
    }) async {
      final domain = <dynamic>[];

      if (employeeId != null && employeeId > 0) {
        domain.add(['employee_id', '=', employeeId]);
      }

      if (status == "open") {
        domain.add(['check_out', '=', false]);
      } else if (status == "closed") {
        domain.add(['check_out', '!=', false]);
      }

      if (dateFrom != null) {
        domain.add(['check_in', '>=', _formatOdooDateTime(dateFrom)]);
      }
      if (dateTo != null) {
        domain.add(['check_in', '<=', _formatOdooDateTime(dateTo)]);
      }

      final offset = pageKey * pageSize;

      try {
        final response = await env.orpc.callKw({
          'model': modelName,
          'method': 'web_search_read',
          'args': [],
          'kwargs': {
            'context': {
              'bin_size': true,
              'lang': env.orpc.sessionId?.userLang ?? 'en_US',
            },
            'domain': domain,
            // ✅ USE SPECIFICATION ITSELF (like OdooRepository.searchRead)
            'specification': specification,
            'limit': pageSize,
            'offset': offset,
            'order': order.isNotEmpty ? order : 'check_in desc',
          },
        });

        if (response is! Map) return [];

        // same behavior as base repo
        final length = response['length'];
        if (length is int) {
          remoteRecordsCount = length;
        }

        final records = response['records'];
        if (records is! List) return [];

        return records
            .whereType<Map>()
            .map((e) => AttendanceRecord.fromJson(e as Map<dynamic, dynamic>))
            .toList();
      } catch (e) {
        debugPrint('fetchAttendancesPageWithSpecification web_search_read error: $e');
        return [];
      }
    }


    // --- GPS field names (match your Odoo fields) ---
    static const String fInLat = 'in_latitude';
    static const String fInLng = 'in_longitude';
    //static const String fInAlt = 'in_altitude';
    static const String fOutLat = 'out_latitude';
    static const String fOutLng = 'out_longitude';
    //static const String fOutAlt = 'out_altitude';

  /*  Future<int> checkInWithGps({
      required double latitude,
      required double longitude,
      String? inLocation,
      DateTime? at,
    }) async {
      final attendanceId = await checkIn(at: at);

      final ip = await getBestIp();

      final vals = <String, dynamic>{
        fInLat: latitude,
        fInLng: longitude,
        'in_browser': 'Mobile App',
        'in_mode': 'kiosk',
        'in_ip_address': ip,
      };

      // Only send these fields if server > 18 (and your module adds these fields)
      if (_isV19Plus) {
        vals.addAll({
          'device_tracking_enabled': true,
          if (inLocation != null) 'in_location': inLocation,
        });
      }

      await env.orpc.callKw({
        'model': modelName,
        'method': 'write',
        'args': [
          [attendanceId],
          vals,
        ],
        'kwargs': {},
      });

      return attendanceId;
    }


    Future<void> checkOutWithGps({
      required int attendanceId,
      required double latitude,
      required double longitude,
      String? outLocation,
      DateTime? at,
    }) async {
      final dt = at ?? DateTime.now();

      final ip = await getBestIp();

      final vals = <String, dynamic>{
        'check_out': _formatOdooDateTime(dt),
        'out_browser': 'Mobile App',
        'out_mode': 'kiosk',
        'out_ip_address': ip,
        fOutLat: latitude,
        fOutLng: longitude,
      };

      // Only send these fields if server > 18
      if (_isV19Plus) {
        vals.addAll({
          'device_tracking_enabled': true,
          if (outLocation != null) 'out_location': outLocation,
        });
      }

      await env.orpc.callKw({
        'model': modelName,
        'method': 'write',
        'args': [
          [attendanceId],
          vals,
        ],
        'kwargs': {},
      });
    }*/


    Future<int> addSelfieAttachment({
      required int attendanceId,
      required String base64Image, // raw base64 (no data:image/... prefix)
      required String fileName,    // eg: selfie_checkin.jpg
    }) async {
      final res = await env.orpc.callKw({
        'model': 'ir.attachment',
        'method': 'create',
        'args': [
          {
            'name': fileName,
            'type': 'binary',
            'datas': base64Image,
            'mimetype': 'image/jpeg',
            'res_model': modelName, // should be 'hr.attendance'
            'res_id': attendanceId,
          }
        ],
        'kwargs': {},
      });

      if (res is int) return res;
      return int.tryParse(res.toString()) ?? 0;
    }

    bool get _isV19Plus => _serverMajorVersion() >= 19;

    int _serverMajorVersion() {
      final v = env.orpc.sessionId?.serverVersion; // can be null

      if (v == null || v.trim().isEmpty) return 0;

      // Handles: "18", "18.0", "18.0+e", "19.1", etc.
      final m = RegExp(r'(\d+)').firstMatch(v);
      return m == null ? 0 : int.tryParse(m.group(1)!) ?? 0;
    }


    Future<String?> getBestIp() async {
      final publicIp = await getPublicIp();
      if (publicIp != null) return publicIp;

      final localIp = await getLocalWifiIp();
      return localIp;
    }

    Future<String?> getLocalWifiIp() async {
      try {
        final info = NetworkInfo();
        return await info.getWifiIP(); // e.g. 192.168.1.20
      } catch (_) {
        return null;
      }
    }

    Future<String?> getPublicIp() async {
      try {
        final res = await http
            .get(Uri.parse('https://api.ipify.org?format=json'))
            .timeout(const Duration(seconds: 6));

        if (res.statusCode != 200) return null;

        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final ip = (data['ip'] ?? '').toString().trim();
        return ip.isEmpty ? null : ip;
      } catch (_) {
        return null;
      }
    }


    // ---------------------------------------------------------------------------
    // ✅ Controller routes (your custom module)
    // ---------------------------------------------------------------------------
    static const String _routeCheckIn  = '/taqnix_attendance/api/attendance/check_in';
    static const String _routeCheckOut = '/taqnix_attendance/api/attendance/check_out';

    /// Build base URL from your Odoo connection.
    /// Adjust this getter based on how your env/orpc exposes server URL.
    String get _baseUrl {
      // Common patterns:
      // - env.orpc.baseUrl
      // - env.baseUrl
      // - env.orpc.url
      final any = (env as dynamic);
      final orpc = any.orpc;

      final url = env.orpc.baseURL;

      if (url == null || url.isEmpty) {
        throw Exception('Odoo base URL not found in env/orpc. Please expose it.');
      }
      return url.endsWith('/') ? url.substring(0, url.length - 1) : url;
    }

    /// Get Odoo session cookie from your authenticated session.
    /// Adjust if your session storage uses a different property name.
    String? get _sessionId {
      final s = env.orpc.sessionId;
      if (s == null) return null;

      // Try common fields:
      final dyn = (s as dynamic);
      return dyn.id.toString();
    }

    Map<String, String> _headers() {
      final sid = _sessionId;
      if (sid == null || sid.isEmpty) {
        throw Exception('No active Odoo session. Please login first.');
      }

      return {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        // Odoo session cookie
        'Cookie': 'session_id=$sid',
      };
    }

    /// Odoo "type=json" controller expects JSON-RPC envelope.
    Future<Map<String, dynamic>> _postJsonController(
        String route,
        Map<String, dynamic> params,
        ) async {
      final uri = Uri.parse('$_baseUrl$route');

      final payload = {
        "jsonrpc": "2.0",
        "method": "call",
        "params": params,
        "id": DateTime.now().millisecondsSinceEpoch,
      };

      debugPrint('➡️ POST $uri');
      debugPrint('➡️ params: ${jsonEncode(params)}');

      final res = await http
          .post(uri, headers: _headers(), body: jsonEncode(payload))
          .timeout(const Duration(seconds: 20));

      debugPrint('⬅️ status=${res.statusCode} body=${res.body}');

      if (res.statusCode != 200) {
        throw Exception('HTTP ${res.statusCode}: ${res.body}');
      }

      final decoded = jsonDecode(res.body);
      if (decoded is! Map) throw Exception('Invalid JSON response: ${res.body}');

      // Odoo JSON controllers return: {jsonrpc, id, result} OR {error}
      if (decoded['error'] != null) {
        final err = decoded['error'];
        throw Exception(err is Map ? (err['data']?['message'] ?? err.toString()) : err.toString());
      }

      final result = decoded['result'];
      if (result is Map<String, dynamic>) return result;
      if (result is Map) return result.map((k, v) => MapEntry(k.toString(), v));
      throw Exception('Unexpected controller result: $result');
    }

    // ---------------------------------------------------------------------------
    // ✅ CHECK-IN / CHECK-OUT using controller (self employee only)
    // ---------------------------------------------------------------------------

    Future<int> checkInWithGps({
      required double latitude,
      required double longitude,
      String? inLocation,
      DateTime? at,
    }) async {
      final ip = await getBestIp();

      // ✅ Do NOT send employee_id. Controller derives it from logged-in user.
      final params = <String, dynamic>{
        if (at != null) 'check_in': _formatOdooDateTime(at),
        'in_latitude': latitude,
        'in_longitude': longitude,
        if (inLocation != null) 'in_location': inLocation,
        if (ip != null) 'in_ip_address': ip,
        'in_browser': 'Mobile App',
        'in_mode': 'kiosk',
        // optionally:
        'device_tracking_enabled': true,
      };

      final result = await _postJsonController(_routeCheckIn, params);

      if (result['success'] == true) {
        final id = result['attendance_id'];
        if (id is int) return id;
        return int.tryParse(id.toString()) ?? 0;
      }

      throw Exception(result['error']?.toString() ?? 'Check-in failed');
    }

    Future<void> checkOutWithGps({
      required int attendanceId,
      required double latitude,
      required double longitude,
      String? outLocation,
      DateTime? at,
    }) async {
      final ip = await getBestIp();

      final params = <String, dynamic>{
        'attendance_id': attendanceId,
        if (at != null) 'check_out': _formatOdooDateTime(at),
        'out_latitude': latitude,
        'out_longitude': longitude,
        if (outLocation != null) 'out_location': outLocation,
        if (ip != null) 'out_ip_address': ip,
        'out_browser': 'Mobile App',
        'out_mode': 'kiosk',
        'device_tracking_enabled': true,
      };

      final result = await _postJsonController(_routeCheckOut, params);

      if (result['success'] == true) return;

      throw Exception(result['error']?.toString() ?? 'Check-out failed');
    }

    // ✅ Like your JobRepository.callMethodOnJob
    Future<T> callModelMethod<T>(
        String method, {
          List<dynamic> args = const [],
          Map<String, dynamic> kwargs = const {},
        }) async {
      final params = {
        'model': modelName,
        'method': method,
        'args': args,
        'kwargs': kwargs,
      };

      debugPrint('🚀 callModelMethod: $method params: ${jsonEncode(params)}');
      final res = await env.orpc.callKw(params);

      return res as T;
    }

    // ---------------------------------------------------------------------------
    // ✅ self-only check-in (employee derived on server)
    // ---------------------------------------------------------------------------
    Future<int> checkInWithGpsByMethodCall({
      required double latitude,
      required double longitude,
      String? inLocation,
      DateTime? at,
    }) async {
      final ip = await getBestIp();

      final vals = <String, dynamic>{
        if (at != null) 'check_in': _formatOdooDateTime(at),
        'in_latitude': latitude,
        'in_longitude': longitude,
        if (inLocation != null) 'in_location': inLocation,
        if (ip != null) 'in_ip_address': ip,
        'in_browser': 'Mobile App',
        'in_mode': 'kiosk',
        'device_tracking_enabled': true,
      };

      final result = await callModelMethod<Map>(
        'taqnix_check_in',
        args: [vals], // ✅ method signature: taqnix_check_in(vals)
      );

      if (result['success'] == true) {
        final id = result['attendance_id'];
        if (id is int) return id;
        return int.tryParse(id.toString()) ?? 0;
      }

      throw Exception(result['error']?.toString() ?? 'Check-in failed');
    }

    // ---------------------------------------------------------------------------
    // ✅ self-only check-out
    // ---------------------------------------------------------------------------
    Future<void> checkOutWithGpsByMethodCall({
      required int attendanceId,
      required double latitude,
      required double longitude,
      String? outLocation,
      DateTime? at,
    }) async {
      final ip = await getBestIp();

      final vals = <String, dynamic>{
        if (at != null) 'check_out': _formatOdooDateTime(at),
        'out_latitude': latitude,
        'out_longitude': longitude,
        if (outLocation != null) 'out_location': outLocation,
        if (ip != null) 'out_ip_address': ip,
        'out_browser': 'Mobile App',
        'out_mode': 'kiosk',
        'device_tracking_enabled': true,
      };

      final result = await callModelMethod<Map>(
        'taqnix_check_out',
        args: [attendanceId, vals], // ✅ method signature: taqnix_check_out(attendance_id, vals)
      );

      if (result['success'] == true) return;

      throw Exception(result['error']?.toString() ?? 'Check-out failed');
    }

  }



