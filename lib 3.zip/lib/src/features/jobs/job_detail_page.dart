import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/cupertino.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_signaturepad/signaturepad.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'package:field_service/l10n/app_localizations.dart';
import '../../odoo/odoo_repository/lib/odoo_repository.dart';
import 'job_record.dart';
import 'job_repository.dart';

class JobDetailPage extends StatefulWidget {
  final JobRecord job;

  const JobDetailPage({
    Key? key,
    required this.job,
  }) : super(key: key);

  @override
  State<JobDetailPage> createState() => _JobDetailPageState();
}

enum _PhotoSource { camera, gallery }

class _JobDetailPageState extends State<JobDetailPage> {
  late JobRepository _jobRepo;
  late JobRecord _job;
  StreamSubscription<List<JobRecord>>? _sub;

  bool _isActionLoading = false;
  bool _isDownloadingPdf = false;

  final ImagePicker _picker = ImagePicker();
  bool _uploadingPhoto = false;

  // Variables for Materials & Invoicing
  List<dynamic> _products = [];

  // 🟢 ADDED: Local state to show the beautiful Chips immediately after selection
  List<Map<String, dynamic>> _locallyAddedMaterials = [];

  @override
  void initState() {
    super.initState();
    final env = context.read<OdooEnvironment>();
    _jobRepo = env.of<JobRepository>();

    _job = widget.job;

    _sub = _jobRepo.recordStream.listen((jobs) {
      final updated = jobs.where((j) => j.id == _job.id).toList();
      if (updated.isNotEmpty) {
        setState(() {
          _job = updated.first;
        });
      }
    });

    _jobRepo.fetchRecords();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  // --------- Helpers ----------

  String _statusLabel(AppLocalizations t, String status) {
    switch (status) {
      case 'draft': return t.statusDraft;
      case 'assigned': return t.statusAssigned;
      case 'in_progress': return t.statusInProgress;
      case 'done': return t.statusDone;
      case 'cancelled': return t.statusCancelled;
      default: return status;
    }
  }

  Color _statusColor(BuildContext context, String status) {
    switch (status) {
      case 'draft': return Colors.grey;
      case 'assigned': return Colors.blue;
      case 'in_progress': return Colors.orange;
      case 'done': return Colors.green;
      case 'cancelled': return Colors.red;
      default: return Theme.of(context).colorScheme.primary;
    }
  }

  String _formatDateTime(AppLocalizations t, DateTime? dt) {
    if (dt == null) return t.noSchedule;
    final local = dt.toLocal();
    final d = local.day.toString().padLeft(2, '0');
    final m = local.month.toString().padLeft(2, '0');
    final y = local.year.toString();
    final h = local.hour.toString().padLeft(2, '0');
    final min = local.minute.toString().padLeft(2, '0');
    return '$d/$m/$y • $h:$min';
  }

  String _formatSchedule(AppLocalizations t) {
    final dt = _job.scheduledDate ?? _job.startTime ?? _job.endTime;
    return _formatDateTime(t, dt);
  }

  String _formatDuration(AppLocalizations t) {
    DateTime? start = _job.startTime;
    DateTime? end = _job.endTime;
    Duration? diff;

    if (start != null && end != null) {
      diff = end.toLocal().difference(start.toLocal());
    } else if (start != null && _job.state == 'in_progress') {
      diff = DateTime.now().difference(start.toLocal());
    } else if (_job.durationHours > 0) {
      diff = Duration(minutes: (_job.durationHours * 60).round());
    }

    if (diff == null || diff.inMinutes <= 0) return '—';

    final h = diff.inHours;
    final m = diff.inMinutes % 60;
    if (h == 0) return '$m min';
    if (m == 0) return '$h h';
    return '${h}h ${m}m';
  }

  Widget _sectionHeader(BuildContext context, IconData icon, String title) {
    final color = Theme.of(context).colorScheme.primary;
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, size: 18, color: color),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
      ],
    );
  }

  // --------- Generic actions ----------

  Future<void> _startWithLocation() async {
    final t = AppLocalizations.of(context)!;
    setState(() => _isActionLoading = true);
    try {
      Position? position;
      try {
        bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
        if (!serviceEnabled) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t.locationServicesDisabled)));
        } else {
          LocationPermission permission = await Geolocator.checkPermission();
          if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();

          if (permission == LocationPermission.deniedForever || permission == LocationPermission.denied) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t.locationPermissionDenied)));
          } else {
            position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
          }
        }
      } catch (e, st) {
        debugPrint('⚠️ Error while getting location: $e\n$st');
      }

      if (position != null) {
        await _jobRepo.updateLocationAndStartJob(jobId: _job.id, latitude: position.latitude, longitude: position.longitude);
      } else {
        await _jobRepo.callMethodOnJob('action_start_job', _job.id);
      }
      await _jobRepo.fetchRecords();
    } catch (e, st) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${t.jobDetailStartFailed}: $e')));
    } finally {
      if (mounted) setState(() => _isActionLoading = false);
    }
  }

  Future<void> _finishWithLocation() async {
    final t = AppLocalizations.of(context)!;
    setState(() => _isActionLoading = true);
    try {
      Position? position;
      try {
        bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
        if (!serviceEnabled) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t.locationServicesDisabled)));
        } else {
          LocationPermission permission = await Geolocator.checkPermission();
          if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();

          if (permission == LocationPermission.deniedForever || permission == LocationPermission.denied) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t.locationPermissionDenied)));
          } else {
            position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
          }
        }
      } catch (e, st) {
        debugPrint('⚠️ Error while getting DONE location: $e\n$st');
      }

      if (position != null) {
        await _jobRepo.updateDoneLocationAndFinishJob(jobId: _job.id, latitude: position.latitude, longitude: position.longitude);
      } else {
        await _jobRepo.callMethodOnJob('action_done_job', _job.id);
      }
      await _jobRepo.fetchRecords();
    } catch (e, st) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${t.jobDetailUpdateFailed}: $e')));
    } finally {
      if (mounted) setState(() => _isActionLoading = false);
    }
  }

  Future<void> _openExternalMap() async {
    final t = AppLocalizations.of(context)!;
    final lat = _job.gpsLatitude;
    final lng = _job.gpsLongitude;
    final address = _buildCustomerAddress();

    final hasValidCoords = lat != null && lng != null && (lat != 0 || lng != 0);

    if (hasValidCoords) {
      final Uri uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lng');
      await launchUrl(uri, mode: LaunchMode.externalApplication);
      return;
    }
    if (address.trim().isNotEmpty) {
      final encoded = Uri.encodeComponent(address.trim());
      final Uri uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=$encoded');
      await launchUrl(uri, mode: LaunchMode.externalApplication);
      return;
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t.jobDetailNoLocationData)));
  }

  Future<void> _addPhotos() async {
    if (_isActionLoading || _uploadingPhoto) return;
    final t = AppLocalizations.of(context)!;

    final _PhotoSource? source = await showModalBottomSheet<_PhotoSource>(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              Container(
                width: 40, height: 4,
                decoration: BoxDecoration(color: Colors.grey[400], borderRadius: BorderRadius.circular(999)),
              ),
              const SizedBox(height: 8),
              ListTile(
                leading: const Icon(FluentIcons.camera_24_regular),
                title: Text(t.jobDetailTakePhotoCamera),
                onTap: () => Navigator.of(ctx).pop(_PhotoSource.camera),
              ),
              ListTile(
                leading: const Icon(Icons.photo_library_outlined),
                title: Text(t.jobDetailChooseFromGallery),
                onTap: () => Navigator.of(ctx).pop(_PhotoSource.gallery),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );

    if (source == null) return;

    try {
      setState(() => _uploadingPhoto = true);
      List<XFile> picked = [];

      if (source == _PhotoSource.camera) {
        final XFile? file = await _picker.pickImage(source: ImageSource.camera, maxWidth: 1600, maxHeight: 1600, imageQuality: 85);
        if (file != null) picked = [file];
      } else {
        picked = await _picker.pickMultiImage(maxWidth: 1600, maxHeight: 1600, imageQuality: 85);
      }

      if (picked.isEmpty) {
        setState(() => _uploadingPhoto = false);
        return;
      }

      final List<String> base64Images = [];
      for (final file in picked) {
        final bytes = await file.readAsBytes();
        base64Images.add(base64Encode(bytes));
      }

      await _jobRepo.uploadPhotos(jobId: _job.id, base64Images: base64Images);
      await _jobRepo.fetchRecords();

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${picked.length} ${t.jobDetailPhotosUploaded}')));
    } catch (e, st) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${t.jobDetailPhotosUploadFailed}: $e')));
    } finally {
      if (mounted) setState(() => _uploadingPhoto = false);
    }
  }

  Future<void> _openAuthentication() async {
    final t = AppLocalizations.of(context)!;
    final bool? saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => SignatureAuthScreen(job: _job)),
    );
    if (!mounted) return;
    if (saved == true) {
      _jobRepo.fetchRecords();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t.authSaved)));
    }
  }

  // =======================================================================
  // 🟢 UPDATED: Multi-Select Product Screen Navigation returning Names
  // =======================================================================
  Future<void> _openProductSelectionScreen() async {
    if (_products.isEmpty) {
      setState(() => _isActionLoading = true);
      try {
        _products = await _jobRepo.fetchProducts();
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to load products: $e')));
        setState(() => _isActionLoading = false);
        return;
      }
      setState(() => _isActionLoading = false);
    }

    if (!mounted) return;

    // Navigate to the new full-screen selection page
    final Map<int, Map<String, dynamic>>? result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddProductSelectionPage(
          availableProducts: _products,
        ),
      ),
    );

    // If user clicked Apply and selected items
    if (result != null && result.isNotEmpty) {
      setState(() => _isActionLoading = true);
      try {
        // Add each selected material sequentially
        for (var entry in result.entries) {
          await _jobRepo.addMaterialToJob(
            _job.id,
            entry.key, // Product ID
            entry.value['qty'], // Quantity
          );
        }
        await _jobRepo.fetchRecords();

        // Add locally so chips show up immediately!
        if (mounted) {
          setState(() {
            result.forEach((id, data) {
              _locallyAddedMaterials.add({
                'id': id,
                'name': data['name'],
                'qty': data['qty']
              });
            });
          });
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Materials added successfully!')));
        }
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to add materials: $e')));
      } finally {
        if (mounted) setState(() => _isActionLoading = false);
      }
    }
  }

  // 🟢 Create Invoice Logic
  Future<void> _createInvoice() async {
    setState(() => _isActionLoading = true);
    try {
      await _jobRepo.createInvoice(_job.id);
      await _jobRepo.fetchRecords();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invoice Created Successfully!')));
    } catch (e) {
      if (mounted) {
        showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('Error Creating Invoice'),
              content: Text(e.toString().replaceAll('Exception: ', '')),
              actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
            )
        );
      }
    } finally {
      if (mounted) setState(() => _isActionLoading = false);
    }
  }

  // 🟢 Download PDF Logic
  Future<void> _downloadInvoicePdf() async {
    setState(() => _isDownloadingPdf = true);

    try {
      const String reportXmlId = 'account.report_invoice';
      final int? targetInvoiceId = _job.invoiceId;

      if (targetInvoiceId == null) {
        throw Exception("No Invoice generated for this job yet.");
      }

      final pdfBytes = await _jobRepo.downloadPdfReport(reportXmlId, targetInvoiceId);

      final tempDir = await getTemporaryDirectory();
      final filePath = '${tempDir.path}/Invoice_$targetInvoiceId.pdf';
      final file = File(filePath);
      await file.writeAsBytes(pdfBytes);

      await Share.shareXFiles([XFile(filePath)], text: 'Invoice PDF');

    } catch (e) {
      debugPrint('Error downloading PDF: $e');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to download invoice: $e')),
      );
    } finally {
      if (mounted) setState(() => _isDownloadingPdf = false);
    }
  }

  String _buildCustomerAddress() {
    final c = _job.customer;
    final parts = <String>[];
    if (c.street.trim().isNotEmpty) parts.add(c.street.trim());
    if (c.street2.trim().isNotEmpty) parts.add(c.street2.trim());

    final cityLineParts = <String>[];
    if (c.city.trim().isNotEmpty) cityLineParts.add(c.city.trim());
    if (c.stateName.trim().isNotEmpty) cityLineParts.add(c.stateName.trim());
    if (c.zip.trim().isNotEmpty) cityLineParts.add(c.zip.trim());
    if (cityLineParts.isNotEmpty) parts.add(cityLineParts.join(' '));
    if (c.countryName.trim().isNotEmpty) parts.add(c.countryName.trim());

    return parts.join(', ');
  }

  void _openPhotoViewer(String url, Map<String, String>? headers) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PhotoViewerPage(imageUrl: url, headers: headers)),
    );
  }

  List<Widget> _buildActionButtons(AppLocalizations t) {
    final status = _job.state;
    final canStart = _job.canStart;
    final canFinish = _job.canFinish;

    VoidCallback? onPressed;
    IconData? icon;
    String? label;

    if (canStart && status != 'done' && status != 'cancelled') {
      onPressed = _isActionLoading ? null : _startWithLocation;
      icon = Icons.play_arrow_rounded;
      label = t.jobDetailStartButton;
    } else if (canFinish && status == 'in_progress') {
      onPressed = _isActionLoading ? null : _finishWithLocation;
      icon = Icons.check_circle_rounded;
      label = t.jobDetailMarkDone;
    } else {
      return [];
    }

    return [
      SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          onPressed: onPressed,
          icon: Icon(icon),
          label: Text(label),
        ),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final statusColor = _statusColor(context, _job.state);

    final env = context.read<OdooEnvironment>();
    final sessionId = env.orpc.sessionId?.id;
    final Map<String, String>? cookieHeader =
    sessionId != null ? {'Cookie': 'session_id=$sessionId'} : null;

    final photos = _job.photos;
    Uint8List? signatureBytes;
    if (_job.signature != null && _job.signature!.isNotEmpty) {
      try {
        signatureBytes = base64Decode(_job.signature!);
      } catch (e, st) {
        debugPrint('❌ Failed to decode signature base64: $e\n$st');
      }
    }

    final customerAddress = _buildCustomerAddress();
    final hasAddress = customerAddress.trim().isNotEmpty;
    final hasGps = _job.gpsLatitude != null && _job.gpsLongitude != null && (_job.gpsLatitude != 0 || _job.gpsLongitude != 0);

    // Determines if an invoice exists
    final bool hasInvoice = _job.invoiceId != null && _job.invoiceId! > 0;

    return Scaffold(
      appBar: AppBar(
        title: Text(_job.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_outlined),
            tooltip: t.commonRefresh,
            onPressed: _isActionLoading ? null : _jobRepo.fetchRecords,
          ),
        ],
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header card
                Card(
                  elevation: 0,
                  color: Theme.of(context).colorScheme.surface,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: BorderSide(color: Theme.of(context).dividerColor.withOpacity(0.4)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_job.name, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: statusColor.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(color: statusColor.withOpacity(0.5)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.circle_rounded, size: 10, color: statusColor),
                                  const SizedBox(width: 6),
                                  Text(
                                    _statusLabel(t, _job.state),
                                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: statusColor),
                                  ),
                                ],
                              ),
                            ),
                            if (_job.customer.phone.isNotEmpty)
                              GestureDetector(
                                  onTap: () async {
                                    final Uri launchUri = Uri(scheme: 'tel', path: _job.customer.phone);
                                    if (await canLaunchUrl(launchUri)) {
                                      await launchUrl(launchUri);
                                    }
                                  },
                                  child: const Icon(CupertinoIcons.phone, color: Colors.green)
                              )
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            const Icon(FluentIcons.person_12_regular, size: 20),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                _job.customer.name.isEmpty ? t.jobDetailNoCustomer : _job.customer.name,
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Icon(PhosphorIcons.hardHat(PhosphorIconsStyle.regular), size: 20),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                _job.assignedTo.name.isEmpty ? t.jobDetailUnassigned : _job.assignedTo.name,
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // Schedule card
                Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _sectionHeader(context, FluentIcons.calendar_clock_24_regular, t.jobDetailSchedule),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            const Icon(FluentIcons.calendar_ltr_24_regular, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(_formatSchedule(t), style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w500)),
                            ),
                          ],
                        ),
                        const Divider(height: 16),
                        Row(
                          children: [
                            const Icon(FluentIcons.arrow_circle_right_24_regular, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text('${t.jobDetailStart}: ${_formatDateTime(t, _job.startTime)}', style: Theme.of(context).textTheme.bodyMedium),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Icon(FluentIcons.arrow_circle_down_24_regular, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text('${t.jobDetailEnd}: ${_formatDateTime(t, _job.endTime)}', style: Theme.of(context).textTheme.bodyMedium),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Icon(FluentIcons.timer_24_regular, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text('${t.jobDetailDuration}: ${_formatDuration(t)}', style: Theme.of(context).textTheme.bodyMedium),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // Location card
                if (hasGps || hasAddress)
                  Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _sectionHeader(context, Icons.location_on_rounded, t.jobDetailLocation),
                          const Divider(height: 16),
                          if (hasGps) ...[
                            Row(
                              children: [
                                const Icon(FluentIcons.location_24_regular, size: 18),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    '${t.jobDetailLatShort}: ${_job.gpsLatitude!.toStringAsFixed(6)}, '
                                        '${t.jobDetailLngShort}: ${_job.gpsLongitude!.toStringAsFixed(6)}',
                                    style: Theme.of(context).textTheme.bodyMedium,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                          ],
                          if (hasAddress) ...[
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(FluentIcons.home_24_regular, size: 18),
                                const SizedBox(width: 6),
                                Expanded(child: Text(customerAddress, style: Theme.of(context).textTheme.bodyMedium)),
                              ],
                            ),
                            const SizedBox(height: 8),
                          ],
                          OutlinedButton.icon(
                            onPressed: _openExternalMap,
                            icon: const Icon(FluentIcons.map_24_regular),
                            label: Text(t.jobDetailOpenInMaps),
                          ),
                        ],
                      ),
                    ),
                  ),

                const SizedBox(height: 12),

                // Notes card
                if ((_job.note ?? '').isNotEmpty || (_job.customerNotes ?? '').isNotEmpty)
                  Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _sectionHeader(context, Icons.sticky_note_2_outlined, t.jobDetailNotes),
                          const SizedBox(height: 8),
                          if ((_job.customerNotes ?? '').isNotEmpty) ...[
                            Text(t.jobDetailCustomerNotes, style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600)),
                            const SizedBox(height: 4),
                            Text(_job.customerNotes!),
                            const SizedBox(height: 12),
                          ],
                          if ((_job.note ?? '').isNotEmpty) ...[
                            Text(t.jobDetailInternalNotes, style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600)),
                            const SizedBox(height: 4),
                            Text(_job.note!),
                          ],
                        ],
                      ),
                    ),
                  ),

                const SizedBox(height: 12),

                // Photos card
                InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: (_isActionLoading || _uploadingPhoto) ? null : _addPhotos,
                  child: Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.photo_library_outlined, size: 20),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(t.jobDetailPhotos, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
                              ),
                              FilledButton.icon(
                                onPressed: (_isActionLoading || _uploadingPhoto) ? null : _addPhotos,
                                icon: _uploadingPhoto
                                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                                    : const Icon(Icons.camera_alt_rounded),
                                label: Text(t.jobDetailAddPhotos),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(t.jobDetailPhotosHint, style: Theme.of(context).textTheme.bodySmall),
                          if (photos.isNotEmpty) ...[
                            const SizedBox(height: 12),
                            SizedBox(
                              height: 80,
                              child: ListView.separated(
                                scrollDirection: Axis.horizontal,
                                itemCount: photos.length,
                                separatorBuilder: (_, __) => const SizedBox(width: 8),
                                itemBuilder: (context, index) {
                                  final p = photos[index];
                                  final url = p.imageUrl;
                                  if (url == null || url.isEmpty) {
                                    return Container(
                                      width: 80, height: 80, alignment: Alignment.center,
                                      decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(12)),
                                      child: const Icon(Icons.image_not_supported_rounded, size: 22),
                                    );
                                  }
                                  return GestureDetector(
                                    onTap: () => _openPhotoViewer(url, cookieHeader),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(12),
                                      child: CachedNetworkImage(
                                        imageUrl: url,
                                        httpHeaders: cookieHeader,
                                        width: 80, height: 80, fit: BoxFit.cover,
                                        placeholder: (context, _) => Container(
                                          width: 80, height: 80, alignment: Alignment.center,
                                          decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(12)),
                                          child: const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                                        ),
                                        errorWidget: (context, _, __) => Container(
                                          width: 80, height: 80, alignment: Alignment.center,
                                          decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(12)),
                                          child: const Icon(Icons.broken_image_rounded, size: 22),
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // Authentication & Documents card
                InkWell(
                  onTap: _isActionLoading ? null : _openAuthentication,
                  borderRadius: BorderRadius.circular(16),
                  child: Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              _sectionHeader(context, Icons.shield_outlined, t.jobDetailAuth),
                              const Spacer(),
                              IconButton(
                                icon: const Icon(Icons.edit_note_rounded),
                                tooltip: t.jobDetailAuthTooltip,
                                onPressed: _isActionLoading ? null : _openAuthentication,
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(t.jobDetailAuthHint, style: Theme.of(context).textTheme.bodySmall),

                          if (signatureBytes != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              t.jobDetailAuthSavedSignature,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(height: 8),
                            Center(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.grey[50],
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: Colors.grey.shade300),
                                ),
                                padding: const EdgeInsets.all(8),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.memory(
                                    signatureBytes!,
                                    height: 80, fit: BoxFit.contain,
                                    errorBuilder: (_, __, ___) => SizedBox(
                                      height: 80, width: 160,
                                      child: Center(child: Icon(Icons.broken_image_rounded, color: Colors.grey[400])),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],

                          // =========================================================
                          // 🟢 ADDED: Materials & Documents Section (Chips style)
                          // =========================================================
                          const SizedBox(height: 16),
                          const Divider(),
                          const SizedBox(height: 8),
                          Text(
                            "Materials & Billing",
                            style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 12),

                          // 1. Add Product Chips and Button (Only visible if no invoice generated)
                          if (!hasInvoice) ...[
                            // 🟢 Show the selected materials beautifully as chips!
                            if (_locallyAddedMaterials.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(bottom: 16.0),
                                child: Wrap(
                                  spacing: 6.0,
                                  runSpacing: 6.0,
                                  children: _locallyAddedMaterials.map((mat) {
                                    return Chip(
                                      label: Text('${mat['name']} (x${mat['qty'].toInt()})', style: const TextStyle(fontSize: 12)),
                                      backgroundColor: Colors.grey[100],
                                      side: BorderSide(color: Colors.grey[300]!),
                                    );
                                  }).toList(),
                                ),
                              ),

                            // 🟢 Beautiful outlined button matching your reference image
                            SizedBox(
                              width: double.infinity,
                              child: OutlinedButton.icon(
                                onPressed: _isActionLoading ? null : _openProductSelectionScreen,
                                icon: const Icon(Icons.list),
                                label: const Text("Select Materials"),
                                style: OutlinedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                  foregroundColor: Theme.of(context).colorScheme.primary,
                                  side: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.5)),
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                          ],

                          // 2. Create Invoice Button
                          if (_job.state == 'done' && !hasInvoice) ...[
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton.icon(
                                onPressed: _isActionLoading ? null : _createInvoice,
                                icon: const Icon(Icons.receipt_rounded),
                                label: const Text("Create Invoice"),
                                style: FilledButton.styleFrom(
                                  backgroundColor: Colors.green,
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                          ],

                          // 3. Download Invoice Button
                          if (hasInvoice) ...[
                            SizedBox(
                              width: double.infinity,
                              child: OutlinedButton.icon(
                                onPressed: _isDownloadingPdf ? null : _downloadInvoicePdf,
                                icon: _isDownloadingPdf
                                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                                    : const Icon(Icons.picture_as_pdf_rounded),
                                label: Text(_isDownloadingPdf ? "Downloading..." : "Download Invoice"),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: Theme.of(context).colorScheme.primary,
                                  side: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.5)),
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          if (_isActionLoading)
            Container(
              color: Colors.black.withOpacity(0.05),
              child: const Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: _buildActionButtons(t),
          ),
        ),
      ),
    );
  }
}

/// Fullscreen screen with Syncfusion Signature Pad
class SignatureAuthScreen extends StatefulWidget {
  final JobRecord job;

  const SignatureAuthScreen({
    Key? key,
    required this.job,
  }) : super(key: key);

  @override
  State<SignatureAuthScreen> createState() => _SignatureAuthScreenState();
}

class _SignatureAuthScreenState extends State<SignatureAuthScreen> {
  final GlobalKey<SfSignaturePadState> _signatureKey = GlobalKey<SfSignaturePadState>();
  bool _saving = false;

  void _clear() => _signatureKey.currentState?.clear();

  void _save() async {
    final t = AppLocalizations.of(context)!;
    final padState = _signatureKey.currentState;
    if (padState == null) return;

    setState(() => _saving = true);
    try {
      final ui.Image image = await padState.toImage(pixelRatio: 3.0);
      final ByteData? bytes = await image.toByteData(format: ui.ImageByteFormat.png);

      if (bytes == null) throw Exception('Failed to convert signature to bytes');

      final Uint8List pngBytes = bytes.buffer.asUint8List(bytes.offsetInBytes, bytes.lengthInBytes);
      final String base64Signature = base64Encode(pngBytes);

      final env = context.read<OdooEnvironment>();
      final jobRepo = env.of<JobRepository>();

      await jobRepo.saveSignature(jobId: widget.job.id, base64Signature: base64Signature);

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${t.authSaveFailed}: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(title: Text('${t.jobDetailAuth} – ${widget.job.name}')),
      body: Column(
        children: [
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Text(t.authSignInstruction, style: Theme.of(context).textTheme.bodyMedium),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade400),
                ),
                child: SfSignaturePad(
                  key: _signatureKey,
                  backgroundColor: Colors.transparent,
                  strokeColor: Colors.black,
                  minimumStrokeWidth: 1.0,
                  maximumStrokeWidth: 3.0,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            child: Row(
              children: [
                TextButton.icon(
                  onPressed: _saving ? null : _clear,
                  icon: const Icon(Icons.clear_rounded),
                  label: Text(t.commonClear),
                ),
                const Spacer(),
                FilledButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: _saving
                      ? const SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.save_rounded),
                  label: Text(t.commonSave),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Simple full-screen photo viewer
class PhotoViewerPage extends StatelessWidget {
  final String imageUrl;
  final Map<String, String>? headers;

  const PhotoViewerPage({
    Key? key,
    required this.imageUrl,
    this.headers,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(title: Text(t.photoViewerTitle)),
      backgroundColor: Colors.black,
      body: Center(
        child: InteractiveViewer(
          maxScale: 5,
          child: CachedNetworkImage(
            imageUrl: imageUrl,
            httpHeaders: headers,
            fit: BoxFit.contain,
            placeholder: (context, _) => const Center(child: CircularProgressIndicator()),
            errorWidget: (context, _, __) => const Icon(Icons.broken_image_rounded, color: Colors.white70, size: 48),
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// 🟢 ADDED: Full Screen Product Selection with Checkboxes
// =======================================================================
class AddProductSelectionPage extends StatefulWidget {
  final List<dynamic> availableProducts;

  const AddProductSelectionPage({
    super.key,
    required this.availableProducts,
  });

  @override
  State<AddProductSelectionPage> createState() => _AddProductSelectionPageState();
}

class _AddProductSelectionPageState extends State<AddProductSelectionPage> {
  // Key = Product ID, Value = Map with name and qty
  final Map<int, Map<String, dynamic>> _selectedItems = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text('Select Materials', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context, _selectedItems);
            },
            child: const Text('Apply', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: widget.availableProducts.isEmpty
          ? const Center(child: Text('No products available'))
          : ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: widget.availableProducts.length,
        itemBuilder: (context, index) {
          final product = widget.availableProducts[index];
          final int productId = product['id'];
          final String productName = product['name'] ?? 'Unknown Product';

          final bool isSelected = _selectedItems.containsKey(productId);

          return Column(
            children: [
              Container(
                color: Colors.white,
                child: Row(
                  children: [
                    Checkbox(
                      value: isSelected,
                      activeColor: Theme.of(context).primaryColor,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                      onChanged: (val) {
                        setState(() {
                          if (val == true) {
                            _selectedItems[productId] = {'name': productName, 'qty': 1.0};
                          } else {
                            _selectedItems.remove(productId);
                          }
                        });
                      },
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            if (isSelected) {
                              _selectedItems.remove(productId);
                            } else {
                              _selectedItems[productId] = {'name': productName, 'qty': 1.0};
                            }
                          });
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 16.0),
                          child: Text(
                            productName,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              color: Colors.black87,
                            ),
                          ),
                        ),
                      ),
                    ),
                    // Small Quantity field when selected
                    if (isSelected)
                      Container(
                        width: 60,
                        height: 35,
                        margin: const EdgeInsets.only(right: 16),
                        child: TextFormField(
                          initialValue: _selectedItems[productId]!['qty'].toString(),
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          textAlign: TextAlign.center,
                          decoration: const InputDecoration(
                            contentPadding: EdgeInsets.zero,
                            border: OutlineInputBorder(),
                            isDense: true,
                          ),
                          onChanged: (val) {
                            final newQty = double.tryParse(val) ?? 1.0;
                            _selectedItems[productId]!['qty'] = newQty;
                          },
                        ),
                      ),
                  ],
                ),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
            ],
          );
        },
      ),
    );
  }
}