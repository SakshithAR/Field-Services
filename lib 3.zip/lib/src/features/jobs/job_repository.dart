import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show debugPrint;
import 'package:http/http.dart' as http;

import '../../odoo/odoo_repository/lib/odoo_repository.dart';
import 'job_record.dart';

/// Repository for the `taqnix_field_service.job` model in Odoo.
class JobRepository extends OdooRepository<JobRecord> {
  @override
  final String modelName = 'taqnix_field_service.job';

  /// Fields and nested relations to fetch for each job
  Map<String, dynamic> specification = {
    'id': {},
    'name': {},
    'invoice_id': {
      'fields': {
        'id': {},
        'name': {},
      }
    },
    'partner_id': {
      'fields': {
        'id': {},
        'name': {},
        'street': {},
        'street2': {},
        'city': {},
        'zip': {},
        'phone': {},
        'email': {},
        'state_id': {
          'fields': {
            'id': {},
            'name': {},
          }
        },
      }
    },
    'user_id': {
      'fields': {
        'id': {},
        'name': {},
      }
    },
    'scheduled_date': {},
    'start_time': {},
    'end_time': {},
    'duration_hours': {},
    'state': {},
    'gps_latitude': {},
    'gps_longitude': {},
    'gps_done_latitude': {},
    'gps_done_longitude': {},
    'note': {},
    'customer_notes': {},
    'can_start': {},
    'can_finish': {},
    'signature': {},
    'photo_ids': {
      'fields': {
        'id': {},
        'name': {},
        'sequence': {},
        'image_1920': {},
        'image_url': {},
      }
    },
  };

  JobRepository(OdooEnvironment odoo) : super(odoo);

  @override
  JobRecord createRecordFromJson(Map<String, dynamic> json) {
    return JobRecord.fromJson(json);
  }

  /// Generic helper to call a method on a single job record.
  Future<bool> callMethodOnJob(
      String method,
      int recordId, {
        Map<String, dynamic>? kwargs,
      }) async {
    final rpcCall = buildRpcCall(
      method,
      recordId,
      [
        [recordId],
      ],
      kwargs ?? {},
    );
    debugPrint('🚀 callMethodOnJob: $method on job #$recordId');
    await env.executeCall(rpcCall);
    return true;
  }

  Future<bool> setDraft(int jobId) => callMethodOnJob('action_set_draft', jobId);
  Future<bool> assignJob(int jobId) => callMethodOnJob('action_assign', jobId);
  Future<bool> startJob(int jobId) => callMethodOnJob('action_start_job', jobId);
  Future<bool> doneJob(int jobId) => callMethodOnJob('action_done_job', jobId);
  Future<bool> cancelJob(int jobId) => callMethodOnJob('action_cancel_job', jobId);

  Future<void> updateLocationAndStartJob({
    required int jobId,
    required double latitude,
    required double longitude,
  }) async {
    final writeParams = {
      'model': modelName,
      'method': 'write',
      'args': [[jobId], {'gps_latitude': latitude, 'gps_longitude': longitude}],
      'kwargs': {},
    };
    await env.orpc.callKw(writeParams);
    final startParams = {
      'model': modelName,
      'method': 'action_start_job',
      'args': [[jobId]],
      'kwargs': {},
    };
    await env.orpc.callKw(startParams);
  }

  Future<void> updateDoneLocationAndFinishJob({
    required int jobId,
    required double latitude,
    required double longitude,
  }) async {
    final writeParams = {
      'model': modelName,
      'method': 'write',
      'args': [[jobId], {'gps_done_latitude': latitude, 'gps_done_longitude': longitude}],
      'kwargs': {},
    };
    await env.orpc.callKw(writeParams);
    final doneParams = {
      'model': modelName,
      'method': 'action_done_job',
      'args': [[jobId]],
      'kwargs': {},
    };
    await env.orpc.callKw(doneParams);
  }

  String _formatOdooDateTime(DateTime dt) {
    final utc = dt.toUtc();
    final y = utc.year.toString().padLeft(4, '0');
    final m = utc.month.toString().padLeft(2, '0');
    final d = utc.day.toString().padLeft(2, '0');
    final h = utc.hour.toString().padLeft(2, '0');
    final min = utc.minute.toString().padLeft(2, '0');
    final s = utc.second.toString().padLeft(2, '0');
    return '$y-$m-$d $h:$min:$s';
  }

  Future<int> createJob({
    required String name,
    DateTime? scheduledDate,
    String? note,
    String? customerNotes,
  }) async {
    final vals = <String, dynamic>{
      'name': name,
      'state': 'assigned',
      if (scheduledDate != null)
        'scheduled_date': _formatOdooDateTime(scheduledDate),
      if (note != null && note.trim().isNotEmpty) 'note': note.trim(),
      if (customerNotes != null && customerNotes.trim().isNotEmpty)
        'customer_notes': customerNotes.trim(),
    };

    final result = await env.orpc.callKw({
      'model': modelName,
      'method': 'create',
      'args': [vals],
      'kwargs': {},
    });

    if (result is int) return result;
    if (result is List && result.isNotEmpty) return result.first as int;
    throw Exception('Unexpected result from create: $result');
  }

  Future<void> saveSignature({
    required int jobId,
    required String base64Signature,
  }) async {
    final params = {
      'model': modelName,
      'method': 'write',
      'args': [[jobId], {'signature': base64Signature}],
      'kwargs': {},
    };
    await env.orpc.callKw(params);
  }

  Future<void> uploadPhotos({
    required int jobId,
    required List<String> base64Images,
  }) async {
    if (base64Images.isEmpty) return;
    final List<dynamic> commands = [];
    for (int i = 0; i < base64Images.length; i++) {
      commands.add([0, 0, {'name': 'Photo ${i + 1}', 'image_1920': base64Images[i]}]);
    }
    final params = {
      'model': modelName,
      'method': 'write',
      'args': [[jobId], {'photo_ids': commands}],
      'kwargs': {},
    };
    await env.orpc.callKw(params);
  }

  Future<Uint8List> downloadPdfReport(String reportXmlId, int recordId) async {
    final baseUrl = env.orpc.baseURL;
    final sessionId = env.orpc.sessionId?.id;

    final url = '$baseUrl/report/pdf/$reportXmlId/$recordId';
    debugPrint('📄 Downloading PDF from: $url');

    final response = await http.get(
      Uri.parse(url),
      headers: {
        if (sessionId != null) 'Cookie': 'session_id=$sessionId',
      },
    );

    if (response.statusCode == 200) {
      return response.bodyBytes;
    } else {
      throw Exception('Failed to download PDF. HTTP Status: ${response.statusCode}');
    }
  }

  // =========================================================
  // 🟢 NEW: MATERIALS & INVOICING METHODS
  // =========================================================

  /// Fetch available products/materials from Odoo
  Future<List<dynamic>> fetchProducts() async {
    return await env.orpc.callKw({
      'model': 'product.product',
      'method': 'search_read',
      'args': [],
      'kwargs': {
        'domain': [
          ['type', 'in', ['consu', 'product']]
        ],
        'fields': ['id', 'name', 'list_price'],
      },
    });
  }

  /// Add a material line item to the current job
  Future<void> addMaterialToJob(int jobId, int productId, double quantity) async {
    await env.orpc.callKw({
      'model': 'taqnix_field_service.job_material',
      'method': 'create',
      'args': [
        {
          'job_id': jobId,
          'product_id': productId,
          'quantity': quantity,
        }
      ],
      'kwargs': {},
    });
  }

  /// Trigger the backend invoice creation logic
  Future<void> createInvoice(int jobId) async {
    await callMethodOnJob('action_create_invoice', jobId);
  }
}