import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fluentui_system_icons/fluentui_system_icons.dart';

import 'package:field_service/l10n/app_localizations.dart';
import 'package:field_service/src/odoo/odoo_repository/lib/odoo_repository.dart';
import 'package:field_service/src/features/jobs/job_record.dart';
import 'package:field_service/src/features/jobs/job_repository.dart';
import 'package:field_service/src/features/jobs/add_job_page.dart';
import 'package:field_service/src/features/jobs/job_card.dart';

class JobListPage extends StatefulWidget {
  const JobListPage({Key? key}) : super(key: key);

  @override
  State<JobListPage> createState() => _JobListPageState();
}

class _JobListPageState extends State<JobListPage>
    with SingleTickerProviderStateMixin {
  late JobRepository _jobRepo;
  late TabController _tabController;

  final TextEditingController _searchController = TextEditingController();
  bool _showSearch = false;

  /// Internal sort key – keep English constants for logic
  String _sortBy = 'Scheduled (Nearest)';

  @override
  void initState() {
    super.initState();
    final env = context.read<OdooEnvironment>();
    env.add(JobRepository(env));
    _jobRepo = env.of<JobRepository>();

    _tabController = TabController(length: 4, vsync: this);
    _fetchJobs();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchJobs() async {
    await _jobRepo.fetchRecords();
  }

  Future<void> _refreshData() async {
    await _jobRepo.fetchRecords();
  }

  String _formatDateTime(AppLocalizations t, DateTime? dt) {
    if (dt == null) return t.noSchedule;
    final local = dt.toLocal();
    final d = local.day.toString().padLeft(2, '0');
    final m = local.month.toString().padLeft(2, '0');
    final y = local.year.toString();
    final h = local.hour.toString().padLeft(2, '0');
    final min = local.minute.toString().padLeft(2, '0');
    return '$d/$m/$y • $h:$min';
  }

  /// Build a nice location/address string from the customer/partner.
  /// 👉 Adjust field names (street, city, countryName) to match your model.
  String _buildLocation(JobRecord job) {
    final parts = <String>[];

    // Example fields – change to whatever you actually have:
    final customer = job.customer;

    if ((customer.street ?? '').isNotEmpty) {
      parts.add(customer.street!);
    }
    if ((customer.city ?? '').isNotEmpty) {
      parts.add(customer.city!);
    }
    if ((customer.countryName ?? '').isNotEmpty) {
      parts.add(customer.countryName!);
    }

    // Fallback: if no address parts, show customer name or empty string
    if (parts.isEmpty) {
      return customer.name;
    }
    return parts.join(', ');
  }

  List<JobRecord> _applyFilters(
      List<JobRecord> list,
      String statusFilter,
      ) {
    final query = _searchController.text.toLowerCase();

    var filtered = list.where((j) {
      final name = j.name.toLowerCase();
      final customerName = j.customer.name.toLowerCase();
      final matchesSearch =
          query.isEmpty || name.contains(query) || customerName.contains(query);

      final matchesStatus =
          statusFilter == 'All' || j.state == statusFilter;

      return matchesSearch && matchesStatus;
    }).toList();

    switch (_sortBy) {
      case 'Scheduled (Farthest)':
        filtered.sort((a, b) {
          final ad = a.scheduledDate ?? DateTime.fromMillisecondsSinceEpoch(0);
          final bd = b.scheduledDate ?? DateTime.fromMillisecondsSinceEpoch(0);
          return bd.compareTo(ad);
        });
        break;
      case 'Customer (A-Z)':
        filtered.sort((a, b) => a.customer.name.compareTo(b.customer.name));
        break;
      case 'Status':
        filtered.sort((a, b) => a.state.compareTo(b.state));
        break;
      default: // 'Scheduled (Nearest)'
        filtered.sort((a, b) {
          final ad = a.scheduledDate ?? DateTime.fromMillisecondsSinceEpoch(0);
          final bd = b.scheduledDate ?? DateTime.fromMillisecondsSinceEpoch(0);
          return ad.compareTo(bd);
        });
    }

    return filtered;
  }

  /// Builds one tab's list using the already-fetched jobs
  Widget _buildJobListForStatus(
      List<JobRecord> allJobs,
      String statusFilter,
      AppLocalizations t,
      ) {
    final display = _applyFilters(allJobs, statusFilter);

    if (display.isEmpty) {
      return _buildEmptyState(t);
    }

    return RefreshIndicator(
      onRefresh: _refreshData,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: display.length,
        itemBuilder: (ctx, i) {
          final job = display[i];
          return JobCard(
            job: job,
            timeText: _formatDateTime(t, job.scheduledDate ?? job.startTime),
            // ✅ Now we pass a proper location/address string instead of customer name
            addressText: _buildLocation(job),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: _showSearch
            ? TextField(
          controller: _searchController,
          autofocus: true,
          decoration: InputDecoration(
            hintText: t.searchJobsHint,
            border: InputBorder.none,
            prefixIcon: const Icon(CupertinoIcons.search),
            suffixIcon: IconButton(
              icon: const Icon(Icons.close_rounded),
              onPressed: () => setState(() {
                _showSearch = false;
                _searchController.clear();
              }),
            ),
          ),
          onChanged: (_) => setState(() {}),
        )
            : Text(t.jobs),
        centerTitle: true,
        actions: [
          if (!_showSearch)
            IconButton(
              icon: const Icon(CupertinoIcons.search),
              onPressed: () => setState(() {
                _showSearch = true;
              }),
            ),
          IconButton(
            icon: const Icon(FluentIcons.filter_24_regular),
            onPressed: () => _showFilterDialog(t),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: false,
          tabs: [
            Tab(
              text: t.tabAssigned,
              icon: const Icon(Icons.assignment_turned_in_outlined),
            ),
            Tab(
              text: t.tabInProgress,
              icon: const Icon(Icons.autorenew),
            ),
            Tab(
              text: t.tabDone,
              icon: const Icon(FluentIcons.checkmark_circle_24_regular),
            ),
            Tab(
              text: t.tabAll,
              icon: const Icon(FluentIcons.folder_open_24_regular),
            ),
          ],
        ),
      ),

      // Single StreamBuilder for all tabs
      body: StreamBuilder<List<JobRecord>>(
        stream: _jobRepo.recordStream,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final allJobs = snapshot.data!;

          return TabBarView(
            controller: _tabController,
            children: [
              _buildJobListForStatus(allJobs, 'assigned', t),
              _buildJobListForStatus(allJobs, 'in_progress', t),
              _buildJobListForStatus(allJobs, 'done', t),
              _buildJobListForStatus(allJobs, 'All', t),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final created = await Navigator.push<bool>(
            context,
            MaterialPageRoute(
              builder: (_) => const AddJobPage(),
            ),
          );

          if (created == true) {
            _refreshData();
          }
        },
        child: const Icon(FluentIcons.add_24_regular),
      ),
    );
  }

  Widget _buildEmptyState(AppLocalizations t) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            FluentIcons.task_list_square_rtl_24_regular,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            t.emptyJobsTitle,
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
          const SizedBox(height: 8),
          Text(
            t.emptyJobsSubtitle,
            style: TextStyle(color: Colors.grey[500]),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            icon: const Icon(FluentIcons.add_24_regular, size: 18),
            label: Text(t.emptyJobsAddButton),
            onPressed: () async {
              final created = await Navigator.push<bool>(
                context,
                MaterialPageRoute(
                  builder: (_) => const AddJobPage(),
                ),
              );
              if (created == true) {
                _refreshData();
              }
            },
          ),
        ],
      ),
    );
  }

  void _showFilterDialog(AppLocalizations t) {
    const options = [
      'Scheduled (Nearest)',
      'Scheduled (Farthest)',
      'Customer (A-Z)',
      'Status',
    ];

    String _labelForOption(String opt) {
      switch (opt) {
        case 'Scheduled (Nearest)':
          return t.sortScheduledNearest;
        case 'Scheduled (Farthest)':
          return t.sortScheduledFarthest;
        case 'Customer (A-Z)':
          return t.sortCustomerAZ;
        case 'Status':
          return t.sortStatus;
        default:
          return opt;
      }
    }

    showModalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              t.sortBy,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            for (var opt in options)
              RadioListTile<String>(
                title: Text(_labelForOption(opt)),
                value: opt,
                groupValue: _sortBy,
                onChanged: (v) {
                  if (v != null) setState(() => _sortBy = v);
                  Navigator.pop(ctx);
                },
              ),
          ],
        ),
      ),
    );
  }
}
