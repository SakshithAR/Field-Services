import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import 'package:field_service/src/odoo/odoo_repository/lib/odoo_repository.dart';
import 'package:field_service/src/features/jobs/job_record.dart';
import 'package:field_service/src/features/jobs/job_repository.dart';
import 'package:field_service/l10n/app_localizations.dart';

class MapPage extends StatefulWidget {
  /// When coming from JobListPage you can pass which job index to focus.
  final int? initialJobIndex;

  const MapPage({super.key, this.initialJobIndex});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  GoogleMapController? _mapController;
  late JobRepository _jobRepo;

  // Default camera (Dubai center as fallback)
  CameraPosition _cameraPosition = const CameraPosition(
    target: LatLng(25.2048, 55.2708),
    zoom: 11,
  );

  LatLng? _currentLatLng; // your GPS location
  int? _selectedJobIndex; // to highlight selected card + marker
  bool _didCenterInitial = false; // only center once when coming from list

  @override
  void initState() {
    super.initState();

    final env = context.read<OdooEnvironment>();
    env.add(JobRepository(env));
    _jobRepo = env.of<JobRepository>();
    _jobRepo.fetchRecords(); // load jobs

    _initCurrentLocation();
  }

  /// Get current GPS location and move camera there
  Future<void> _initCurrentLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return;

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.deniedForever ||
          permission == LocationPermission.denied) {
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      final currentLatLng = LatLng(pos.latitude, pos.longitude);

      setState(() {
        _currentLatLng = currentLatLng;
        _cameraPosition = CameraPosition(
          target: currentLatLng,
          zoom: 13,
        );
      });

      _mapController?.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(target: currentLatLng, zoom: 13),
        ),
      );
    } catch (e) {
      // ignore errors for now
    }
  }

  /// Temporary: generate a fake position for each job around base point
  LatLng _jobPositionForIndex(int index) {
    final base = _currentLatLng ?? const LatLng(25.2048, 55.2708);
    const step = 0.01; // ~1km offset per job
    return LatLng(
      base.latitude + index * step,
      base.longitude + index * step,
    );
  }

  /// Nicely format job address from customer partner fields.
  String _formatJobAddress(JobRecord job) {
    final c = job.customer;
    final parts = <String>[];

    final street = c.street.trim();
    if (street.isNotEmpty) parts.add(street);

    final street2 = c.street2.trim();
    if (street2.isNotEmpty) parts.add(street2);

    final cityZip = <String>[];
    final city = c.city.trim();
    if (city.isNotEmpty) cityZip.add(city);
    final zip = c.zip.trim();
    if (zip.isNotEmpty) cityZip.add(zip);
    if (cityZip.isNotEmpty) parts.add(cityZip.join(' '));

    final countryName = c.countryName.trim();
    if (countryName.isNotEmpty) parts.add(countryName);

    // Fallback: just customer name
    if (parts.isEmpty) {
      return c.name;
    }
    return parts.join(', ');
  }

  /// Format date + time together, e.g. "Jan 1, 2025 · 14:30"
  String _formatDateTime(DateTime? dt) {
    if (dt == null) return '-- --, --:--';
    final local = dt.toLocal();
    final datePart = DateFormat.yMMMd().format(local); // locale-aware
    final timePart = DateFormat.Hm().format(local); // 24h time
    return '$datePart · $timePart';
  }

  /// Build markers from job list, highlighting selected job if any
  Set<Marker> _buildMarkers(
      List<JobRecord> jobs,
      int? selectedIndex,
      AppLocalizations t,
      ) {
    final markers = <Marker>{};

    for (int i = 0; i < jobs.length; i++) {
      final job = jobs[i];
      final pos = _jobPositionForIndex(i);
      final isSelected = i == selectedIndex;

      final address = _formatJobAddress(job);

      markers.add(
        Marker(
          markerId: MarkerId('job_$i'),
          position: pos,
          infoWindow: InfoWindow(
            title: job.name,
            snippet: address,
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            isSelected
                ? BitmapDescriptor.hueAzure
                : BitmapDescriptor.hueRed,
          ),
        ),
      );
    }

    if (_currentLatLng != null) {
      markers.add(
        Marker(
          markerId: const MarkerId('you'),
          position: _currentLatLng!,
          infoWindow: InfoWindow(title: t.mapYouAreHere),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueAzure,
          ),
        ),
      );
    }

    return markers;
  }

  /// When you tap a job card at bottom
  void _onJobTap(int index) {
    setState(() {
      _selectedJobIndex = index;
    });

    final target = _jobPositionForIndex(index);

    _mapController?.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: target, zoom: 14),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      // background of whole page
      backgroundColor:
      isDark ? Colors.black : Theme.of(context).colorScheme.surface,
      appBar: AppBar(
        title: Text(t.mapTitle),
      ),
      body: StreamBuilder<List<JobRecord>>(
        stream: _jobRepo.recordStream,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final jobs = snapshot.data!;

          if (jobs.isEmpty) {
            return Center(
              child: Text(
                t.mapEmptyTitle,
                style: TextStyle(
                  color: isDark ? Colors.white70 : Colors.grey,
                ),
              ),
            );
          }

          // use selected index from tap OR from initialJobIndex
          final selectedIndex = _selectedJobIndex ?? widget.initialJobIndex;

          // center on initialJobIndex once when coming from list
          if (widget.initialJobIndex != null &&
              !_didCenterInitial &&
              widget.initialJobIndex! >= 0 &&
              widget.initialJobIndex! < jobs.length &&
              _mapController != null) {
            _didCenterInitial = true;
            final target = _jobPositionForIndex(widget.initialJobIndex!);
            WidgetsBinding.instance.addPostFrameCallback((_) {
              _mapController?.animateCamera(
                CameraUpdate.newCameraPosition(
                  CameraPosition(target: target, zoom: 14),
                ),
              );
            });
          }

          final markers = _buildMarkers(jobs, selectedIndex, t);

          return Stack(
            children: [
              // === Real Google Map ===
              Positioned.fill(
                child: GoogleMap(
                  initialCameraPosition: _cameraPosition,
                  markers: markers,
                  myLocationEnabled: true,
                  myLocationButtonEnabled: true,
                  onMapCreated: (controller) {
                    _mapController = controller;
                  },
                ),
              ),

              // === Bottom horizontal job cards ===
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  height: 190,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    // bottom sheet background
                    color: isDark
                        ? Colors.black
                        : Colors.white.withOpacity(0.94),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 12,
                        offset: Offset(0, -4),
                      ),
                    ],
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title row
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 4,
                        ),
                        child: Row(
                          children: [
                            Text(
                              t.mapBottomTitle,
                              style: Theme.of(context)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                                color:
                                isDark ? Colors.white : Colors.black87,
                              ),
                            ),
                            const Spacer(),
                            Text(
                              '${jobs.length} ${t.mapJobsLabel}',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(
                                color: isDark
                                    ? Colors.white70
                                    : Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Horizontal cards
                      Expanded(
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          padding:
                          const EdgeInsets.symmetric(horizontal: 12),
                          itemCount: jobs.length,
                          itemBuilder: (context, index) {
                            final job = jobs[index];
                            return _MapJobCard(
                              t: t,
                              title: job.name,
                              customer: job.customer.name,
                              status: job.state,
                              // date + time together
                              time: _formatDateTime(
                                job.scheduledDate ?? job.startTime,
                              ),
                              // full address from partner
                              address: _formatJobAddress(job),
                              index: index + 1,
                              total: jobs.length,
                              selected: index == selectedIndex,
                              onTap: () => _onJobTap(index),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Card shown at the bottom over the map
class _MapJobCard extends StatelessWidget {
  final AppLocalizations t;
  final String title;
  final String customer;
  final String status;
  final String time; // now contains "date · time"
  final String address; // full address shown with location icon
  final int index;
  final int total;
  final bool selected;
  final VoidCallback onTap;

  const _MapJobCard({
    required this.t,
    required this.title,
    required this.customer,
    required this.status,
    required this.time,
    required this.address,
    required this.index,
    required this.total,
    required this.selected,
    required this.onTap,
  });

  Color _statusColor(BuildContext context) {
    switch (status) {
      case 'draft':
        return Colors.grey;
      case 'assigned':
        return Colors.blue;
      case 'in_progress':
        return Colors.orange;
      case 'done':
        return Colors.green;
      case 'cancelled':
        return Colors.red;
      default:
        return Theme.of(context).colorScheme.primary;
    }
  }

  String _statusLabel() {
    switch (status) {
      case 'draft':
        return t.statusDraft;
      case 'assigned':
        return t.statusAssigned;
      case 'in_progress':
        return t.statusInProgress;
      case 'done':
        return t.statusDone;
      case 'cancelled':
        return t.statusCancelled;
      default:
        return status;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _statusColor(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final titleColor = isDark ? Colors.white : Colors.black87;
    final secondaryColor = isDark ? Colors.white70 : Colors.black54;

    return Container(
      width: 260,
      margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Card(
        elevation: selected ? 6 : 3,
        // card background
        color: isDark ? Colors.black : Colors.white,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: selected
              ? BorderSide(
            color: Theme.of(context).colorScheme.primary,
            width: 1,
          )
              : BorderSide.none,
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Top row: index & status chip
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: isDark
                            ? Colors.white10
                            : Colors.grey.shade200,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '$index / $total',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: isDark ? Colors.white : Colors.black87,
                        ),
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.16),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: color.withOpacity(0.5),
                        ),
                      ),
                      child: Text(
                        _statusLabel(),
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: isDark ? Colors.white : color,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                // Title
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: titleColor,
                  ),
                ),
                const SizedBox(height: 4),
                // Customer
                Row(
                  children: [
                    Icon(
                      Icons.person_outline,
                      size: 16,
                      color: secondaryColor,
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        customer,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: secondaryColor,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                // Address
                Row(
                  children: [
                    Icon(
                      Icons.location_on_outlined,
                      size: 16,
                      color: secondaryColor,
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        address,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: secondaryColor,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                // Date + Time
                Row(
                  children: [
                    Icon(
                      Icons.access_time,
                      size: 16,
                      color: secondaryColor,
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        time,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: secondaryColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
