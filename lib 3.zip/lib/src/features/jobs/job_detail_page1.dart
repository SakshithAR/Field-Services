import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart'; // debugPrint
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_signaturepad/signaturepad.dart';

import 'package:field_service/l10n/app_localizations.dart';
import '../../odoo/odoo_repository/lib/odoo_repository.dart';
import 'job_record.dart';
import 'job_repository.dart';

class JobDetailPage extends StatefulWidget {
  final JobRecord job;

  const JobDetailPage({
    Key? key,
    required this.job,
  }) : super(key: key);

  @override
  State<JobDetailPage> createState() => _JobDetailPageState();
}

// For choosing between camera and gallery
enum _PhotoSource { camera, gallery }

class _JobDetailPageState extends State<JobDetailPage> {
  late JobRepository _jobRepo;
  late JobRecord _job;
  StreamSubscription<List<JobRecord>>? _sub;

  bool _isActionLoading = false;

  /// For picking photos from camera / gallery
  final ImagePicker _picker = ImagePicker();
  bool _uploadingPhoto = false;

  @override
  void initState() {
    super.initState();
    final env = context.read<OdooEnvironment>();
    _jobRepo = env.of<JobRepository>();

    _job = widget.job;

    // Keep detail page in sync with repository updates
    _sub = _jobRepo.recordStream.listen((jobs) {
      final updated = jobs.where((j) => j.id == _job.id).toList();
      if (updated.isNotEmpty) {
        setState(() {
          _job = updated.first;
        });
      }
    });

    // Ensure we have fresh data
    _jobRepo.fetchRecords();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  // --------- Helpers ----------

  String _statusLabel(AppLocalizations t, String status) {
    switch (status) {
      case 'draft':
        return t.statusDraft;
      case 'assigned':
        return t.statusAssigned;
      case 'in_progress':
        return t.statusInProgress;
      case 'done':
        return t.statusDone;
      case 'cancelled':
        return t.statusCancelled;
      default:
        return status;
    }
  }

  Color _statusColor(BuildContext context, String status) {
    switch (status) {
      case 'draft':
        return Colors.grey;
      case 'assigned':
        return Colors.blue;
      case 'in_progress':
        return Colors.orange;
      case 'done':
        return Colors.green;
      case 'cancelled':
        return Colors.red;
      default:
        return Theme.of(context).colorScheme.primary;
    }
  }

  /// Convert Odoo datetime → local device time → formatted string
  String _formatDateTime(AppLocalizations t, DateTime? dt) {
    if (dt == null) return t.noSchedule;

    // Odoo stores UTC; convert once to local for display
    final local = dt.toLocal();

    final d = local.day.toString().padLeft(2, '0');
    final m = local.month.toString().padLeft(2, '0');
    final y = local.year.toString();
    final h = local.hour.toString().padLeft(2, '0');
    final min = local.minute.toString().padLeft(2, '0');

    return '$d/$m/$y • $h:$min';
  }

  String _formatSchedule(AppLocalizations t) {
    final dt = _job.scheduledDate ?? _job.startTime ?? _job.endTime;
    return _formatDateTime(t, dt);
  }

  /// Duration logic:
  /// - if start & end exist -> end - start
  /// - else if start exists & job in_progress -> now - start (present time)
  /// - else if durationHours > 0 from Odoo -> use that
  /// - else -> "—"
  String _formatDuration(AppLocalizations t) {
    DateTime? start = _job.startTime;
    DateTime? end = _job.endTime;
    Duration? diff;

    if (start != null && end != null) {
      final s = start.toLocal();
      final e = end.toLocal();
      diff = e.difference(s);
    } else if (start != null && _job.state == 'in_progress') {
      final s = start.toLocal();
      final now = DateTime.now(); // already local
      diff = now.difference(s);
    } else if (_job.durationHours > 0) {
      final totalMinutes = (_job.durationHours * 60).round();
      diff = Duration(minutes: totalMinutes);
    }

    if (diff == null || diff.inMinutes <= 0) return '—';

    final h = diff.inHours;
    final m = diff.inMinutes % 60;
    if (h == 0) return '$m min';
    if (m == 0) return '$h h';
    return '${h}h ${m}m';
  }

  /// Reusable stylish header for each card section
  Widget _sectionHeader(BuildContext context, IconData icon, String title) {
    final color = Theme.of(context).colorScheme.primary;

    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            size: 18,
            color: color,
          ),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: Theme.of(context)
              .textTheme
              .titleMedium
              ?.copyWith(fontWeight: FontWeight.w600),
        ),
      ],
    );
  }

  // --------- Generic actions ----------

  Future<void> _runAction(String methodName) async {
    final t = AppLocalizations.of(context)!;
    setState(() => _isActionLoading = true);
    try {
      await _jobRepo.callMethodOnJob(methodName, _job.id);
      await _jobRepo.fetchRecords(); // refresh state + stream
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.jobDetailUpdateFailed}: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => _isActionLoading = false);
      }
    }
  }

  // --------- Open map for any coordinates (helper) ----------

  Future<void> _openMapForCoords(double lat, double lng) async {
    final t = AppLocalizations.of(context)!;
    final Uri uri = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=$lat,$lng',
    );

    try {
      final ok = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
      if (!ok && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(t.jobDetailMapOpenFailed)),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.jobDetailMapError}: $e')),
      );
    }
  }

  // --------- Start with GPS + auto-open map ----------

  Future<void> _startWithLocation() async {
    final t = AppLocalizations.of(context)!;
    setState(() => _isActionLoading = true);
    try {
      Position? position;

      // --- Ask for location and get coordinates ---
      try {
        bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
        if (!serviceEnabled) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(t.locationServicesDisabled)),
          );
        } else {
          LocationPermission permission = await Geolocator.checkPermission();
          if (permission == LocationPermission.denied) {
            permission = await Geolocator.requestPermission();
          }

          if (permission == LocationPermission.deniedForever ||
              permission == LocationPermission.denied) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(t.locationPermissionDenied)),
            );
          } else {
            position = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.high,
            );
            debugPrint(
              '📍 Got position: ${position.latitude}, ${position.longitude}',
            );
          }
        }
      } catch (e, st) {
        debugPrint('⚠️ Error while getting location: $e\n$st');
      }

      // --- Call Odoo: write GPS + start, or just start if no GPS ---
      if (position != null) {
        await _jobRepo.updateLocationAndStartJob(
          jobId: _job.id,
          latitude: position.latitude,
          longitude: position.longitude,
        );
      } else {
        await _jobRepo.callMethodOnJob('action_start_job', _job.id);
      }

      // Refresh to pull updated state + GPS from Odoo
      await _jobRepo.fetchRecords();
    } catch (e, st) {
      debugPrint('❌ Failed to start job: $e\n$st');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.jobDetailStartFailed}: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => _isActionLoading = false);
      }
    }
  }

  // --------- Finish job with GPS + mark as done ----------

  Future<void> _finishWithLocation() async {
    final t = AppLocalizations.of(context)!;
    setState(() => _isActionLoading = true);
    try {
      Position? position;

      // --- Ask for location and get coordinates ---
      try {
        bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
        if (!serviceEnabled) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(t.locationServicesDisabled)),
          );
        } else {
          LocationPermission permission = await Geolocator.checkPermission();
          if (permission == LocationPermission.denied) {
            permission = await Geolocator.requestPermission();
          }

          if (permission == LocationPermission.deniedForever ||
              permission == LocationPermission.denied) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(t.locationPermissionDenied)),
            );
          } else {
            position = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.high,
            );
            debugPrint(
              '📍 Got DONE position: ${position.latitude}, ${position.longitude}',
            );
          }
        }
      } catch (e, st) {
        debugPrint('⚠️ Error while getting DONE location: $e\n$st');
      }

      // --- Call Odoo: write GPS_DONE + done, or only done if no GPS ---
      if (position != null) {
        await _jobRepo.updateDoneLocationAndFinishJob(
          jobId: _job.id,
          latitude: position.latitude,
          longitude: position.longitude,
        );
      } else {
        // Fallback: still allow finishing the job without GPS
        await _jobRepo.callMethodOnJob('action_done_job', _job.id);
      }

      // Refresh to pull updated state + GPS from Odoo
      await _jobRepo.fetchRecords();
    } catch (e, st) {
      debugPrint('❌ Failed to finish job: $e\n$st');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.jobDetailUpdateFailed}: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => _isActionLoading = false);
      }
    }
  }

  // --------- Open external Maps with job GPS or address ----------

  Future<void> _openExternalMap() async {
    final t = AppLocalizations.of(context)!;
    final lat = _job.gpsLatitude;
    final lng = _job.gpsLongitude;
    final address = _buildCustomerAddress();

    // Treat 0,0 as "no GPS"
    final hasValidCoords =
        lat != null && lng != null && (lat != 0 || lng != 0);

    if (hasValidCoords) {
      await _openMapForCoords(lat!, lng!);
      return;
    }

    if (address.trim().isNotEmpty) {
      await _openMapForAddress(address);
      return;
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(t.jobDetailNoLocationData)),
    );
  }

  // --------- MULTI photo upload (camera + gallery) ----------

  Future<void> _addPhotos() async {
    if (_isActionLoading || _uploadingPhoto) return;
    final t = AppLocalizations.of(context)!;

    // Ask user: camera or gallery?
    final _PhotoSource? source = await showModalBottomSheet<_PhotoSource>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[400],
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
              const SizedBox(height: 8),
              ListTile(
                leading: const Icon(FluentIcons.camera_24_regular),
                title: Text(t.jobDetailTakePhotoCamera),
                onTap: () => Navigator.of(ctx).pop(_PhotoSource.camera),
              ),
              ListTile(
                leading: const Icon(Icons.photo_library_outlined),
                title: Text(t.jobDetailChooseFromGallery),
                onTap: () => Navigator.of(ctx).pop(_PhotoSource.gallery),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );

    if (source == null) return;

    try {
      setState(() => _uploadingPhoto = true);

      List<XFile> picked = [];

      if (source == _PhotoSource.camera) {
        final XFile? file = await _picker.pickImage(
          source: ImageSource.camera,
          maxWidth: 1600,
          maxHeight: 1600,
          imageQuality: 85,
        );
        if (file != null) {
          picked = [file];
        }
      } else {
        picked = await _picker.pickMultiImage(
          maxWidth: 1600,
          maxHeight: 1600,
          imageQuality: 85,
        );
      }

      if (picked.isEmpty) {
        setState(() => _uploadingPhoto = false);
        return;
      }

      final List<String> base64Images = [];
      for (final file in picked) {
        final bytes = await file.readAsBytes();
        base64Images.add(base64Encode(bytes));
      }

      await _jobRepo.uploadPhotos(
        jobId: _job.id,
        base64Images: base64Images,
      );

      await _jobRepo.fetchRecords();

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${picked.length} ${t.jobDetailPhotosUploaded}'),
        ),
      );
    } catch (e, st) {
      debugPrint('❌ Failed to upload photos: $e\n$st');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.jobDetailPhotosUploadFailed}: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => _uploadingPhoto = false);
      }
    }
  }

  // --------- Authentication (open Syncfusion screen) ----------

  Future<void> _openAuthentication() async {
    final t = AppLocalizations.of(context)!;
    final bool? saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => SignatureAuthScreen(job: _job),
      ),
    );

    if (!mounted) return;

    if (saved == true) {
      _jobRepo.fetchRecords();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t.authSaved)),
      );
    }
  }

  /// Build a single-line customer address string from PartnerRecord.
  String _buildCustomerAddress() {
    final c = _job.customer;

    final parts = <String>[];

    if (c.street.trim().isNotEmpty) {
      parts.add(c.street.trim());
    }
    if (c.street2.trim().isNotEmpty) {
      parts.add(c.street2.trim());
    }

    final cityLineParts = <String>[];
    if (c.city.trim().isNotEmpty) {
      cityLineParts.add(c.city.trim());
    }
    if (c.stateName.trim().isNotEmpty) {
      cityLineParts.add(c.stateName.trim());
    }
    if (c.zip.trim().isNotEmpty) {
      cityLineParts.add(c.zip.trim());
    }
    if (cityLineParts.isNotEmpty) {
      parts.add(cityLineParts.join(' '));
    }

    if (c.countryName.trim().isNotEmpty) {
      parts.add(c.countryName.trim());
    }

    return parts.join(', ');
  }

  // --------- Open map for an address string ----------

  Future<void> _openMapForAddress(String address) async {
    final t = AppLocalizations.of(context)!;

    if (address.trim().isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t.jobDetailNoAddress)),
      );
      return;
    }

    final encoded = Uri.encodeComponent(address.trim());
    final Uri uri = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=$encoded',
    );

    try {
      final ok = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
      if (!ok && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(t.jobDetailMapOpenFailed)),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.jobDetailMapError}: $e')),
      );
    }
  }

  // --------- Open full-screen photo viewer ----------

  void _openPhotoViewer(String url, Map<String, String>? headers) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PhotoViewerPage(
          imageUrl: url,
          headers: headers,
        ),
      ),
    );
  }

  // --------- Build bottom actions ----------
  // Single full-width button: Start OR Mark as done. No secondary buttons.

  List<Widget> _buildActionButtons(AppLocalizations t) {
    final status = _job.state;
    final canStart = _job.canStart;
    final canFinish = _job.canFinish;

    VoidCallback? onPressed;
    IconData? icon;
    String? label;

    if (canStart && status != 'done' && status != 'cancelled') {
      // Primary: START
      onPressed = _isActionLoading ? null : _startWithLocation;
      icon = Icons.play_arrow_rounded;
      label = t.jobDetailStartButton;
    } else if (canFinish && status == 'in_progress') {
      // Primary: MARK DONE (with GPS)
      onPressed = _isActionLoading ? null : _finishWithLocation;
      icon = Icons.check_circle_rounded;
      label = t.jobDetailMarkDone;
    } else {
      // No action available for this state
      return [];
    }

    return [
      SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          onPressed: onPressed,
          icon: Icon(icon),
          label: Text(label),
        ),
      ),
    ];
  }

  // --------- UI ----------

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final statusColor = _statusColor(context, _job.state);

    // Get session cookie from Odoo client
    final env = context.read<OdooEnvironment>();
    final sessionId = env.orpc.sessionId?.id;
    final Map<String, String>? cookieHeader =
    sessionId != null ? {'Cookie': 'session_id=$sessionId'} : null;

    final photos = _job.photos; // List<JobPhotoRecord>

    // Decode saved signature (base64 -> bytes)
    Uint8List? signatureBytes;
    if (_job.signature != null && _job.signature!.isNotEmpty) {
      try {
        signatureBytes = base64Decode(_job.signature!);
      } catch (e, st) {
        debugPrint('❌ Failed to decode signature base64: $e\n$st');
      }
    }

    final customerAddress = _buildCustomerAddress();
    final hasAddress = customerAddress.trim().isNotEmpty;

    final hasGps = _job.gpsLatitude != null &&
        _job.gpsLongitude != null &&
        (_job.gpsLatitude != 0 || _job.gpsLongitude != 0);

    return Scaffold(
      appBar: AppBar(
        title: Text(_job.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_outlined),
            tooltip: t.commonRefresh,
            onPressed: _isActionLoading ? null : _jobRepo.fetchRecords,
          ),
        ],
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header card
                Card(
                  elevation: 0,
                  color: Theme.of(context).colorScheme.surface,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: BorderSide(
                      color: Theme.of(context).dividerColor.withOpacity(0.4),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Title + status chip
                        Text(
                          _job.name,
                          style: Theme.of(context)
                              .textTheme
                              .titleLarge
                              ?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: statusColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(
                              color: statusColor.withOpacity(0.5),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.circle_rounded,
                                size: 10,
                                color: statusColor,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                _statusLabel(t, _job.state),
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: statusColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            const Icon(FluentIcons.person_12_regular, size: 20),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                _job.customer.name.isEmpty
                                    ? t.jobDetailNoCustomer
                                    : _job.customer.name,
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Icon(PhosphorIcons.hardHat(PhosphorIconsStyle.regular), size: 20),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                _job.assignedTo.name.isEmpty
                                    ? t.jobDetailUnassigned
                                    : _job.assignedTo.name,
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // Schedule card (Schedule + Start + End + Duration)
                Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    // Added a subtle border for better definition in a flat UI
                    side: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // 1. SECTION HEADER (Schedule)
                        _sectionHeader(
                          context,
                          // Fluent UI: Calendar with Clock (Schedule/Appointment)
                          FluentIcons.calendar_clock_24_regular,
                          t.jobDetailSchedule,
                        ),
                        const SizedBox(height: 12),

                        // 2. SCHEDULE TYPE/DATE
                        Row(
                          children: [
                            // Fluent UI: Standard Calendar Icon
                            const Icon(FluentIcons.calendar_ltr_24_regular, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                _formatSchedule(t),
                                style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w500),
                              ),
                            ),
                          ],
                        ),
                        const Divider(height: 16), // Divider for visual separation

                        // 3. START TIME
                        Row(
                          children: [
                            // Fluent UI: Clock Arrow In (Start/Arrival Time)
                            const Icon(FluentIcons.arrow_circle_right_24_regular, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                '${t.jobDetailStart}: ${_formatDateTime(t, _job.startTime)}',
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),

                        // 4. END TIME
                        Row(
                          children: [
                            // Fluent UI: Clock Arrow Out (End/Departure Time)
                            const Icon(FluentIcons.arrow_circle_down_24_regular, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                '${t.jobDetailEnd}: ${_formatDateTime(t, _job.endTime)}',
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),

                        // 5. DURATION
                        Row(
                          children: [
                            // Fluent UI: Timer (Duration/Time elapsed)
                            const Icon(FluentIcons.timer_24_regular, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                '${t.jobDetailDuration}: ${_formatDuration(t)}',
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // Location card (GPS + address)
                if (hasGps || hasAddress)
                  Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _sectionHeader(
                            context,
                            Icons.location_on_rounded,
                            t.jobDetailLocation,
                          ),
                          const Divider(height: 16),

                          // GPS line (only if valid coordinates)
                          if (hasGps) ...[
                            Row(
                              children: [
                                const Icon(FluentIcons.location_24_regular, size: 18),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    '${t.jobDetailLatShort}: ${_job.gpsLatitude!.toStringAsFixed(6)}, '
                                        '${t.jobDetailLngShort}: ${_job.gpsLongitude!.toStringAsFixed(6)}',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyMedium,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                          ],

                          // Address line (from partner)
                          if (hasAddress) ...[
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(FluentIcons.home_24_regular, size: 18),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    customerAddress,
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyMedium,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                          ],

                          OutlinedButton.icon(
                            onPressed: _openExternalMap,
                            icon: const Icon(FluentIcons.map_24_regular),
                            label: Text(t.jobDetailOpenInMaps),
                          ),
                        ],
                      ),
                    ),
                  ),

                const SizedBox(height: 12),

                // Notes card
                if ((_job.note ?? '').isNotEmpty ||
                    (_job.customerNotes ?? '').isNotEmpty)
                  Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _sectionHeader(
                            context,
                            Icons.sticky_note_2_outlined,
                            t.jobDetailNotes,
                          ),
                          const SizedBox(height: 8),
                          if ((_job.customerNotes ?? '').isNotEmpty) ...[
                            Text(
                              t.jobDetailCustomerNotes,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(height: 4),
                            Text(_job.customerNotes!),
                            const SizedBox(height: 12),
                          ],
                          if ((_job.note ?? '').isNotEmpty) ...[
                            Text(
                              t.jobDetailInternalNotes,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(height: 4),
                            Text(_job.note!),
                          ],
                        ],
                      ),
                    ),
                  ),

                const SizedBox(height: 12),

                // Photos card – multi upload + thumbnails (card tappable anywhere)
                InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap:
                  (_isActionLoading || _uploadingPhoto) ? null : _addPhotos,
                  child: Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.photo_library_outlined, size: 20),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  t.jobDetailPhotos,
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleMedium
                                      ?.copyWith(fontWeight: FontWeight.w600),
                                ),
                              ),
                              FilledButton.icon(
                                onPressed:
                                (_isActionLoading || _uploadingPhoto)
                                    ? null
                                    : _addPhotos,
                                icon: _uploadingPhoto
                                    ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                                    : const Icon(Icons.camera_alt_rounded),
                                label: Text(t.jobDetailAddPhotos),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            t.jobDetailPhotosHint,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          if (photos.isNotEmpty) ...[
                            const SizedBox(height: 12),
                            SizedBox(
                              height: 80,
                              child: ListView.separated(
                                scrollDirection: Axis.horizontal,
                                itemCount: photos.length,
                                separatorBuilder: (_, __) =>
                                const SizedBox(width: 8),
                                itemBuilder: (context, index) {
                                  final p = photos[index];
                                  final url = p.imageUrl;

                                  if (url == null || url.isEmpty) {
                                    // No URL – show placeholder
                                    return Container(
                                      width: 80,
                                      height: 80,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color: Colors.grey[200],
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: const Icon(
                                        Icons.image_not_supported_rounded,
                                        size: 22,
                                      ),
                                    );
                                  }

                                  debugPrint('Photo URL: $url');

                                  return GestureDetector(
                                    onTap: () =>
                                        _openPhotoViewer(url, cookieHeader),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(12),
                                      child: CachedNetworkImage(
                                        imageUrl: url,
                                        httpHeaders: cookieHeader,
                                        width: 80,
                                        height: 80,
                                        fit: BoxFit.cover,
                                        placeholder: (context, _) => Container(
                                          width: 80,
                                          height: 80,
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                            color: Colors.grey[200],
                                            borderRadius:
                                            BorderRadius.circular(12),
                                          ),
                                          child: const SizedBox(
                                            width: 16,
                                            height: 16,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2,
                                            ),
                                          ),
                                        ),
                                        errorWidget: (context, _, __) =>
                                            Container(
                                              width: 80,
                                              height: 80,
                                              alignment: Alignment.center,
                                              decoration: BoxDecoration(
                                                color: Colors.grey[200],
                                                borderRadius:
                                                BorderRadius.circular(12),
                                              ),
                                              child: const Icon(
                                                Icons.broken_image_rounded,
                                                size: 22,
                                              ),
                                            ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // Authentication card + signature preview
                InkWell(
                  onTap: _isActionLoading ? null : _openAuthentication,
                  borderRadius: BorderRadius.circular(16),
                  child: Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              _sectionHeader(
                                context,
                                Icons.shield_outlined,
                                t.jobDetailAuth,
                              ),
                              const Spacer(),
                              IconButton(
                                icon: const Icon(Icons.edit_note_rounded),
                                tooltip: t.jobDetailAuthTooltip,
                                onPressed: _isActionLoading
                                    ? null
                                    : _openAuthentication,
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            t.jobDetailAuthHint,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),

                          if (signatureBytes != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              t.jobDetailAuthSavedSignature,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(height: 8),
                            Center(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.grey[50],
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                      color: Colors.grey.shade300),
                                ),
                                padding: const EdgeInsets.all(8),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.memory(
                                    signatureBytes!,
                                    height: 80,
                                    fit: BoxFit.contain,
                                    errorBuilder: (_, __, ___) => SizedBox(
                                      height: 80,
                                      width: 160,
                                      child: Center(
                                        child: Icon(
                                          Icons.broken_image_rounded,
                                          color: Colors.grey[400],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          if (_isActionLoading)
            Container(
              color: Colors.black.withOpacity(0.05),
              child: const Center(
                child: CircularProgressIndicator(),
              ),
            ),
        ],
      ),

      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: _buildActionButtons(t),
          ),
        ),
      ),
    );
  }
}

/// Fullscreen screen with Syncfusion Signature Pad
class SignatureAuthScreen extends StatefulWidget {
  final JobRecord job;

  const SignatureAuthScreen({
    Key? key,
    required this.job,
  }) : super(key: key);

  @override
  State<SignatureAuthScreen> createState() => _SignatureAuthScreenState();
}

class _SignatureAuthScreenState extends State<SignatureAuthScreen> {
  final GlobalKey<SfSignaturePadState> _signatureKey =
  GlobalKey<SfSignaturePadState>();

  bool _saving = false;

  void _clear() {
    _signatureKey.currentState?.clear();
  }

  void _save() async {
    final t = AppLocalizations.of(context)!;
    final padState = _signatureKey.currentState;
    if (padState == null) return;

    setState(() => _saving = true);
    try {
      final ui.Image image = await padState.toImage(pixelRatio: 3.0);
      final ByteData? bytes =
      await image.toByteData(format: ui.ImageByteFormat.png);

      if (bytes == null) {
        throw Exception('Failed to convert signature to bytes');
      }

      final Uint8List pngBytes = bytes.buffer.asUint8List(
        bytes.offsetInBytes,
        bytes.lengthInBytes,
      );
      final String base64Signature = base64Encode(pngBytes);

      final env = context.read<OdooEnvironment>();
      final jobRepo = env.of<JobRepository>();

      await jobRepo.saveSignature(
        jobId: widget.job.id,
        base64Signature: base64Signature,
      );

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.authSaveFailed}: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text('${t.jobDetailAuth} – ${widget.job.name}'),
      ),
      body: Column(
        children: [
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Text(
              t.authSignInstruction,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade400),
                ),
                child: SfSignaturePad(
                  key: _signatureKey,
                  backgroundColor: Colors.transparent,
                  strokeColor: Colors.black,
                  minimumStrokeWidth: 1.0,
                  maximumStrokeWidth: 3.0,
                ),
              ),
            ),
          ),
          Padding(
            padding:
            const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            child: Row(
              children: [
                TextButton.icon(
                  onPressed: _saving ? null : _clear,
                  icon: const Icon(Icons.clear_rounded),
                  label: Text(t.commonClear),
                ),
                const Spacer(),
                FilledButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: _saving
                      ? const SizedBox(
                    height: 16,
                    width: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                      : const Icon(Icons.save_rounded),
                  label: Text(t.commonSave),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Simple full-screen photo viewer
class PhotoViewerPage extends StatelessWidget {
  final String imageUrl;
  final Map<String, String>? headers;

  const PhotoViewerPage({
    Key? key,
    required this.imageUrl,
    this.headers,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(t.photoViewerTitle),
      ),
      backgroundColor: Colors.black,
      body: Center(
        child: InteractiveViewer(
          maxScale: 5,
          child: CachedNetworkImage(
            imageUrl: imageUrl,
            httpHeaders: headers,
            fit: BoxFit.contain,
            placeholder: (context, _) => const Center(
              child: CircularProgressIndicator(),
            ),
            errorWidget: (context, _, __) => const Icon(
              Icons.broken_image_rounded,
              color: Colors.white70,
              size: 48,
            ),
          ),
        ),
      ),
    );
  }
}
