import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import '../../odoo/odoo_repository/lib/odoo_repository.dart';

/// Record class for the `taqnix_field_service.job` model.
class JobRecord extends Equatable implements OdooRecord {
  final int id;
  final String name;
  final PartnerRecord customer;
  final UserRecord assignedTo;

  /// Text address from Odoo (Char field, e.g. "Al Khuwair, Muscat, Oman")
  final String? address;

  final DateTime? scheduledDate;
  final DateTime? startTime;
  final DateTime? endTime;

  // ✅ FIXED: Added invoiceId field
  final int? invoiceId;

  final double durationHours;

  /// Odoo selection: draft / assigned / in_progress / done / cancelled
  final String state;

  final double? gpsLatitude;
  final double? gpsLongitude;

  final double? gpsDoneLatitude;
  final double? gpsDoneLongitude;

  final String? note;
  final String? customerNotes;

  final bool canStart;
  final bool canFinish;

  /// Photos (photo_ids one2many)
  final List<JobPhotoRecord> photos;

  /// Signature stored as base64 (binary field)
  final String? signature;

  JobRecord({
    required this.id,
    required this.name,
    required this.customer,
    required this.assignedTo,
    this.address,
    this.scheduledDate,
    this.startTime,
    this.endTime,
    this.invoiceId, // ✅ FIXED: Added to constructor
    required this.durationHours,
    required this.state,
    this.gpsLatitude,
    this.gpsLongitude,
    this.gpsDoneLatitude,
    this.gpsDoneLongitude,
    this.note,
    this.customerNotes,
    required this.canStart,
    required this.canFinish,
    required this.photos,
    this.signature,
  });

  @override
  List<Object?> get props => [
    id,
    name,
    customer,
    assignedTo,
    address,
    scheduledDate,
    startTime,
    endTime,
    invoiceId, // ✅ FIXED: Added to props
    durationHours,
    state,
    gpsLatitude,
    gpsLongitude,
    gpsDoneLatitude,
    gpsDoneLongitude,
    note,
    customerNotes,
    canStart,
    canFinish,
    photos,
    signature,
  ];

  JobRecord copyWith({
    int? id,
    String? name,
    PartnerRecord? customer,
    UserRecord? assignedTo,
    String? address,
    DateTime? scheduledDate,
    DateTime? startTime,
    DateTime? endTime,
    int? invoiceId, // ✅ FIXED: Added to copyWith
    double? durationHours,
    String? state,
    double? gpsLatitude,
    double? gpsLongitude,
    double? gpsDoneLatitude,
    double? gpsDoneLongitude,
    String? note,
    String? customerNotes,
    bool? canStart,
    bool? canFinish,
    List<JobPhotoRecord>? photos,
    String? signature,
  }) {
    return JobRecord(
      id: id ?? this.id,
      name: name ?? this.name,
      customer: customer ?? this.customer,
      assignedTo: assignedTo ?? this.assignedTo,
      address: address ?? this.address,
      scheduledDate: scheduledDate ?? this.scheduledDate,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      invoiceId: invoiceId ?? this.invoiceId, // ✅ FIXED
      durationHours: durationHours ?? this.durationHours,
      state: state ?? this.state,
      gpsLatitude: gpsLatitude ?? this.gpsLatitude,
      gpsLongitude: gpsLongitude ?? this.gpsLongitude,
      gpsDoneLatitude: gpsDoneLatitude ?? this.gpsDoneLatitude,
      gpsDoneLongitude: gpsDoneLongitude ?? this.gpsDoneLongitude,
      note: note ?? this.note,
      customerNotes: customerNotes ?? this.customerNotes,
      canStart: canStart ?? this.canStart,
      canFinish: canFinish ?? this.canFinish,
      photos: photos ?? this.photos,
      signature: signature ?? this.signature,
    );
  }

  @override
  Map<String, dynamic> toVals() {
    return {
      'id': id,
      'name': name,
      'partner_id': customer.toVals(),
      'user_id': assignedTo.toVals(),
      'address': address,
      'scheduled_date': _dateToOdooString(scheduledDate),
      'start_time': _dateToOdooString(startTime),
      'end_time': _dateToOdooString(endTime),
      // We generally don't push invoiceId back to Odoo from the app, but keeping it mapped is safe
      'invoice_id': invoiceId,
      'duration_hours': durationHours,
      'state': state,
      'gps_latitude': gpsLatitude,
      'gps_longitude': gpsLongitude,
      'gps_done_latitude': gpsDoneLatitude,
      'gps_done_longitude': gpsDoneLongitude,
      'note': note,
      'customer_notes': customerNotes,
      'can_start': canStart,
      'can_finish': canFinish,
      'signature': signature,
      'photo_ids': photos.map((p) => p.toVals()).toList(),
    };
  }

  @override
  Map<String, dynamic> toJson() => toVals();

  static JobRecord fromJson(Map<dynamic, dynamic> json) {
    return JobRecord(
      id: json['id'] as int? ?? 0,
      name: _parseString(json['name']),
      customer: _parsePartner(json['partner_id']),
      assignedTo: _parseUser(json['user_id']),
      address: _parseNullableString(json['address']),
      scheduledDate: _parseDateTime(json['scheduled_date']),
      startTime: _parseDateTime(json['start_time']),
      endTime: _parseDateTime(json['end_time']),
      invoiceId: _parseInvoiceId(json['invoice_id']), // ✅ FIXED: Safely parsed from JSON
      durationHours: _parseDouble(json['duration_hours']),
      state: _parseString(json['state']),
      gpsLatitude: _parseNullableDouble(json['gps_latitude']),
      gpsLongitude: _parseNullableDouble(json['gps_longitude']),
      gpsDoneLatitude: _parseNullableDouble(json['gps_done_latitude']),
      gpsDoneLongitude: _parseNullableDouble(json['gps_done_longitude']),
      note: _parseNullableString(json['note']),
      customerNotes: _parseNullableString(json['customer_notes']),
      canStart: _parseBool(json['can_start']),
      canFinish: _parseBool(json['can_finish']),
      photos: _parsePhotoList(json['photo_ids']),
      signature: _parseSignature(json['signature']),
    );
  }

  // ----------------- helpers -----------------

  // ✅ ADDED: Helper to safely extract the ID from an Odoo Many2one field
  static int? _parseInvoiceId(dynamic raw) {
    if (raw == null || raw == false) return null;
    if (raw is Map) return raw['id'] as int?; // Handles {'id': 1, 'name': 'INV/001'}
    if (raw is List && raw.isNotEmpty) return raw[0] as int?; // Handles [1, 'INV/001']
    if (raw is int) return raw;
    return null;
  }

  static PartnerRecord _parsePartner(dynamic raw) {
    if (raw == null || raw == false) return PartnerRecord(id: 0, name: '');
    if (raw is Map) return PartnerRecord.fromJson(raw);
    if (raw is List && raw.length >= 2) {
      final id = raw[0] is int ? raw[0] as int : int.tryParse(raw[0].toString()) ?? 0;
      final name = _parseString(raw[1]);
      return PartnerRecord(id: id, name: name);
    }
    return PartnerRecord(id: 0, name: '');
  }

  static UserRecord _parseUser(dynamic raw) {
    if (raw == null || raw == false) return UserRecord(id: 0, name: '');
    if (raw is Map) return UserRecord.fromJson(raw);
    if (raw is List && raw.length >= 2) {
      final id = raw[0] is int ? raw[0] as int : int.tryParse(raw[0].toString()) ?? 0;
      final name = _parseString(raw[1]);
      return UserRecord(id: id, name: name);
    }
    return UserRecord(id: 0, name: '');
  }

  static String? _parseSignature(dynamic value) {
    if (value == null || value == false) return null;
    if (value is String) return value;
    return value.toString();
  }

  static String? _parseNullableString(dynamic value) {
    if (value == null || value is bool) return null;
    if (value is String) {
      final v = value.trim();
      return (v.isEmpty || v.toLowerCase() == 'false') ? null : v;
    }
    final v = value.toString();
    return v.toLowerCase() == 'false' ? null : v;
  }

  static String _parseString(dynamic value) {
    if (value == null) return '';
    if (value is String) return value;
    return value.toString();
  }

  static double _parseDouble(dynamic value) {
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }

  static double? _parseNullableDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  static bool _parseBool(dynamic value) {
    if (value is bool) return value;
    if (value is int) return value != 0;
    if (value is String) {
      final v = value.toLowerCase();
      return v == 'true' || v == '1' || v == 'yes';
    }
    return false;
  }

  static DateTime? _parseDateTime(dynamic value) {
    if (value == null) return null;
    if (value is DateTime) return value;
    if (value is String && value.isNotEmpty) {
      final base = value.replaceFirst(' ', 'T');
      final utc = DateTime.tryParse('${base}Z');
      if (utc == null) return null;
      return utc.toLocal();
    }
    return null;
  }

  static String? _dateToOdooString(DateTime? value) {
    if (value == null) return null;
    return value.toIso8601String().replaceFirst('T', ' ').split('.').first;
  }

  static List<JobPhotoRecord> _parsePhotoList(dynamic value) {
    if (value == null || value == false) return <JobPhotoRecord>[];
    if (value is List) {
      return value
          .where((e) => e is Map)
          .map((e) => JobPhotoRecord.fromJson(e as Map<dynamic, dynamic>))
          .toList();
    }
    return <JobPhotoRecord>[];
  }
}

/// Nested record for Customer (partner_id).
class PartnerRecord extends Equatable {
  final int id;
  final String name;

  // Address / contact fields
  final String street;
  final String street2;
  final String city;
  final String zip;
  final String phone;
  final String email;

  // State / country (Many2one)
  final int stateId;
  final String stateName;
  final int countryId;
  final String countryName;

  PartnerRecord({
    required this.id,
    required this.name,
    this.street = '',
    this.street2 = '',
    this.city = '',
    this.zip = '',
    this.phone = '',
    this.email = '',
    this.stateId = 0,
    this.stateName = '',
    this.countryId = 0,
    this.countryName = '',
  });

  @override
  List<Object?> get props => [
    id, name, street, street2, city, zip, phone, email, stateId, stateName, countryId, countryName,
  ];

  PartnerRecord copyWith({
    int? id, String? name, String? street, String? street2, String? city, String? zip,
    String? phone, String? email, int? stateId, String? stateName, int? countryId, String? countryName,
  }) {
    return PartnerRecord(
      id: id ?? this.id,
      name: name ?? this.name,
      street: street ?? this.street,
      street2: street2 ?? this.street2,
      city: city ?? this.city,
      zip: zip ?? this.zip,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      stateId: stateId ?? this.stateId,
      stateName: stateName ?? this.stateName,
      countryId: countryId ?? this.countryId,
      countryName: countryName ?? this.countryName,
    );
  }

  Map<String, dynamic> toVals() => {
    'id': id, 'name': name, 'street': street, 'street2': street2, 'city': city,
    'zip': zip, 'phone': phone, 'email': email,
    'state_id': stateId == 0 ? null : stateId,
    'country_id': countryId == 0 ? null : countryId,
  };

  static String _safeString(dynamic value) {
    if (value == null || value == false) return '';
    if (value is String) return value;
    return value.toString();
  }

  static PartnerRecord fromJson(Map<dynamic, dynamic> json) {
    final dynamic rawState = json['state_id'];
    int stateId = 0;
    String stateName = '';
    if (rawState is Map) {
      stateId = rawState['id'] as int? ?? 0;
      stateName = _safeString(rawState['name']);
    }

    final dynamic rawCountry = json['country_id'];
    int countryId = 0;
    String countryName = '';
    if (rawCountry is Map) {
      countryId = rawCountry['id'] as int? ?? 0;
      countryName = _safeString(rawCountry['name']);
    }

    return PartnerRecord(
      id: json['id'] as int? ?? 0,
      name: _safeString(json['name']),
      street: _safeString(json['street']),
      street2: _safeString(json['street2']),
      city: _safeString(json['city']),
      zip: _safeString(json['zip']),
      phone: _safeString(json['phone']),
      email: _safeString(json['email']),
      stateId: stateId,
      stateName: stateName,
      countryId: countryId,
      countryName: countryName,
    );
  }
}

/// Nested record for Assigned User (user_id).
class UserRecord extends Equatable {
  final int id;
  final String name;

  UserRecord({required this.id, required this.name});

  @override
  List<Object?> get props => [id, name];

  UserRecord copyWith({int? id, String? name}) {
    return UserRecord(
      id: id ?? this.id,
      name: name ?? this.name,
    );
  }

  Map<String, dynamic> toVals() => {'id': id, 'name': name};

  static UserRecord fromJson(Map<dynamic, dynamic> json) {
    return UserRecord(
      id: json['id'] as int? ?? 0,
      name: json['name'] as String? ?? '',
    );
  }
}

/// Nested record for Job Photos (photo_ids).
class JobPhotoRecord extends Equatable {
  final int id;
  final String name;
  final int sequence;
  final String? imageUrl;

  JobPhotoRecord({
    required this.id,
    required this.name,
    required this.sequence,
    this.imageUrl,
  });

  @override
  List<Object?> get props => [id, name, sequence, imageUrl];

  JobPhotoRecord copyWith({
    int? id, String? name, int? sequence, String? imageUrl,
  }) {
    return JobPhotoRecord(
      id: id ?? this.id,
      name: name ?? this.name,
      sequence: sequence ?? this.sequence,
      imageUrl: imageUrl ?? this.imageUrl,
    );
  }

  Map<String, dynamic> toVals() => {
    'id': id, 'name': name, 'sequence': sequence, 'image_url': imageUrl,
  };

  static JobPhotoRecord fromJson(Map<dynamic, dynamic> json) {
    final dynamic rawUrl = json['image_url'];
    String? url;
    if (rawUrl is String) {
      final trimmed = rawUrl.trim();
      if (trimmed.isNotEmpty && trimmed.toLowerCase() != 'false') {
        url = trimmed;
      }
    }

    return JobPhotoRecord(
      id: json['id'] as int? ?? 0,
      name: json['name'] is String ? json['name'] as String : '',
      sequence: json['sequence'] as int? ?? 10,
      imageUrl: url,
    );
  }
}