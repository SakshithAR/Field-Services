import 'package:field_service/src/features/calendar/calendar_page.dart';
import 'package:field_service/src/features/jobs/job_card.dart';
import 'package:field_service/src/features/map/map_page.dart';
import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';
import 'package:field_service/src/features/home/home_page.dart';
//import 'package:field_service/src/features/profile/presentation/profile_page.dart';
import 'package:field_service/l10n/app_localizations.dart';

class JobsPage extends StatelessWidget {
  const JobsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    // For now dummy jobs – later replace with API data
    final jobs = [
      {
        'title': 'AC Maintenance - Villa 12',
        'customer': 'Mr. Ahmed',
        'time': 'Today • 10:30 AM',
        'status': 'in_progress',
        'address': 'Dubai Marina',
      },
      {
        'title': 'Site Inspection - Warehouse',
        'customer': 'Blue Bridge LLC',
        'time': 'Today • 3:00 PM',
        'status': 'assigned',
        'address': 'Jebel Ali',
      },
      {
        'title': 'Generator Checkup',
        'customer': 'UV Gulf',
        'time': 'Yesterday',
        'status': 'done',
        'address': 'Dubai Investment Park',
      },
    ];

    return Scaffold(
      appBar: AppBar(
        // 👇 Uses localized "jobs" (English: Jobs, Arabic: الوظائف)
        title: Text(t.jobs),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        itemCount: jobs.length,
        itemBuilder: (context, index) {
          final job = jobs[index];
          return Container(); // your JobCard / layout later
        },
      ),
    );
  }
}
