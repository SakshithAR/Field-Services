import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:field_service/l10n/app_localizations.dart';
import '../../odoo/odoo_repository/lib/odoo_repository.dart';
import 'job_record.dart';
import 'job_repository.dart';

class JobListPage extends StatefulWidget {
  const JobListPage({Key? key}) : super(key: key);

  @override
  State<JobListPage> createState() => _JobListPageState();
}

class _JobListPageState extends State<JobListPage> {
  late JobRepository _jobRepo;
  final TextEditingController _searchController = TextEditingController();
  bool _showSearch = false;

  String _filterStatus = 'All';
  String _sortBy = 'Scheduled (Nearest)';

  // 0 = assigned, 1 = in_progress, 2 = done, 3 = All
  int _statusTabIndex = 3;

  @override
  void initState() {
    super.initState();
    final env = context.read<OdooEnvironment>();
    env.add(JobRepository(env));
    _jobRepo = env.of<JobRepository>();
    _fetchJobs();
  }

  Future<void> _fetchJobs() async {
    await _jobRepo.fetchRecords();
  }

  Future<void> _refreshData() async {
    await _jobRepo.fetchRecords();
  }

  String _statusLabel(AppLocalizations t, String status) {
    switch (status) {
      case 'draft':
        return t.statusDraft;
      case 'assigned':
        return t.statusAssigned;
      case 'in_progress':
        return t.statusInProgress;
      case 'done':
        return t.statusDone;
      case 'cancelled':
        return t.statusCancelled;
      case 'All':
        return t.tabAll;
      default:
        return status;
    }
  }

  String _formatDateTime(AppLocalizations t, DateTime? dt) {
    if (dt == null) return t.noSchedule;
    final local = dt.toLocal();
    final day = local.day.toString().padLeft(2, '0');
    final month = local.month.toString().padLeft(2, '0');
    final year = local.year.toString();
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return '$day/$month/$year • $hour:$minute';
  }

  // map bottom tab index -> filter status string
  String _statusFromIndex(int index) {
    switch (index) {
      case 0:
        return 'assigned';
      case 1:
        return 'in_progress';
      case 2:
        return 'done';
      default:
        return 'All';
    }
  }

  // map filter status string -> bottom tab index (for sync)
  int _indexFromStatus(String status) {
    switch (status) {
      case 'assigned':
        return 0;
      case 'in_progress':
        return 1;
      case 'done':
        return 2;
      case 'All':
        return 3;
      default:
        return 3; // fallback to "All"
    }
  }

  List<JobRecord> _applyFilters(List<JobRecord> list) {
    final query = _searchController.text.toLowerCase();

    var filtered = list.where((j) {
      final name = j.name.toLowerCase();
      final customerName = j.customer.name.toLowerCase();
      final matchesSearch =
          query.isEmpty || name.contains(query) || customerName.contains(query);

      final matchesStatus =
          _filterStatus == 'All' || j.state == _filterStatus;

      return matchesSearch && matchesStatus;
    }).toList();

    switch (_sortBy) {
      case 'Scheduled (Farthest)':
        filtered.sort((a, b) {
          final ad = a.scheduledDate ?? DateTime.fromMillisecondsSinceEpoch(0);
          final bd = b.scheduledDate ?? DateTime.fromMillisecondsSinceEpoch(0);
          return bd.compareTo(ad);
        });
        break;
      case 'Customer (A-Z)':
        filtered.sort((a, b) => a.customer.name.compareTo(b.customer.name));
        break;
      case 'Status':
        filtered.sort((a, b) => a.state.compareTo(b.state));
        break;
      default: // Scheduled (Nearest)
        filtered.sort((a, b) {
          final ad = a.scheduledDate ?? DateTime.fromMillisecondsSinceEpoch(0);
          final bd = b.scheduledDate ?? DateTime.fromMillisecondsSinceEpoch(0);
          return ad.compareTo(bd);
        });
    }

    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: _showSearch ? _buildSearchAppBar(t) : _buildNormalAppBar(t),
      body: StreamBuilder<List<JobRecord>>(
        stream: _jobRepo.recordStream,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final allJobs = snapshot.data!;
          final statuses = <String>{for (var j in allJobs) j.state}.toList()
            ..sort();

          final display = _applyFilters(allJobs);

          return Column(
            children: [
              if (!_showSearch) _buildFilterChips(t, statuses),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: _refreshData,
                  child: display.isEmpty
                      ? _buildEmptyState(t)
                      : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: display.length,
                    itemBuilder: (ctx, i) {
                      final job = display[i];
                      return JobCard(
                        title: job.name,
                        customer: job.customer.name,
                        time: _formatDateTime(
                          t,
                          job.scheduledDate ?? job.startTime,
                        ),
                        status: job.state,
                        // TODO: later use full partner address
                        address: job.customer.name,
                      );
                    },
                  ),
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // later: open "New Job" form
        },
        child: const Icon(FluentIcons.add_24_regular),
      ),

      // Bottom app bar tabs for status filters
      bottomNavigationBar: Builder(
        builder: (ctx) {
          final t = AppLocalizations.of(ctx)!;
          return BottomNavigationBar(
            currentIndex: _statusTabIndex,
            type: BottomNavigationBarType.fixed,
            onTap: (index) {
              setState(() {
                _statusTabIndex = index;
                _filterStatus = _statusFromIndex(index);
              });
            },
            items: [
              BottomNavigationBarItem(
                icon: const Icon(FluentIcons.person_24_regular),
                label: t.tabAssigned,
              ),
              BottomNavigationBarItem(
                icon: const Icon(FluentIcons.timer_24_regular),
                label: t.tabInProgress,
              ),
              BottomNavigationBarItem(
                icon: const Icon(FluentIcons.checkmark_circle_24_regular),
                label: t.tabDone,
              ),
              BottomNavigationBarItem(
                icon: const Icon(FluentIcons.list_24_regular),
                label: t.tabAll,
              ),
            ],
          );
        },
      ),
    );
  }

  AppBar _buildNormalAppBar(AppLocalizations t) => AppBar(
    title: Text(t.jobs),
    centerTitle: true,
    actions: [
      IconButton(
        icon: const Icon(FluentIcons.search_24_regular),
        onPressed: () => setState(() {
          _showSearch = true;
          _searchController.clear();
        }),
      ),
      IconButton(
        icon: const Icon(FluentIcons.filter_24_regular),
        onPressed: _showFilterDialog,
      ),
    ],
  );

  AppBar _buildSearchAppBar(AppLocalizations t) => AppBar(
    automaticallyImplyLeading: false,
    title: TextField(
      controller: _searchController,
      autofocus: true,
      decoration: InputDecoration(
        hintText: t.searchJobsHint,
        border: InputBorder.none,
        suffixIcon: IconButton(
          icon: const Icon(FluentIcons.dismiss_24_regular),
          onPressed: () => setState(() {
            _showSearch = false;
            _searchController.clear();
          }),
        ),
      ),
      onChanged: (_) => setState(() {}),
    ),
  );

  Widget _buildFilterChips(AppLocalizations t, List<String> statuses) {
    // Include "All" at the beginning
    final all = ['All', ...statuses];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: all
            .map(
              (s) => Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(_statusLabel(t, s)),
              selected: _filterStatus == s,
              onSelected: (_) => setState(() {
                _filterStatus = s;
                _statusTabIndex = _indexFromStatus(s);
              }),
            ),
          ),
        )
            .toList(),
      ),
    );
  }

  Widget _buildEmptyState(AppLocalizations t) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            FluentIcons.task_list_square_rtl_24_regular,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            t.emptyJobsTitle,
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
          const SizedBox(height: 8),
          Text(
            t.emptyJobsSubtitle,
            style: TextStyle(color: Colors.grey[500]),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            icon: const Icon(FluentIcons.add_24_regular, size: 18),
            label: Text(t.emptyJobsAddButton),
            onPressed: () {
              // same as FAB or open form later
            },
          ),
        ],
      ),
    );
  }

  void _showFilterDialog() {
    final t = AppLocalizations.of(context)!;

    const options = [
      'Scheduled (Nearest)',
      'Scheduled (Farthest)',
      'Customer (A-Z)',
      'Status',
    ];

    String _labelForOption(String opt) {
      switch (opt) {
        case 'Scheduled (Nearest)':
          return t.sortScheduledNearest;
        case 'Scheduled (Farthest)':
          return t.sortScheduledFarthest;
        case 'Customer (A-Z)':
          return t.sortCustomerAZ;
        case 'Status':
          return t.sortStatus;
        default:
          return opt;
      }
    }

    showModalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              t.sortBy,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            for (var opt in options)
              RadioListTile<String>(
                title: Text(_labelForOption(opt)),
                value: opt,
                groupValue: _sortBy,
                onChanged: (v) {
                  if (v != null) setState(() => _sortBy = v);
                  Navigator.pop(ctx);
                },
              ),
          ],
        ),
      ),
    );
  }
}

/// Job card UI
class JobCard extends StatelessWidget {
  final String title;
  final String customer;
  final String time;
  final String status;
  final String address;

  const JobCard({
    super.key,
    required this.title,
    required this.customer,
    required this.time,
    required this.status,
    required this.address,
  });

  Color _statusColor(BuildContext context) {
    switch (status) {
      case 'draft':
        return Colors.grey;
      case 'assigned':
        return Colors.blue;
      case 'in_progress':
        return Colors.orange;
      case 'done':
        return Colors.green;
      case 'cancelled':
        return Colors.red;
      default:
        return Theme.of(context).colorScheme.primary;
    }
  }

  String _statusLabel(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    switch (status) {
      case 'draft':
        return t.statusDraft;
      case 'assigned':
        return t.statusAssigned;
      case 'in_progress':
        return t.statusInProgress;
      case 'done':
        return t.statusDone;
      case 'cancelled':
        return t.statusCancelled;
      default:
        return status;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _statusColor(context);

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          // later: open Job Details page
        },
        child: Row(
          children: [
            // Left colored stripe
            Container(
              width: 5,
              height: 92,
              decoration: BoxDecoration(
                color: color,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(12),
                  bottomLeft: Radius.circular(12),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title + status chip
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            title,
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(fontWeight: FontWeight.w600),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: color.withOpacity(0.4)),
                          ),
                          child: Text(
                            _statusLabel(context),
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: color,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(Icons.person_outline, size: 16),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            customer,
                            style: Theme.of(context).textTheme.bodySmall,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        const Icon(Icons.location_on_outlined, size: 16),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            address,
                            style: Theme.of(context).textTheme.bodySmall,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        const Icon(Icons.access_time, size: 16),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            time,
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(color: Colors.grey[600]),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
