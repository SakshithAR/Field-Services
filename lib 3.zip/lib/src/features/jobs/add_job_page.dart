import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:field_service/l10n/app_localizations.dart';
import '../../odoo/odoo_repository/lib/odoo_repository.dart';
import 'job_repository.dart';

class AddJobPage extends StatefulWidget {
  const AddJobPage({Key? key}) : super(key: key);

  @override
  State<AddJobPage> createState() => _AddJobPageState();
}

class _AddJobPageState extends State<AddJobPage> {
  late JobRepository _jobRepo;

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _customerNotesController =
  TextEditingController();
  final TextEditingController _internalNotesController =
  TextEditingController();

  DateTime? _scheduledDate;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final env = context.read<OdooEnvironment>();
    _jobRepo = env.of<JobRepository>(); // repo already added in JobListPage

    // 🔹 Default to "now"
    _scheduledDate = DateTime.now();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _customerNotesController.dispose();
    _internalNotesController.dispose();
    super.dispose();
  }

  String _formatDateTime(AppLocalizations t, DateTime? dt) {
    if (dt == null) return t.addJobDateTimeNotSet;
    final local = dt.toLocal();
    final d = local.day.toString().padLeft(2, '0');
    final m = local.month.toString().padLeft(2, '0');
    final y = local.year.toString();
    final h = local.hour.toString().padLeft(2, '0');
    final min = local.minute.toString().padLeft(2, '0');
    return '$d/$m/$y • $h:$min';
  }

  Future<void> _pickScheduledDateTime() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now.subtract(const Duration(days: 1)),
      lastDate: now.add(const Duration(days: 365)),
    );

    if (date == null) return;

    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(now),
    );

    if (time == null) {
      setState(() => _scheduledDate = DateTime(date.year, date.month, date.day));
      return;
    }

    setState(() {
      _scheduledDate = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
    });
  }

  Future<void> _saveJob() async {
    final t = AppLocalizations.of(context)!;

    if (!_formKey.currentState!.validate()) return;

    setState(() => _saving = true);
    try {
      await _jobRepo.createJob(
        name: _titleController.text.trim(),
        scheduledDate: _scheduledDate,
        note: _internalNotesController.text,
        customerNotes: _customerNotesController.text,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t.addJobCreated)),
      );

      // return true to indicate "created"
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.addJobCreateFailed}: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => _saving = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(t.addJobTitle),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Job title
                  TextFormField(
                    controller: _titleController,
                    decoration: InputDecoration(
                      labelText: t.addJobJobTitleLabel,
                      hintText: t.addJobJobTitleHint,
                      border: const OutlineInputBorder(),
                    ),
                    validator: (val) {
                      if (val == null || val.trim().isEmpty) {
                        return t.addJobJobTitleRequired;
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),

                  // Scheduled date/time
                  Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      leading:
                      const Icon(FluentIcons.calendar_ltr_24_regular),
                      title: Text(t.addJobScheduledLabel),
                      subtitle: Text(_formatDateTime(t, _scheduledDate)),
                      trailing:
                      const Icon(FluentIcons.edit_24_regular, size: 20),
                      onTap: _pickScheduledDateTime,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Customer notes
                  TextFormField(
                    controller: _customerNotesController,
                    maxLines: 3,
                    decoration: InputDecoration(
                      labelText: t.addJobCustomerNotesLabel,
                      hintText: t.addJobCustomerNotesHint,
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Internal notes
                  TextFormField(
                    controller: _internalNotesController,
                    maxLines: 3,
                    decoration: InputDecoration(
                      labelText: t.addJobInternalNotesLabel,
                      hintText: t.addJobInternalNotesHint,
                      border: const OutlineInputBorder(),
                    ),
                  ),

                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),

          if (_saving)
            Container(
              color: Colors.black.withOpacity(0.05),
              child: const Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding:
          const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _saving ? null : _saveJob,
              icon: const Icon(FluentIcons.save_24_regular),
              label: Text(t.addJobCreateButton),
            ),
          ),
        ),
      ),
    );
  }
}
