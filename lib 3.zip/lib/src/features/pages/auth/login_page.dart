import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:field_service/main.dart'; // ✅ for MainOdooApp.rebuild(context)
import 'package:field_service/l10n/app_localizations.dart';
import 'package:field_service/src/config/app_config.dart';
import '../../../controllers/auth_controller.dart';

// ✅ FIX #2: correct import (same folder)
import 'server_config_screen.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();

  bool _loading = false;
  bool _obscurePassword = true;
  String? _error;

  late String _serverUrl;
  late String _dbName;

  @override
  void initState() {
    super.initState();

    final cfg = AppConfig.instance;
    _serverUrl = cfg.serverUrl;
    _dbName = cfg.dbName;

    // If not configured, open config screen
    if (!cfg.isConfigured) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _openServerConfig();
      });
    }
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _openServerConfig() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ServerConfigScreen(
          onConfigured: () {
            Navigator.of(_).pop();
          },
        ),
      ),
    );

    // refresh server info after returning
    final cfg = AppConfig.instance;
    setState(() {
      _serverUrl = cfg.serverUrl;
      _dbName = cfg.dbName;
    });
  }

  Future<void> _submit() async {
    final t = AppLocalizations.of(context)!;

    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();

    setState(() {
      _loading = true;
      _error = null;
    });

    final authController = context.read<AuthController>();
    final ok = await authController.loginWithPassword(
      login: _email.text.trim(),
      password: _password.text,
    );

    if (!mounted) return;

    if (ok) {
      // ✅ IMPORTANT: rebuild main providers + AuthGate will auto-open FieldServiceHome
      MainOdooApp.rebuild(context);

      setState(() => _loading = false);
    } else {
      setState(() {
        _loading = false;
        _error = t.loginError;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final t = AppLocalizations.of(context)!;

    final hasServer = _serverUrl.isNotEmpty && _dbName.isNotEmpty;
    final baseBg = const Color(0xFF16568c);

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.transparent,
        scrolledUnderElevation: 0,
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: RadialGradient(
            radius: 1.2,
            center: const Alignment(-0.4, -0.9),
            colors: [baseBg.withOpacity(0.82), baseBg],
          ),
        ),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: _buildCard(theme, t, hasServer),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCard(ThemeData theme, AppLocalizations t, bool hasServer) {
    final surfaceColor =
    theme.brightness == Brightness.dark ? const Color(0xFF0C1020) : Colors.white;

    final baseBg = const Color(0xFF16568c);

    return Container(
      decoration: BoxDecoration(
        color: surfaceColor.withOpacity(0.96),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.25),
            blurRadius: 25,
            offset: const Offset(0, 18),
          ),
          BoxShadow(
            color: baseBg.withOpacity(theme.brightness == Brightness.dark ? 0.06 : 0.45),
            blurRadius: 15,
            offset: const Offset(-6, -6),
          ),
        ],
        border: Border.all(color: baseBg.withOpacity(0.06), width: 1.0),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(22, 22, 22, 26),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    height: 52,
                    width: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [theme.colorScheme.primary, theme.colorScheme.secondary],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: theme.colorScheme.primary.withOpacity(0.50),
                          blurRadius: 18,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: const Icon(Icons.route_rounded, color: Colors.white),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t.loginWelcomeBack,
                          style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          t.loginSubtitle,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.textTheme.bodySmall?.color?.withOpacity(0.72),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              _buildServerInfo(theme, t, hasServer),
              const SizedBox(height: 26),

              Text(
                t.loginDetailsTitle,
                style: theme.textTheme.labelLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: theme.textTheme.bodyMedium?.color?.withOpacity(0.9),
                ),
              ),
              const SizedBox(height: 8),

              _buildNeumorphicField(
                theme: theme,
                child: TextFormField(
                  controller: _email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    labelText: t.loginEmailLabel,
                    prefixIcon: Icon(Icons.person_outline, color: theme.colorScheme.primary),
                    border: InputBorder.none,
                  ),
                  validator: (v) => (v == null || v.isEmpty) ? t.validationRequired : null,
                ),
              ),
              const SizedBox(height: 14),

              _buildNeumorphicField(
                theme: theme,
                child: TextFormField(
                  controller: _password,
                  obscureText: _obscurePassword,
                  decoration: InputDecoration(
                    labelText: t.loginPasswordLabel,
                    prefixIcon: Icon(Icons.lock_outline_rounded, color: theme.colorScheme.primary),
                    border: InputBorder.none,
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscurePassword ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                      ),
                      onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                    ),
                  ),
                  validator: (v) => (v == null || v.isEmpty) ? t.validationRequired : null,
                ),
              ),

              const SizedBox(height: 10),

              if (_error != null) ...[
                Text(_error!, style: const TextStyle(color: Colors.redAccent, fontSize: 13)),
                const SizedBox(height: 8),
              ],

              const SizedBox(height: 4),

              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _loading ? null : _submit,
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 6,
                    shadowColor: theme.colorScheme.primary.withOpacity(0.55),
                  ),
                  child: _loading
                      ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                      : Text(t.loginButton, style: const TextStyle(fontSize: 16)),
                ),
              ),

              const SizedBox(height: 10),

              Align(
                alignment: Alignment.center,
                child: Text(
                  t.loginPoweredBy,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.textTheme.bodySmall?.color?.withOpacity(0.65),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildServerInfo(ThemeData theme, AppLocalizations t, bool hasServer) {
    final dbText = hasServer ? t.loginServerDb(_dbName) : t.loginServerDbEmpty;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withOpacity(theme.brightness == Brightness.dark ? 0.20 : 0.85),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.primary.withOpacity(0.10)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.cloud_done_outlined, size: 24, color: theme.colorScheme.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  t.loginConnectedServer,
                  style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                Text(hasServer ? _serverUrl : t.loginNoServerConfigured,
                    style: theme.textTheme.bodySmall),
                const SizedBox(height: 2),
                Text(
                  dbText,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.textTheme.bodySmall?.color?.withOpacity(0.7),
                  ),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    onPressed: _openServerConfig,
                    icon: const Icon(Icons.settings_rounded, size: 18),
                    label: Text(t.loginChangeServer),
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                      minimumSize: const Size(0, 30),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNeumorphicField({required ThemeData theme, required Widget child}) {
    final fieldBg =
    theme.brightness == Brightness.dark ? const Color(0xFF141827) : const Color(0xFFF5F7FC);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 0),
      decoration: BoxDecoration(
        color: fieldBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.black.withOpacity(0.10)),
      ),
      child: child,
    );
  }
}
