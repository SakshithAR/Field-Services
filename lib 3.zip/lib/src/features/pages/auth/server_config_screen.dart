import 'package:flutter/material.dart';
import 'package:field_service/src/config/app_config.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:field_service/l10n/app_localizations.dart';

Future<String?> resolveDbFromServerUrl(String rawUrl) async {
  // remove trailing slash
  final base = rawUrl.trim().replaceAll(RegExp(r'/+$'), '');
  final uri = Uri.parse('$base/taqnix_field_service/api/db_info');

  final resp = await http.get(uri, headers: {
    'Content-Type': 'application/json',
  });

  if (resp.statusCode != 200) {
    return null;
  }

  final data = jsonDecode(resp.body);
  if (data is Map && data['success'] == true && data['db'] is String) {
    return data['db'] as String;
  }
  return null;
}

class ServerConfigScreen extends StatefulWidget {
  final VoidCallback onConfigured;

  const ServerConfigScreen({
    super.key,
    required this.onConfigured,
  });

  @override
  State<ServerConfigScreen> createState() => _ServerConfigScreenState();
}

class _ServerConfigScreenState extends State<ServerConfigScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _urlController;
  late final TextEditingController _dbController;
  bool _saving = false;

  @override
  void initState() {
    super.initState();

    final cfg = AppConfig.instance;

    // Prefill with already saved values (if any)
    _urlController = TextEditingController(text: cfg.serverUrl);
    _dbController = TextEditingController(text: cfg.dbName);
  }

  @override
  void dispose() {
    _urlController.dispose();
    _dbController.dispose();
    super.dispose();
  }

  void _savingNull() {}

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final t = AppLocalizations.of(context)!;

    setState(() => _saving = true);

    final url = _urlController.text.trim();

    String? dbName;

    if(_dbController.text.isEmpty) {
      try {
        dbName = await resolveDbFromServerUrl(url);
      } catch (e) {
        dbName = _dbController.text.trim();
      }
    } else {
      dbName = _dbController.text.trim();
    }

    if (dbName == null || dbName.isEmpty) {
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(t.serverConfigDbAutoDetectError),
        ),
      );
      return;
    }

    await AppConfig.instance.save(
      serverUrl: url,
      dbName: dbName,
    );

    setState(() => _saving = false);

    widget.onConfigured();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final t = AppLocalizations.of(context)!;

    final baseBg = const Color(0xFF16568c);

    return Scaffold(
      appBar: AppBar(
        //title: Text(t.configureOdooServer),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.transparent,
        scrolledUnderElevation: 0,
        iconTheme: const IconThemeData(
          color: Colors.white, // back icon white
        ),
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        // Different gradient from LoginPage
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              baseBg.withOpacity(0.82),
              baseBg,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Stack(
          children: [
            // Background blobs
            Positioned(
              top: -60,
              right: -30,
              child: Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.blue.withOpacity(0.6),
                  boxShadow: [
                    BoxShadow(
                      color: baseBg.withOpacity(0.5),
                      blurRadius: 40,
                      spreadRadius: 10,
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              bottom: -80,
              left: -40,
              child: Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.blue.withOpacity(0.4),
                  boxShadow: [
                    BoxShadow(
                      color: baseBg,
                      blurRadius: 40,
                      spreadRadius: 10,
                    ),
                  ],
                ),
              ),
            ),

            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 24,
                  ),
                  child: _buildGlassCard(theme, t),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Glassmorphism-style card: subtle gradient border + semi-transparent surface
  Widget _buildGlassCard(ThemeData theme, AppLocalizations t) {
    final isDark = theme.brightness == Brightness.dark;
    final baseBg = const Color(0xFF16568c);

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        // Outer gradient border
        gradient: LinearGradient(
          colors: [
            theme.colorScheme.primary.withOpacity(0.45),
            theme.colorScheme.secondary.withOpacity(0.35),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 26,
            offset: const Offset(0, 18),
          ),
        ],
      ),
      child: Container(
        margin: const EdgeInsets.all(1.4), // thin gradient border
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          color: isDark
              ? const Color(0xFF0B0F1D).withOpacity(0.88)
              : Colors.white.withOpacity(0.93),
          boxShadow: [
            BoxShadow(
              color: baseBg.withOpacity(
                isDark ? 0.04 : 0.55,
              ),
              blurRadius: 18,
              offset: const Offset(-4, -4),
            )
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 24, 22, 26),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Header
                Row(
                  children: [
                    Container(
                      height: 48,
                      width: 48,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        gradient: LinearGradient(
                          colors: [
                            theme.colorScheme.primary,
                            theme.colorScheme.secondary,
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: theme.colorScheme.primary.withOpacity(0.55),
                            blurRadius: 18,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.dns_rounded,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            t.configureOdooServer,
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            t.serverConfigSubtitle,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.textTheme.bodySmall?.color
                                  ?.withOpacity(0.75),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 18),

                // Little environment pill (empty for now, can localize later if needed)
                Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(999),
                      color:
                      theme.colorScheme.primary.withOpacity(0.08),
                    ),
                    child: const SizedBox.shrink(),
                  ),
                ),

                const SizedBox(height: 22),

                Text(
                  t.serverConfigSectionConnectionDetails,
                  style: theme.textTheme.labelLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: theme.textTheme.bodyMedium?.color
                        ?.withOpacity(0.95),
                  ),
                ),
                const SizedBox(height: 10),

                // URL field
            _buildGlassField(
              theme: theme,
              child: TextFormField(
                controller: _urlController,
                keyboardType: TextInputType.url,
                decoration: InputDecoration(
                  labelText: t.serverConfigServerUrlLabel,
                  hintText: t.serverConfigServerUrlHint,
                  labelStyle: TextStyle(
                    color: theme.textTheme.bodySmall?.color?.withOpacity(0.86),
                  ),
                  prefixIcon: Icon(
                    Icons.public_rounded,
                    color: theme.colorScheme.primary,
                  ),
                  border: InputBorder.none,
                ),
                validator: (v) {
                  final value = v?.trim() ?? '';

                  if (value.isEmpty) {
                    return t.validationRequired; // already in your code
                  }

                  // validate URL
                  final uri = Uri.tryParse(value);

                  final isValid = uri != null &&
                      (uri.scheme == 'http' || uri.scheme == 'https') &&
                      uri.host.isNotEmpty;

                  if (!isValid) {
                    // use your own translated string if you have one
                    return 'Please enter a valid URL (e.g. https://example.com)';
                    // or: return t.serverConfigInvalidUrl;
                  }

                  return null; // OK
                },
              ),
            ),
            const SizedBox(height: 14),

                // DB field (still required for UI, although db is auto-detected)
                _buildGlassField(
                  theme: theme,
                  child: TextFormField(
                    controller: _dbController,
                    decoration: InputDecoration(
                      labelText: t.serverConfigDbNameLabel,
                      labelStyle: TextStyle(
                        color: theme.textTheme.bodySmall?.color
                            ?.withOpacity(0.86),
                      ),
                      prefixIcon: Icon(
                        Icons.storage_rounded,
                        color: theme.colorScheme.primary,
                      ),
                      border: InputBorder.none,
                    ),
                    /*validator: (v) =>
                    v == null || v.trim().isEmpty
                        ? t.validationRequired
                        : null,*/
                  ),
                ),

                const SizedBox(height: 24),

                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _saving ? _savingNull : _save,
                    style: FilledButton.styleFrom(
                      padding:
                      const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 6,
                      shadowColor: theme.colorScheme.primary
                          .withOpacity(0.55),
                    ),
                    child: _saving
                        ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor:
                        AlwaysStoppedAnimation<Color>(
                          Colors.white,
                        ),
                      ),
                    )
                        : Text(
                      t.serverConfigSaveButton,
                      style: const TextStyle(fontSize: 16),
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                Align(
                  alignment: Alignment.center,
                  child: Text(
                    t.serverConfigSaveHint,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.textTheme.bodySmall?.color
                          ?.withOpacity(0.65),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Reusable glass-like field container (different style from login page)
  Widget _buildGlassField({
    required ThemeData theme,
    required Widget child,
  }) {
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: isDark
            ? const Color(0xFF171B2A).withOpacity(0.95)
            : Colors.white.withOpacity(0.100),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.20),
            blurRadius: 16,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(
              isDark ? 0.04 : 0.70,
            ),
            blurRadius: 10,
            offset: const Offset(-4, -4),
          ),
        ],
        border: Border.all(
          color: theme.colorScheme.primary.withOpacity(0.12),
        ),
      ),
      child: child,
    );
  }

  Widget _blurCircle({required Color color, required double size}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
      ),
    );
  }
}
