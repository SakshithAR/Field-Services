import 'package:flex_color_picker/flex_color_picker.dart';
import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../controllers/settings_controller.dart';
import 'package:field_service/l10n/app_localizations.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  // ---------------------------------------------------------------------------
  // LANGUAGE OPTIONS (must match what you support in AppLocalizations)
  // Keys = localeCode stored in SettingsState.localeCode
  // ---------------------------------------------------------------------------
  static const Map<String, String> _languageOptions = {
    'en_US': 'English (US)',
    'en_GB': 'English (UK)',
    'fr_FR': 'Français',
    'ar': 'العربية',
    'es_ES': 'Español (España)',
    'es_MX': 'Español (México)',
    'de_DE': 'Deutsch',
    'pt_BR': 'Português (Brasil)',
    'it_IT': 'Italiano',
    'nl_NL': 'Nederlands',
    'ru_RU': 'Русский',
    'zh_CN': '简体中文',
    'zh_TW': '繁體中文',
    'hi_IN': 'हिन्दी',
    'tr_TR': 'Türkçe',
    'th_TH': 'ไทย',
    'sw': 'Kiswahili',
    'fil_PH': 'Filipino',
  };

  // --- THEME LABELS ---

  String _themeLabel(ThemeMode m, AppLocalizations t) {
    switch (m) {
      case ThemeMode.light:
        return t.settingsThemeLight;
      case ThemeMode.dark:
        return t.settingsThemeDark;
      default:
        return t.settingsThemeSystem;
    }
  }

  // --- LANGUAGE LABEL: use localized names for English/Arabic if available ---

  String _languageLabel(String code, AppLocalizations t) {
    if (code.startsWith('en')) {
      return t.languageEnglish; // from your l10n
    }
    if (code.startsWith('ar')) {
      return t.languageArabic; // from your l10n
    }
    // fallback to our static map or just show the code
    return _languageOptions[code] ?? code;
  }

  // --- COLOR PARSER ---

  Color _parseHex(String hex) {
    final h = hex.replaceAll('#', '');
    // Ensure it's 6 chars and prepend FF for full opacity
    final colorValue =
    int.parse('FF${h.padLeft(6, '0').substring(0, 6)}', radix: 16);
    return Color(colorValue);
  }

  // --- REUSABLE SETTINGS TILE ---

  Widget _SettingsTile({
    required Widget leading,
    required Widget title,
    Widget? subtitle,
    Widget? trailing,
    GestureTapCallback? onTap,
    ShapeBorder? shape,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      elevation: 0,
      shape: shape ??
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: Colors.grey.shade200),
          ),
      child: ListTile(
        leading: leading,
        title: title,
        subtitle: subtitle,
        trailing: trailing,
        onTap: onTap,
        contentPadding:
        const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      ),
    );
  }

  // --- BUILD ---

  @override
  Widget build(BuildContext context) {
    final settingsController = context.read<SettingsController>();
    final s = context.watch<SettingsController>().state;
    final t = AppLocalizations.of(context)!;

    // Make sure current localeCode is valid for dropdown
    final currentLocaleCode = _languageOptions.keys.contains(s.localeCode)
        ? s.localeCode
        : 'en_US';

    return Scaffold(
      appBar: AppBar(
        title: Text(t.settingsTitle),
        elevation: 1.0,
        shadowColor: Theme.of(context).shadowColor.withOpacity(0.1),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // -----------------------------------------------------------------
          // 1. APPEARANCE SECTION
          // -----------------------------------------------------------------
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0, top: 4.0),
            child: Text(
              t.settingsAppearance,
              style: Theme.of(context).textTheme.titleSmall!.copyWith(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          // THEME MODE
          _SettingsTile(
            leading: const Icon(FluentIcons.weather_moon_24_regular),
            title: Text(t.settingsTheme),
            subtitle:
            Text(_themeLabel(s.themeMode ?? ThemeMode.system, t)),
            trailing: DropdownButton<ThemeMode>(
              value: s.themeMode ?? ThemeMode.system,
              icon: const Icon(Icons.arrow_forward_ios_rounded, size: 16),
              underline: const SizedBox.shrink(),
              items: [
                DropdownMenuItem(
                  value: ThemeMode.light,
                  child: Text(t.settingsThemeLight),
                ),
                DropdownMenuItem(
                  value: ThemeMode.dark,
                  child: Text(t.settingsThemeDark),
                ),
                DropdownMenuItem(
                  value: ThemeMode.system,
                  child: Text(t.settingsThemeSystem),
                ),
              ],
              onChanged: (v) =>
              v != null ? settingsController.setThemeMode(v) : null,
            ),
          ),

          // ACCENT COLOR PICKER
          _SettingsTile(
            leading: const Icon(FluentIcons.color_24_regular),
            title: Text(t.settingsAccentColor),
            subtitle: Text(s.seedColorHex),
            trailing: CircleAvatar(
              backgroundColor: _parseHex(s.seedColorHex),
              radius: 12,
            ),
            onTap: () async {
              final picked = await showColorPickerDialog(
                context,
                _parseHex(s.seedColorHex),
                title: Text(t.settingsAccentColorDialogTitle),
                colorCodeHasColor: true,
                showColorCode: true,
              );
              final hex =
                  '#${picked.value.toRadixString(16).padLeft(8, '0').substring(2, 8)}';
              await settingsController.setSeedColorHex(hex);
            },
          ),

          const SizedBox(height: 16),

          // -----------------------------------------------------------------
          // 2. LANGUAGE SECTION
          // -----------------------------------------------------------------
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0, top: 4.0),
            child: Text(
              t.settingsLanguageSection,
              style: Theme.of(context).textTheme.titleSmall!.copyWith(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          // LANGUAGE SELECTOR (all languages)
          _SettingsTile(
            leading: const Icon(FluentIcons.translate_24_regular),
            title: Text(t.settingsLanguageLabel),
            subtitle: Text(_languageLabel(currentLocaleCode, t)),
            trailing: DropdownButton<String>(
              value: currentLocaleCode,
              icon: const Icon(Icons.arrow_forward_ios_rounded, size: 16),
              underline: const SizedBox.shrink(),
              onChanged: (code) {
                if (code != null) {
                  settingsController.setLocale(code);
                }
              },
              items: _languageOptions.entries.map((entry) {
                final code = entry.key;
                final label = _languageLabel(code, t);
                return DropdownMenuItem<String>(
                  value: code,
                  child: Text(label),
                );
              }).toList(),
            ),
          ),

          const SizedBox(height: 16),

          // -----------------------------------------------------------------
          // 3. ABOUT SECTION
          // -----------------------------------------------------------------
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0, top: 4.0),
            child: Text(
              t.settingsAboutSection,
              style: Theme.of(context).textTheme.titleSmall!.copyWith(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          _SettingsTile(
            leading: const Icon(FluentIcons.info_24_regular),
            title: Text(t.settingsVersionLabel),
            subtitle: const Text('Field Service App 1.0.0'),
            trailing: const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}
