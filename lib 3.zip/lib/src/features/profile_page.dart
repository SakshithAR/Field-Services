// features/profile/presentation/profile_page.dart
import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flex_color_picker/flex_color_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import 'package:field_service/src/config/app_config.dart';
import 'package:field_service/src/features/webview/web_doc_page.dart';
import 'package:provider/provider.dart';
import 'package:field_service/src/controllers/auth_controller.dart';
import 'package:field_service/src/controllers/settings_controller.dart';

// localized strings
import 'package:field_service/l10n/app_localizations.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  // Map full locale codes → readable labels
  static const Map<String, String> kAllLanguages = {
    'en_US': 'English (US)',
    'en_GB': 'English (UK)',
    'fr_FR': 'French',
    'ar': 'Arabic',
    'es_ES': 'Spanish (Spain)',
    'es_MX': 'Spanish (Mexico)',
    'de_DE': 'German',
    'pt_BR': 'Portuguese (Brazil)',
    'it_IT': 'Italian',
    'nl_NL': 'Dutch',
    'ru_RU': 'Russian',
    'zh_CN': 'Chinese (Simplified)',
    'zh_TW': 'Chinese (Traditional)',
    'hi_IN': 'Hindi',
    'tr_TR': 'Turkish',
    'th_TH': 'Thai',
    'sw': 'Swahili',
    'fil_PH': 'Filipino',
  };

  // -------- In-app web with Odoo cookie injection ----------
  Future<void> openWeb(String title, Uri url) async {
    final env = context.read<AuthController>().env;
    final session = env.orpc.sessionId;
    final base = Uri.parse(env.orpc.baseURL);
    final host = url.host.isNotEmpty ? url.host : base.host;
    final scheme = url.scheme.isNotEmpty ? url.scheme : base.scheme;

    if (session != null && session.id.isNotEmpty) {
      await CookieManager.instance().setCookie(
        url: WebUri('$scheme://$host/'),
        name: 'session_id',
        value: session.id,
        domain: host,
        path: '/',
        isSecure: scheme == 'https',
        isHttpOnly: true,
        sameSite: HTTPCookieSameSitePolicy.LAX,
      );
    }

    final target = url.hasScheme ? url : base.resolveUri(url);
    if (!mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => WebDocPage(title: title, url: target),
      ),
    );
  }

  String _themeLabel(ThemeMode m, AppLocalizations t) {
    switch (m) {
      case ThemeMode.light:
        return t.settingsThemeLight;
      case ThemeMode.dark:
        return t.settingsThemeDark;
      default:
        return t.settingsThemeSystem;
    }
  }

  Color _parseHex(String hex) {
    final h = hex.replaceAll('#', '');
    final colorValue =
    int.parse('FF${h.padLeft(6, '0').substring(0, 6)}', radix: 16);
    return Color(colorValue);
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final settingsState = context.watch<SettingsController>().state;
    final settingsCtl = context.read<SettingsController>();

    final t = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    /// User display + login
    final displayName = auth.displayName ?? auth.login ?? '-';
    final email = auth.login ?? '-';

    /// Company name from email domain (info@taqnix.com → "Taqnix")
    final dbName = AppConfig.instance.dbName;
    final parsedCompany = _companyNameFromEmail(email);
    final companyName = parsedCompany.isNotEmpty
        ? parsedCompany
        : (dbName.isNotEmpty ? dbName : t.profileLoggedIn);

    final themeMode = settingsState.themeMode ?? ThemeMode.system;

    // Ensure localeCode is always something valid for the dropdown
    final currentLocaleCode = kAllLanguages.keys.contains(settingsState.localeCode)
        ? settingsState.localeCode
        : 'en_US';

    return Scaffold(
      appBar: AppBar(
        // title: Text(t.navProfile),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        children: [
          // -----------------------------------------------------------------
          // 1. IDENTITY CARD
          // -----------------------------------------------------------------
          Card(
            elevation: 1,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            color: colorScheme.surfaceContainerLow, // Slight contrast
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  _buildAvatar(theme, companyName),
                  const SizedBox(height: 16),
                  Text(
                    displayName,
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    email,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color:
                      theme.textTheme.bodyMedium?.color?.withOpacity(0.7),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 12),
                  // Company Badge
                  Container(
                    padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: colorScheme.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          FluentIcons.building_24_regular,
                          size: 16,
                          color: colorScheme.primary,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          companyName,
                          style: theme.textTheme.labelMedium?.copyWith(
                            color: colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),

          // ─── Settings & more (all settings now inside Profile) ───────────
          _SectionTitle(t.profileSectionSettingsAndMore),

          Card(
            elevation: 1,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                // Theme mode
                ListTile(
                  leading: const Icon(FluentIcons.weather_moon_24_regular),
                  title: Text(t.settingsTheme),
                  subtitle: Text(_themeLabel(themeMode, t)),
                  trailing: DropdownButtonHideUnderline(
                    child: DropdownButton<ThemeMode>(
                      value: settingsState.themeMode ?? ThemeMode.system,
                      icon: const Icon(Icons.keyboard_arrow_down_rounded),
                      style: theme.textTheme.bodyMedium,
                      borderRadius: BorderRadius.circular(12),
                      items: [
                        DropdownMenuItem(
                          value: ThemeMode.light,
                          child: Text(t.settingsThemeLight),
                        ),
                        DropdownMenuItem(
                          value: ThemeMode.dark,
                          child: Text(t.settingsThemeDark),
                        ),
                        DropdownMenuItem(
                          value: ThemeMode.system,
                          child: Text(t.settingsThemeSystem),
                        ),
                      ],
                      onChanged: (v) =>
                      v != null ? settingsCtl.setThemeMode(v) : null,
                    ),
                  ),
                  contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                ),
                const Divider(height: 1),

                // Accent color
                ListTile(
                  leading: const Icon(FluentIcons.color_24_regular),
                  title: Text(t.settingsAccentColor),
                  subtitle: Text(settingsState.seedColorHex),
                  trailing: Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: _parseHex(settingsState.seedColorHex),
                      shape: BoxShape.circle,
                      border:
                      Border.all(color: colorScheme.outlineVariant, width: 1),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        )
                      ],
                    ),
                  ),
                  onTap: () async {
                    final picked = await showColorPickerDialog(
                      context,
                      _parseHex(settingsState.seedColorHex),
                      title: Text(t.settingsAccentColorDialogTitle),
                      colorCodeHasColor: true,
                      showColorCode: true,
                    );
                    final hex = '#${picked.value.toRadixString(16)
                        .padLeft(8, '0')
                        .substring(2, 8)}';
                    await settingsCtl.setSeedColorHex(hex);
                  },
                  contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                ),
                const Divider(height: 1),

                // Language
                ListTile(
                  leading: const Icon(FluentIcons.translate_24_regular),
                  title: Text(t.settingsLanguageLabel),
                  subtitle:
                  Text(kAllLanguages[currentLocaleCode] ?? currentLocaleCode),
                  trailing: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: currentLocaleCode,
                      icon: const Icon(Icons.keyboard_arrow_down_rounded),
                      style: theme.textTheme.bodyMedium,
                      borderRadius: BorderRadius.circular(12),
                      items: kAllLanguages.entries.map((entry) {
                        return DropdownMenuItem(
                          value: entry.key,
                          child: Text(entry.value),
                        );
                      }).toList(),
                      onChanged: (v) {
                        if (v != null) {
                          // Store full code like en_US, fr_FR, etc.
                          settingsCtl.setLocale(v);
                        }
                      },
                    ),
                  ),
                  contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                ),
                const Divider(height: 1),

                // About / version
                ListTile(
                  leading: const Icon(FluentIcons.info_24_regular),
                  title: Text(t.settingsVersionLabel),
                  subtitle: const Text('Field Service App 1.0.0'),
                  contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                ),
              ],
            ),
          ),

          const SizedBox(height: 18),

          // ─── Logout (styled as a "danger" card) ─────────────────────────
          _SectionTitle(t.profileLogoutTitle),
          Card(
            elevation: 0,
            color: theme.colorScheme.error.withOpacity(0.03),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(
                color: theme.colorScheme.error.withOpacity(0.3),
              ),
            ),
            child: ListTile(
              leading: Icon(
                FluentIcons.sign_out_24_regular,
                color: theme.colorScheme.error,
              ),
              title: Text(
                t.profileLogoutTitle,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.error,
                  fontWeight: FontWeight.w600,
                ),
              ),
              subtitle: Text(
                t.profileLogoutSubtitle,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.error.withOpacity(0.9),
                ),
              ),
              trailing: Icon(
                Icons.chevron_right,
                color: theme.colorScheme.error,
              ),
              onTap: () {
                auth.logout();
                if (!mounted) return;
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // AVATAR LOGIC
  // ---------------------------------------------------------------------------

  Widget _buildAvatar(ThemeData theme, String companyName) {
    final auth = context.read<AuthController>();
    String? avatarUrl;
    try {
      avatarUrl = (auth as dynamic).avatarUrl as String?;
    } catch (_) {}

    if (avatarUrl != null && avatarUrl.isNotEmpty) {
      return CircleAvatar(
        radius: 40,
        backgroundColor: theme.colorScheme.primaryContainer,
        backgroundImage: NetworkImage(avatarUrl),
      );
    }

    final initials = _initialsFromName(companyName);
    return CircleAvatar(
      radius: 40,
      backgroundColor: theme.colorScheme.primary,
      child: Text(
        initials,
        style: theme.textTheme.headlineMedium?.copyWith(
          color: theme.colorScheme.onPrimary,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  /// Turn "info@taqnix.com" → "Taqnix"
  String _companyNameFromEmail(String email) {
    final atIndex = email.indexOf('@');
    if (atIndex == -1) return '';

    final domainPart = email.substring(atIndex + 1); // taqnix.com
    if (domainPart.isEmpty) return '';

    final firstDot = domainPart.indexOf('.');
    final core = firstDot == -1 ? domainPart : domainPart.substring(0, firstDot);

    // Clean separators like "_" or "-"
    final cleaned = core.replaceAll(RegExp(r'[_\-]+'), ' ').trim();
    if (cleaned.isEmpty) return '';

    final words = cleaned.split(RegExp(r'\s+'));
    final nice = words
        .map((w) =>
    w.isEmpty ? '' : w[0].toUpperCase() + w.substring(1).toLowerCase())
        .join(' ');
    return nice;
  }

  /// Simple initials from name – here we use company name
  String _initialsFromName(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty || trimmed == '-') return 'C'; // C = Company

    final parts = trimmed.split(RegExp(r'\s+'));
    if (parts.length == 1) {
      final s = parts.first;
      return s.length >= 2 ? (s[0] + s[1]).toUpperCase() : s[0].toUpperCase();
    }
    final first = parts[0].isNotEmpty ? parts[0][0] : '';
    final last = parts[1].isNotEmpty ? parts[1][0] : '';
    final result = (first + last).toUpperCase();
    return result.isEmpty ? 'C' : result;
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
