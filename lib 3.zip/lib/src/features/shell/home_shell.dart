import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';

import 'package:field_service/l10n/app_localizations.dart';
import 'package:field_service/src/features/jobs/job_list_page.dart';
import 'package:field_service/src/features/calendar/calendar_page.dart';
import 'package:field_service/src/features/map/map_page.dart';
import '../profile_page.dart';

/// ✅ MAIN HOME SHELL (Bottom Navigation)
class FieldServiceHome extends StatefulWidget {
  const FieldServiceHome({Key? key}) : super(key: key);

  @override
  State<FieldServiceHome> createState() => _FieldServiceHomeState();
}

class _FieldServiceHomeState extends State<FieldServiceHome> {
  int _currentIndex = 0;

  /// Keep all pages alive (preserves scroll, state)
  late final List<Widget> _pages = const [
    JobListPage(key: PageStorageKey('jobs_page')),
    CalendarPage(key: PageStorageKey('calendar_page')),
    MapPage(key: PageStorageKey('map_page')),
    ProfilePage(key: PageStorageKey('profile_page')),
  ];

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (index) {
          setState(() => _currentIndex = index);
        },
        items: [
          BottomNavigationBarItem(
            icon: const Icon(FluentIcons.wrench_screwdriver_20_regular),
            activeIcon: const Icon(FluentIcons.wrench_screwdriver_20_filled),
            label: t.navJobs,
          ),
          BottomNavigationBarItem(
            icon: const Icon(FluentIcons.calendar_clock_24_regular),
            activeIcon: const Icon(FluentIcons.calendar_clock_24_filled),
            label: t.navCalendar,
          ),
          BottomNavigationBarItem(
            icon: const Icon(FluentIcons.location_24_regular),
            activeIcon: const Icon(FluentIcons.location_24_filled),
            label: t.navMap,
          ),
          BottomNavigationBarItem(
            icon: const Icon(FluentIcons.person_24_regular),
            activeIcon: const Icon(FluentIcons.person_24_filled),
            label: t.navProfile,
          ),
        ],
      ),
    );
  }
}
