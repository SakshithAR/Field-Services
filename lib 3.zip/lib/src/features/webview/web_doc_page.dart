import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';


/// Simple in-app web page with back/forward/refresh
class WebDocPage extends StatefulWidget {
  final String title;
  final Uri url;
  const WebDocPage({super.key, required this.title, required this.url});

  @override
  State<WebDocPage> createState() => _WebDocPageState();
}

class _WebDocPageState extends State<WebDocPage> {
  InAppWebViewController? _controller;
  double _progress = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(2),
          child: _progress < 1
              ? LinearProgressIndicator(value: _progress, minHeight: 2)
              : const SizedBox.shrink(),
        ),
      ),
      body: InAppWebView(
        initialSettings: InAppWebViewSettings(
          javaScriptEnabled: true,
          clearCache: false,
          mediaPlaybackRequiresUserGesture: true,
          useShouldOverrideUrlLoading: true,
        ),
        initialUrlRequest: URLRequest(url: WebUri(widget.url.toString())),
        onWebViewCreated: (c) => _controller = c,
        onProgressChanged: (_, p) => setState(() => _progress = p / 100.0),
      ),
    );
  }
}
