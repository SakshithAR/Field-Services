import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fluentui_system_icons/fluentui_system_icons.dart';

import 'package:field_service/l10n/app_localizations.dart';
import 'package:field_service/src/odoo/odoo_repository/lib/odoo_repository.dart';
import 'package:field_service/src/features/jobs/job_record.dart';
import 'package:field_service/src/features/jobs/job_repository.dart';
import 'package:field_service/src/features/jobs/job_card.dart';

class CalendarPage extends StatefulWidget {
  const CalendarPage({super.key});

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  DateTime _selectedDate = DateTime.now();
  late JobRepository _jobRepo;

  @override
  void initState() {
    super.initState();

    final env = context.read<OdooEnvironment>();
    env.add(JobRepository(env));          // register repository
    _jobRepo = env.of<JobRepository>();   // get instance
    _jobRepo.fetchRecords();              // initial load
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  List<JobRecord> _jobsForDate(List<JobRecord> all) {
    final filtered = all.where((job) {
      final dt = job.scheduledDate ?? job.startTime;
      if (dt == null) return false;
      return _isSameDay(dt, _selectedDate);
    }).toList();

    filtered.sort((a, b) {
      final aDt = a.scheduledDate ?? a.startTime ?? DateTime(1900);
      final bDt = b.scheduledDate ?? b.startTime ?? DateTime(1900);
      return aDt.compareTo(bDt);
    });

    return filtered;
  }

  String _formatShortTime(DateTime? dt) {
    if (dt == null) return '--:--';
    final local = dt.toLocal();
    final h = local.hour.toString().padLeft(2, '0');
    final m = local.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        // Use navCalendar from ARB for the title
        title: Text(t.navCalendar),
        actions: [
          IconButton(
            icon: const Icon(FluentIcons.arrow_sync_24_regular),
            tooltip: t.calendarRefreshTooltip,
            onPressed: _jobRepo.fetchRecords,
          ),
        ],
      ),
      body: Column(
        children: [
          // 🗓 Calendar at the top
          CalendarDatePicker(
            initialDate: _selectedDate,
            firstDate: DateTime(2020),
            lastDate: DateTime(2030),
            onDateChanged: (date) {
              setState(() => _selectedDate = date);
            },
          ),

          const Divider(height: 1),

          // Header: selected date
          Padding(
            padding:
            const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Row(
              children: [
                Text(
                  t.calendarJobsOnPrefix,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(width: 4),
                Text(
                  '${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),

          // 📋 Jobs list for that day
          Expanded(
            child: StreamBuilder<List<JobRecord>>(
              stream: _jobRepo.recordStream,
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final jobsForDay = _jobsForDate(snapshot.data!);

                if (jobsForDay.isEmpty) {
                  return Center(
                    child: Text(
                      t.calendarNoJobsOnDay,
                      style: const TextStyle(color: Colors.grey),
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 4,
                  ),
                  itemCount: jobsForDay.length,
                  itemBuilder: (context, index) {
                    final job = jobsForDay[index];

                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4.0),
                      child: JobCard(
                        job: job,
                        timeText: _formatShortTime(
                          job.scheduledDate ?? job.startTime,
                        ),
                        // later: replace with real address from partner
                        addressText: job.customer.name,
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
