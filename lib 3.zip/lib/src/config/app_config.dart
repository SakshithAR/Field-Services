import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Runtime configuration for the Odoo backend.
///
/// Call: `await AppConfig.instance.init();` once in main()
/// then always use `AppConfig.instance.serverUrl` / `.dbName`.
class AppConfig {
  AppConfig._internal();
  static final AppConfig instance = AppConfig._internal();

  late String _serverUrl;
  late String _dbName;

  // ── Public getters ─────────────────────────────────────────
  String get serverUrl => _serverUrl;
  String get dbName => _dbName;

  /// Optional alias if some old code still expects `baseUrl`
  String get baseUrl => _serverUrl;

  /// Changes when user points app to different server/DB.
  String get hiveBoxName => sha1
      .convert(utf8.encode('odoo_repository_demo:$_serverUrl:$_dbName'))
      .toString();

  /// Where OdooClient session is stored in Hive.
  String get cacheSessionKey => _kCacheSessionKey;

  bool get isConfigured => _serverUrl.isNotEmpty && _dbName.isNotEmpty;

  // ── Init / persistence ─────────────────────────────────────
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _serverUrl = prefs.getString('odoo_server_url') ?? '';
    _dbName = prefs.getString('odoo_db_name') ?? '';
  }

  Future<void> save({
    required String serverUrl,
    required String dbName,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final url = serverUrl.trim();
    final db = dbName.trim();

    await prefs.setString('odoo_server_url', url);
    await prefs.setString('odoo_db_name', db);

    _serverUrl = url;
    _dbName = db;
  }

  static const String _kCacheSessionKey = 'session';
}

final hiveBoxName = sha1
    .convert(utf8.encode('odoo_repository'))
    .toString();

const cacheSessionKey = 'session';
