// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Portuguese (`pt`).
class AppLocalizationsPt extends AppLocalizations {
  AppLocalizationsPt([String locale = 'pt']) : super(locale);

  @override
  String get configureOdooServer => 'Configurar servidor Odoo';

  @override
  String get jobs => 'Serviços';

  @override
  String get searchJobsHint => 'Buscar serviços...';

  @override
  String get sortBy => 'Ordenar por';

  @override
  String get sortScheduledNearest => 'Agendado (mais próximo primeiro)';

  @override
  String get sortScheduledFarthest => 'Agendado (mais distante primeiro)';

  @override
  String get sortCustomerAZ => 'Cliente (A–Z)';

  @override
  String get sortStatus => 'Status';

  @override
  String get tabAssigned => 'Atribuídos';

  @override
  String get tabInProgress => 'Em andamento';

  @override
  String get tabDone => 'Concluídos';

  @override
  String get tabAll => 'Todos';

  @override
  String get emptyJobsTitle => 'Nenhum serviço';

  @override
  String get emptyJobsSubtitle => 'Tente mudar a busca ou os filtros';

  @override
  String get emptyJobsAddButton => 'Adicionar novo serviço';

  @override
  String get noSchedule => 'Sem agendamento';

  @override
  String get statusDraft => 'Rascunho';

  @override
  String get statusAssigned => 'Atribuído';

  @override
  String get statusInProgress => 'Em andamento';

  @override
  String get statusDone => 'Concluído';

  @override
  String get statusCancelled => 'Cancelado';

  @override
  String get settingsTitle => 'Configurações do app';

  @override
  String get settingsAppearance => 'Aparência';

  @override
  String get settingsTheme => 'Tema';

  @override
  String get settingsThemeLight => 'Claro';

  @override
  String get settingsThemeDark => 'Escuro';

  @override
  String get settingsThemeSystem => 'Padrão do sistema';

  @override
  String get settingsAccentColor => 'Cor de destaque';

  @override
  String get settingsAccentColorPick => 'Escolher cor';

  @override
  String get settingsAccentColorDialogTitle => 'Escolha uma cor';

  @override
  String get settingsLanguageSection => 'Idioma e texto';

  @override
  String get settingsLanguageLabel => 'Idioma';

  @override
  String get settingsAboutSection => 'Sobre o app';

  @override
  String get settingsVersionLabel => 'Versão';

  @override
  String get languageEnglish => 'Inglês';

  @override
  String get languageArabic => 'Árabe';

  @override
  String get navJobs => 'Serviços';

  @override
  String get navCalendar => 'Calendário';

  @override
  String get navMap => 'Mapa';

  @override
  String get navProfile => 'Perfil';

  @override
  String get profileSectionSettingsAndMore => 'Configurações e mais';

  @override
  String get profileSettingsTitle => 'Configurações';

  @override
  String get profileSettingsSubtitle => 'Configurações do app e do tema';

  @override
  String get profileLogoutTitle => 'Sair';

  @override
  String get profileLogoutSubtitle => 'Sair da sua conta';

  @override
  String get profileLoggedIn => 'Conectado';

  @override
  String get jobDetailSchedule => 'Agenda';

  @override
  String get jobDetailStart => 'Início';

  @override
  String get jobDetailEnd => 'Fim';

  @override
  String get jobDetailDuration => 'Duração';

  @override
  String get jobDetailLocation => 'Localização';

  @override
  String get jobDetailLatShort => 'Lat';

  @override
  String get jobDetailLngShort => 'Lng';

  @override
  String get jobDetailOpenInMaps => 'Abrir no Maps';

  @override
  String get jobDetailNotes => 'Notas';

  @override
  String get jobDetailCustomerNotes => 'Notas do cliente';

  @override
  String get jobDetailInternalNotes => 'Notas internas';

  @override
  String get jobDetailPhotos => 'Fotos';

  @override
  String get jobDetailAddPhotos => 'Adicionar fotos';

  @override
  String get jobDetailPhotosHint => 'Toque em qualquer lugar neste cartão ou use o botão para anexar fotos da câmera ou da galeria.';

  @override
  String get jobDetailTakePhotoCamera => 'Tirar foto (câmera)';

  @override
  String get jobDetailChooseFromGallery => 'Escolher da galeria';

  @override
  String get jobDetailAuth => 'Autenticação';

  @override
  String get jobDetailAuthTooltip => 'Abrir autenticação';

  @override
  String get jobDetailAuthHint => 'Toque neste cartão para capturar a autenticação do cliente (assinatura).';

  @override
  String get jobDetailAuthSavedSignature => 'Assinatura salva';

  @override
  String get jobDetailNoCustomer => 'Nenhum cliente';

  @override
  String get jobDetailUnassigned => 'Não atribuído';

  @override
  String get jobDetailStartButton => 'Iniciar';

  @override
  String get jobDetailMarkDone => 'Marcar como concluído';

  @override
  String get jobDetailAssign => 'Atribuir';

  @override
  String get jobDetailUpdateFailed => 'Falha ao atualizar o serviço';

  @override
  String get locationServicesDisabled => 'Serviços de localização desativados';

  @override
  String get locationPermissionDenied => 'Permissão de localização negada';

  @override
  String get jobDetailStartFailed => 'Falha ao iniciar o serviço';

  @override
  String get jobDetailNoLocationData => 'Nenhum GPS ou endereço disponível para este serviço';

  @override
  String get jobDetailNoAddress => 'Nenhum endereço disponível para este serviço';

  @override
  String get jobDetailMapOpenFailed => 'Não foi possível abrir o app de mapas';

  @override
  String get jobDetailMapError => 'Falha ao abrir o Maps';

  @override
  String get jobDetailPhotosUploaded => 'foto(s) enviada(s)';

  @override
  String get jobDetailPhotosUploadFailed => 'Falha ao enviar fotos';

  @override
  String get authSaved => 'Autenticação salva';

  @override
  String get authSaveFailed => 'Falha ao salvar a assinatura';

  @override
  String get authSignInstruction => 'Peça ao cliente para assinar dentro da caixa abaixo.';

  @override
  String get photoViewerTitle => 'Foto';

  @override
  String get commonRefresh => 'Atualizar';

  @override
  String get commonClear => 'Limpar';

  @override
  String get commonCancel => 'Cancelar';

  @override
  String get commonSave => 'Salvar';

  @override
  String get addJobTitle => 'Novo serviço';

  @override
  String get addJobJobTitleLabel => 'Título do serviço';

  @override
  String get addJobJobTitleHint => 'Ex.: Manutenção de ar-condicionado – Casa 12B';

  @override
  String get addJobJobTitleRequired => 'Insira o título do serviço';

  @override
  String get addJobScheduledLabel => 'Data e hora agendadas';

  @override
  String get addJobDateTimeNotSet => 'Não definido';

  @override
  String get addJobCustomerNotesLabel => 'Notas do cliente (opcional)';

  @override
  String get addJobCustomerNotesHint => 'Notas do cliente, informações de acesso etc.';

  @override
  String get addJobInternalNotesLabel => 'Notas internas (opcional)';

  @override
  String get addJobInternalNotesHint => 'Notas apenas para sua equipe';

  @override
  String get addJobCreateButton => 'Criar serviço';

  @override
  String get addJobCreated => 'Serviço criado';

  @override
  String get addJobCreateFailed => 'Falha ao criar serviço';

  @override
  String get calendarRefreshTooltip => 'Atualizar serviços';

  @override
  String get calendarJobsOnPrefix => 'Serviços em';

  @override
  String get calendarNoJobsOnDay => 'Nenhum serviço neste dia';

  @override
  String get mapTitle => 'Mapa de serviços';

  @override
  String get mapEmptyTitle => 'Nenhum serviço para mostrar no mapa';

  @override
  String get mapBottomTitle => 'Serviços no mapa';

  @override
  String get mapJobsLabel => 'serviços';

  @override
  String get myJobsTitle => 'Meus serviços';

  @override
  String get mapYouAreHere => 'Você está aqui';

  @override
  String get loginWelcomeBack => 'Bem-vindo de volta';

  @override
  String get loginSubtitle => 'Entre para gerenciar seus serviços de campo.';

  @override
  String get loginDetailsTitle => 'Detalhes de login';

  @override
  String get loginEmailLabel => 'E-mail / Login';

  @override
  String get loginPasswordLabel => 'Senha';

  @override
  String get loginButton => 'Entrar';

  @override
  String get loginError => 'Falha no login. Verifique as credenciais e o servidor.';

  @override
  String get validationRequired => 'Obrigatório';

  @override
  String get loginConnectedServer => 'Servidor conectado';

  @override
  String get loginNoServerConfigured => 'Nenhum servidor configurado ainda';

  @override
  String loginServerDb(String dbName) {
    return 'BD: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'BD: -';

  @override
  String get loginChangeServer => 'Alterar servidor';

  @override
  String get loginPoweredBy => 'Oferecido por Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Informe qual servidor e banco de dados Odoo o app deve usar.';

  @override
  String get serverConfigSectionConnectionDetails => 'Detalhes da conexão';

  @override
  String get serverConfigServerUrlLabel => 'URL do servidor';

  @override
  String get serverConfigServerUrlHint => 'https://seu-dominio-odoo.com';

  @override
  String get serverConfigDbNameLabel => 'Nome do banco de dados';

  @override
  String get serverConfigSaveButton => 'Salvar e continuar';

  @override
  String get serverConfigSaveHint => 'Você pode alterar isso depois, na tela de login.';

  @override
  String get serverConfigDbAutoDetectError => 'Não foi possível detectar o banco de dados automaticamente. Verifique a URL.';

  @override
  String get attendanceDetailsTitle => 'Detalhes de presença';

  @override
  String get employeeLabel => 'Funcionário';

  @override
  String get statusOpen => 'ABERTO';

  @override
  String get statusClosed => 'FECHADO';

  @override
  String get workedTimeLabel => 'Tempo trabalhado';

  @override
  String get extraHoursLabel => 'Horas extras';

  @override
  String get checkInTitle => 'ENTRADA';

  @override
  String get checkOutTitle => 'SAÍDA';

  @override
  String get ipAddressLabel => 'Endereço IP';

  @override
  String get gpsCoordinatesLabel => 'Coordenadas GPS';

  @override
  String get unknownValue => 'Desconhecido';

  @override
  String get notAvailableValue => 'Não disponível';

  @override
  String get viewOnMaps => 'Ver no Maps';

  @override
  String get notCheckedOutYet => 'Ainda não saiu';

  @override
  String hoursValue(String hours) {
    return '$hours h';
  }

  @override
  String get attendanceOnDuty => 'Em serviço';

  @override
  String get attendanceOffDuty => 'Fora de serviço';

  @override
  String get attendanceSwipeToCheckIn => 'Deslize para fazer check-in';

  @override
  String get attendanceSwipeToCheckOut => 'Deslize para fazer check-out';

  @override
  String get attendanceCurrentLocation => 'Localização atual';

  @override
  String get attendanceRefresh => 'ATUALIZAR';

  @override
  String get attendanceFetchingAddress => 'Obtendo endereço...';

  @override
  String get attendanceWaitingForGps => 'Aguardando GPS...';

  @override
  String get attendanceUploadSelfie => 'Enviar selfie';

  @override
  String get attendanceLocationRequired => 'A localização é necessária para continuar.';

  @override
  String get attendanceCheckInSuccess => 'Bem-vindo! Check-in registrado.';

  @override
  String get attendanceCheckOutSuccess => 'Turno encerrado. Bom trabalho!';

  @override
  String get attendanceCheckInFirst => 'Faça check-in primeiro.';

  @override
  String get attendanceSelfieUploaded => 'Selfie enviada';

  @override
  String get attendanceUploadFailed => 'Falha no envio';

  @override
  String get attendanceCameraError => 'Erro da câmera';

  @override
  String attendanceStartedAt(String time) {
    return 'Iniciado às $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Lat: $lat, Lng: $lng';
  }

  @override
  String get attendanceReadyToStart => 'Pronto para iniciar o turno';

  @override
  String get attendanceTitle => 'Ponto';

  @override
  String get attNavAttendance => 'Presença';

  @override
  String get attNavHistory => 'Histórico';

  @override
  String get attFiltersTitle => 'Filtros de ponto';

  @override
  String get attDateRangeLabel => 'Intervalo de datas';

  @override
  String get attStatusLabel => 'Status';

  @override
  String get attFilterTooltip => 'Filtrar';

  @override
  String get attClearFilters => 'Limpar filtros';

  @override
  String get attApplyFilters => 'Aplicar filtros';

  @override
  String get attFilterStatusAll => 'Todos os status';

  @override
  String get attFilterStatusOpen => 'Aberto (Check-in)';

  @override
  String get attFilterStatusClosed => 'Fechado (Check-out)';

  @override
  String get attFilterRangeToday => 'Hoje';

  @override
  String get attFilterRangeWeek => 'Esta semana';

  @override
  String get attFilterRangeMonth => 'Este mês';

  @override
  String get attFilterRangeAll => 'Todo o período';

  @override
  String attFilterDescription(String status, String range) {
    return '$status para $range';
  }

  @override
  String get attLoadingAttendance => 'Carregando ponto…';

  @override
  String get attLoadingMore => 'Carregando mais…';

  @override
  String get attFailedToLoad => 'Falha ao carregar ponto';

  @override
  String get attFailedToLoadMore => 'Falha ao carregar mais';

  @override
  String get attTryAgain => 'Tentar novamente';

  @override
  String get attNoAttendanceTitle => 'Nenhum registro encontrado';

  @override
  String get attNoAttendanceSubtitle => 'Tente ajustar os filtros (datas ou status).';

  @override
  String get attNoMoreItems => 'Você chegou ao fim da lista.';

  @override
  String employeeFallback(String id) {
    return 'Funcionário #$id';
  }

  @override
  String get attDetailsTitle => 'Detalhes de presença';

  @override
  String get attEmployeeLabel => 'Funcionário';

  @override
  String get attWorkedTimeLabel => 'Tempo trabalhado';

  @override
  String get attExtraHoursLabel => 'Horas extras';

  @override
  String get attCheckInSection => 'ENTRADA';

  @override
  String get attCheckOutSection => 'SAÍDA';

  @override
  String get attIpAddressLabel => 'Endereço IP';

  @override
  String get attGpsCoordinatesLabel => 'Coordenadas GPS';

  @override
  String get attViewOnMaps => 'Ver no Maps';

  @override
  String get attUnknownValue => 'Desconhecido';

  @override
  String get attNotAvailableValue => 'Não disponível';

  @override
  String get attNotCheckedOutYet => 'Ainda não fez check-out';

  @override
  String get attZeroHours => '0.00 h';
}
