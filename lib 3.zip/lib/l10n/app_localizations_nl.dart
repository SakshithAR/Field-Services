// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Dutch Flemish (`nl`).
class AppLocalizationsNl extends AppLocalizations {
  AppLocalizationsNl([String locale = 'nl']) : super(locale);

  @override
  String get configureOdooServer => 'Odoo-server configureren';

  @override
  String get jobs => 'Werkopdrachten';

  @override
  String get searchJobsHint => 'Werkopdrachten zoeken...';

  @override
  String get sortBy => 'Sorteren op';

  @override
  String get sortScheduledNearest => 'Gepland (eerstkomend)';

  @override
  String get sortScheduledFarthest => 'Gepland (verst in de tijd)';

  @override
  String get sortCustomerAZ => 'Klant (A-Z)';

  @override
  String get sortStatus => 'Status';

  @override
  String get tabAssigned => 'Toegewezen';

  @override
  String get tabInProgress => 'Bezig';

  @override
  String get tabDone => 'Afgerond';

  @override
  String get tabAll => 'Alles';

  @override
  String get emptyJobsTitle => 'Geen werkopdrachten';

  @override
  String get emptyJobsSubtitle => 'Probeer de zoekopdracht of filters te wijzigen';

  @override
  String get emptyJobsAddButton => 'Nieuwe werkopdracht toevoegen';

  @override
  String get noSchedule => 'Geen planning';

  @override
  String get statusDraft => 'Concept';

  @override
  String get statusAssigned => 'Toegewezen';

  @override
  String get statusInProgress => 'Bezig';

  @override
  String get statusDone => 'Afgerond';

  @override
  String get statusCancelled => 'Geannuleerd';

  @override
  String get settingsTitle => 'App-instellingen';

  @override
  String get settingsAppearance => 'Weergave';

  @override
  String get settingsTheme => 'Thema';

  @override
  String get settingsThemeLight => 'Licht';

  @override
  String get settingsThemeDark => 'Donker';

  @override
  String get settingsThemeSystem => 'Systeem';

  @override
  String get settingsAccentColor => 'Accentkleur';

  @override
  String get settingsAccentColorPick => 'Kleur kiezen';

  @override
  String get settingsAccentColorDialogTitle => 'Kies een kleur';

  @override
  String get settingsLanguageSection => 'Taal en tekst';

  @override
  String get settingsLanguageLabel => 'Taal';

  @override
  String get settingsAboutSection => 'Over de app';

  @override
  String get settingsVersionLabel => 'Versie';

  @override
  String get languageEnglish => 'Engels';

  @override
  String get languageArabic => 'Arabisch';

  @override
  String get navJobs => 'Werkopdrachten';

  @override
  String get navCalendar => 'Agenda';

  @override
  String get navMap => 'Kaart';

  @override
  String get navProfile => 'Profiel';

  @override
  String get profileSectionSettingsAndMore => 'Instellingen en meer';

  @override
  String get profileSettingsTitle => 'Instellingen';

  @override
  String get profileSettingsSubtitle => 'App- en thema-instellingen';

  @override
  String get profileLogoutTitle => 'Afmelden';

  @override
  String get profileLogoutSubtitle => 'Afmelden bij je account';

  @override
  String get profileLoggedIn => 'Aangemeld';

  @override
  String get jobDetailSchedule => 'Planning';

  @override
  String get jobDetailStart => 'Start';

  @override
  String get jobDetailEnd => 'Einde';

  @override
  String get jobDetailDuration => 'Duur';

  @override
  String get jobDetailLocation => 'Locatie';

  @override
  String get jobDetailLatShort => 'Breedte';

  @override
  String get jobDetailLngShort => 'Lengte';

  @override
  String get jobDetailOpenInMaps => 'Openen in Maps';

  @override
  String get jobDetailNotes => 'Notities';

  @override
  String get jobDetailCustomerNotes => 'Klantnotities';

  @override
  String get jobDetailInternalNotes => 'Interne notities';

  @override
  String get jobDetailPhotos => 'Foto\'s';

  @override
  String get jobDetailAddPhotos => 'Foto\'s toevoegen';

  @override
  String get jobDetailPhotosHint => 'Tik ergens op deze kaart of gebruik de knop om foto\'s toe te voegen vanaf de camera of galerij.';

  @override
  String get jobDetailTakePhotoCamera => 'Foto maken (camera)';

  @override
  String get jobDetailChooseFromGallery => 'Kiezen uit galerij';

  @override
  String get jobDetailAuth => 'Authenticatie';

  @override
  String get jobDetailAuthTooltip => 'Authenticatie openen';

  @override
  String get jobDetailAuthHint => 'Tik op deze kaart om de authenticatie van de klant (handtekening) vast te leggen.';

  @override
  String get jobDetailAuthSavedSignature => 'Opgeslagen handtekening';

  @override
  String get jobDetailNoCustomer => 'Geen klant';

  @override
  String get jobDetailUnassigned => 'Niet toegewezen';

  @override
  String get jobDetailStartButton => 'Starten';

  @override
  String get jobDetailMarkDone => 'Markeren als voltooid';

  @override
  String get jobDetailAssign => 'Toewijzen';

  @override
  String get jobDetailUpdateFailed => 'Bijwerken van werkopdracht mislukt';

  @override
  String get locationServicesDisabled => 'Locatiediensten zijn uitgeschakeld';

  @override
  String get locationPermissionDenied => 'Locatierechten geweigerd';

  @override
  String get jobDetailStartFailed => 'Starten van werkopdracht mislukt';

  @override
  String get jobDetailNoLocationData => 'Geen GPS of adres beschikbaar voor deze werkopdracht';

  @override
  String get jobDetailNoAddress => 'Geen adres beschikbaar voor deze werkopdracht';

  @override
  String get jobDetailMapOpenFailed => 'Kon de kaarten-app niet openen';

  @override
  String get jobDetailMapError => 'Kaarten openen mislukt';

  @override
  String get jobDetailPhotosUploaded => 'foto(\'s) geüpload';

  @override
  String get jobDetailPhotosUploadFailed => 'Uploaden van foto\'s mislukt';

  @override
  String get authSaved => 'Authenticatie opgeslagen';

  @override
  String get authSaveFailed => 'Opslaan van handtekening mislukt';

  @override
  String get authSignInstruction => 'Vraag de klant om in het kader hieronder te tekenen.';

  @override
  String get photoViewerTitle => 'Foto';

  @override
  String get commonRefresh => 'Vernieuwen';

  @override
  String get commonClear => 'Wissen';

  @override
  String get commonCancel => 'Annuleren';

  @override
  String get commonSave => 'Opslaan';

  @override
  String get addJobTitle => 'Nieuwe werkopdracht';

  @override
  String get addJobJobTitleLabel => 'Titel werkopdracht';

  @override
  String get addJobJobTitleHint => 'Bijv.: AC-onderhoud – Villa 12B';

  @override
  String get addJobJobTitleRequired => 'Voer een titel voor de werkopdracht in';

  @override
  String get addJobScheduledLabel => 'Geplande datum en tijd';

  @override
  String get addJobDateTimeNotSet => 'Niet ingesteld';

  @override
  String get addJobCustomerNotesLabel => 'Klantnotities (optioneel)';

  @override
  String get addJobCustomerNotesHint => 'Notities van klant, toegangsinfo, enz.';

  @override
  String get addJobInternalNotesLabel => 'Interne notities (optioneel)';

  @override
  String get addJobInternalNotesHint => 'Notities alleen voor je team';

  @override
  String get addJobCreateButton => 'Werkopdracht aanmaken';

  @override
  String get addJobCreated => 'Werkopdracht aangemaakt';

  @override
  String get addJobCreateFailed => 'Aanmaken van werkopdracht mislukt';

  @override
  String get calendarRefreshTooltip => 'Werkopdrachten vernieuwen';

  @override
  String get calendarJobsOnPrefix => 'Werkopdrachten op';

  @override
  String get calendarNoJobsOnDay => 'Geen werkopdrachten op deze dag';

  @override
  String get mapTitle => 'Kaart met werkopdrachten';

  @override
  String get mapEmptyTitle => 'Geen werkopdrachten om op de kaart te tonen';

  @override
  String get mapBottomTitle => 'Werkopdrachten op de kaart';

  @override
  String get mapJobsLabel => 'werkopdrachten';

  @override
  String get myJobsTitle => 'Mijn werkopdrachten';

  @override
  String get mapYouAreHere => 'Je bent hier';

  @override
  String get loginWelcomeBack => 'Welkom terug';

  @override
  String get loginSubtitle => 'Meld je aan om je field service-werkopdrachten te beheren.';

  @override
  String get loginDetailsTitle => 'Inloggegevens';

  @override
  String get loginEmailLabel => 'E-mail / Login';

  @override
  String get loginPasswordLabel => 'Wachtwoord';

  @override
  String get loginButton => 'Inloggen';

  @override
  String get loginError => 'Inloggen mislukt. Controleer de gegevens en de server.';

  @override
  String get validationRequired => 'Verplicht';

  @override
  String get loginConnectedServer => 'Verbonden server';

  @override
  String get loginNoServerConfigured => 'Nog geen server geconfigureerd';

  @override
  String loginServerDb(String dbName) {
    return 'DB: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'DB: -';

  @override
  String get loginChangeServer => 'Server wijzigen';

  @override
  String get loginPoweredBy => 'Aangedreven door Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Geef aan welke Odoo-server en database de app moet gebruiken.';

  @override
  String get serverConfigSectionConnectionDetails => 'Verbindingsgegevens';

  @override
  String get serverConfigServerUrlLabel => 'Server-URL';

  @override
  String get serverConfigServerUrlHint => 'https://jouw-odoo-domein.com';

  @override
  String get serverConfigDbNameLabel => 'Databasenaam';

  @override
  String get serverConfigSaveButton => 'Opslaan en doorgaan';

  @override
  String get serverConfigSaveHint => 'Je kunt dit later altijd wijzigen vanaf het inlogscherm.';

  @override
  String get serverConfigDbAutoDetectError => 'Database kan niet automatisch worden gedetecteerd. Controleer de URL.';

  @override
  String get attendanceDetailsTitle => 'Aanwezigheidsdetails';

  @override
  String get employeeLabel => 'Medewerker';

  @override
  String get statusOpen => 'OPEN';

  @override
  String get statusClosed => 'GESLOTEN';

  @override
  String get workedTimeLabel => 'Gewerkte tijd';

  @override
  String get extraHoursLabel => 'Overuren';

  @override
  String get checkInTitle => 'INLOGGEN';

  @override
  String get checkOutTitle => 'UITLOGGEN';

  @override
  String get ipAddressLabel => 'IP-adres';

  @override
  String get gpsCoordinatesLabel => 'GPS-coördinaten';

  @override
  String get unknownValue => 'Onbekend';

  @override
  String get notAvailableValue => 'Niet beschikbaar';

  @override
  String get viewOnMaps => 'Bekijken op Maps';

  @override
  String get notCheckedOutYet => 'Nog niet uitgeklokt';

  @override
  String hoursValue(String hours) {
    return '$hours uur';
  }

  @override
  String get attendanceOnDuty => 'Aan het werk';

  @override
  String get attendanceOffDuty => 'Niet aan het werk';

  @override
  String get attendanceSwipeToCheckIn => 'Veeg om in te klokken';

  @override
  String get attendanceSwipeToCheckOut => 'Veeg om uit te klokken';

  @override
  String get attendanceCurrentLocation => 'Huidige locatie';

  @override
  String get attendanceRefresh => 'VERVERSEN';

  @override
  String get attendanceFetchingAddress => 'Adres ophalen...';

  @override
  String get attendanceWaitingForGps => 'Wachten op GPS...';

  @override
  String get attendanceUploadSelfie => 'Selfie uploaden';

  @override
  String get attendanceLocationRequired => 'Locatie is vereist om door te gaan.';

  @override
  String get attendanceCheckInSuccess => 'Welkom! Inklokken geregistreerd.';

  @override
  String get attendanceCheckOutSuccess => 'Dienst beëindigd. Goed gedaan!';

  @override
  String get attendanceCheckInFirst => 'Eerst inklokken a.u.b.';

  @override
  String get attendanceSelfieUploaded => 'Selfie geüpload';

  @override
  String get attendanceUploadFailed => 'Upload mislukt';

  @override
  String get attendanceCameraError => 'Camera fout';

  @override
  String attendanceStartedAt(String time) {
    return 'Gestart om $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Lat: $lat, Lng: $lng';
  }

  @override
  String get attendanceReadyToStart => 'Klaar om de dienst te starten';

  @override
  String get attendanceTitle => 'Aanwezigheid';

  @override
  String get attNavAttendance => 'Aanwezigheid';

  @override
  String get attNavHistory => 'Geschiedenis';

  @override
  String get attFiltersTitle => 'Aanwezigheidsfilters';

  @override
  String get attDateRangeLabel => 'Datumbereik';

  @override
  String get attStatusLabel => 'Status';

  @override
  String get attFilterTooltip => 'Filter';

  @override
  String get attClearFilters => 'Filters wissen';

  @override
  String get attApplyFilters => 'Filters toepassen';

  @override
  String get attFilterStatusAll => 'Alle statussen';

  @override
  String get attFilterStatusOpen => 'Open (Ingeklokt)';

  @override
  String get attFilterStatusClosed => 'Gesloten (Uitgeklokt)';

  @override
  String get attFilterRangeToday => 'Vandaag';

  @override
  String get attFilterRangeWeek => 'Deze week';

  @override
  String get attFilterRangeMonth => 'Deze maand';

  @override
  String get attFilterRangeAll => 'Altijd';

  @override
  String attFilterDescription(String status, String range) {
    return '$status voor $range';
  }

  @override
  String get attLoadingAttendance => 'Aanwezigheid laden…';

  @override
  String get attLoadingMore => 'Meer laden…';

  @override
  String get attFailedToLoad => 'Aanwezigheid laden mislukt';

  @override
  String get attFailedToLoadMore => 'Meer laden mislukt';

  @override
  String get attTryAgain => 'Opnieuw proberen';

  @override
  String get attNoAttendanceTitle => 'Geen aanwezigheid gevonden';

  @override
  String get attNoAttendanceSubtitle => 'Pas je filters aan (datumbereik of status).';

  @override
  String get attNoMoreItems => 'Je hebt het einde van de lijst bereikt.';

  @override
  String employeeFallback(String id) {
    return 'Medewerker #$id';
  }

  @override
  String get attDetailsTitle => 'Aanwezigheidsdetails';

  @override
  String get attEmployeeLabel => 'Medewerker';

  @override
  String get attWorkedTimeLabel => 'Gewerkte tijd';

  @override
  String get attExtraHoursLabel => 'Overuren';

  @override
  String get attCheckInSection => 'INKLOKKEN';

  @override
  String get attCheckOutSection => 'UITKLOKKEN';

  @override
  String get attIpAddressLabel => 'IP-adres';

  @override
  String get attGpsCoordinatesLabel => 'GPS-coördinaten';

  @override
  String get attViewOnMaps => 'Bekijk op Maps';

  @override
  String get attUnknownValue => 'Onbekend';

  @override
  String get attNotAvailableValue => 'Niet beschikbaar';

  @override
  String get attNotCheckedOutYet => 'Nog niet uitgeklokt';

  @override
  String get attZeroHours => '0.00 uur';
}
