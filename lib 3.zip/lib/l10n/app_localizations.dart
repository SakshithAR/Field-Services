import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_de.dart';
import 'app_localizations_en.dart';
import 'app_localizations_es.dart';
import 'app_localizations_fil.dart';
import 'app_localizations_fr.dart';
import 'app_localizations_hi.dart';
import 'app_localizations_it.dart';
import 'app_localizations_nl.dart';
import 'app_localizations_pt.dart';
import 'app_localizations_ru.dart';
import 'app_localizations_sw.dart';
import 'app_localizations_th.dart';
import 'app_localizations_tr.dart';
import 'app_localizations_zh.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('de'),
    Locale('en'),
    Locale('es'),
    Locale('fil'),
    Locale('fr'),
    Locale('hi'),
    Locale('it'),
    Locale('nl'),
    Locale('pt'),
    Locale('ru'),
    Locale('sw'),
    Locale('th'),
    Locale('tr'),
    Locale('zh')
  ];

  /// No description provided for @configureOdooServer.
  ///
  /// In en, this message translates to:
  /// **'Configure Odoo Server'**
  String get configureOdooServer;

  /// No description provided for @jobs.
  ///
  /// In en, this message translates to:
  /// **'Jobs'**
  String get jobs;

  /// No description provided for @searchJobsHint.
  ///
  /// In en, this message translates to:
  /// **'Search jobs...'**
  String get searchJobsHint;

  /// No description provided for @sortBy.
  ///
  /// In en, this message translates to:
  /// **'Sort by'**
  String get sortBy;

  /// No description provided for @sortScheduledNearest.
  ///
  /// In en, this message translates to:
  /// **'Scheduled (nearest first)'**
  String get sortScheduledNearest;

  /// No description provided for @sortScheduledFarthest.
  ///
  /// In en, this message translates to:
  /// **'Scheduled (farthest first)'**
  String get sortScheduledFarthest;

  /// No description provided for @sortCustomerAZ.
  ///
  /// In en, this message translates to:
  /// **'Customer (A-Z)'**
  String get sortCustomerAZ;

  /// No description provided for @sortStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get sortStatus;

  /// No description provided for @tabAssigned.
  ///
  /// In en, this message translates to:
  /// **'Assigned'**
  String get tabAssigned;

  /// No description provided for @tabInProgress.
  ///
  /// In en, this message translates to:
  /// **'In progress'**
  String get tabInProgress;

  /// No description provided for @tabDone.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get tabDone;

  /// No description provided for @tabAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get tabAll;

  /// No description provided for @emptyJobsTitle.
  ///
  /// In en, this message translates to:
  /// **'No jobs'**
  String get emptyJobsTitle;

  /// No description provided for @emptyJobsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Try changing search or filters'**
  String get emptyJobsSubtitle;

  /// No description provided for @emptyJobsAddButton.
  ///
  /// In en, this message translates to:
  /// **'Add new job'**
  String get emptyJobsAddButton;

  /// No description provided for @noSchedule.
  ///
  /// In en, this message translates to:
  /// **'No schedule'**
  String get noSchedule;

  /// No description provided for @statusDraft.
  ///
  /// In en, this message translates to:
  /// **'Draft'**
  String get statusDraft;

  /// No description provided for @statusAssigned.
  ///
  /// In en, this message translates to:
  /// **'Assigned'**
  String get statusAssigned;

  /// No description provided for @statusInProgress.
  ///
  /// In en, this message translates to:
  /// **'In progress'**
  String get statusInProgress;

  /// No description provided for @statusDone.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get statusDone;

  /// No description provided for @statusCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get statusCancelled;

  /// No description provided for @settingsTitle.
  ///
  /// In en, this message translates to:
  /// **'App settings'**
  String get settingsTitle;

  /// No description provided for @settingsAppearance.
  ///
  /// In en, this message translates to:
  /// **'Appearance'**
  String get settingsAppearance;

  /// No description provided for @settingsTheme.
  ///
  /// In en, this message translates to:
  /// **'Theme'**
  String get settingsTheme;

  /// No description provided for @settingsThemeLight.
  ///
  /// In en, this message translates to:
  /// **'Light'**
  String get settingsThemeLight;

  /// No description provided for @settingsThemeDark.
  ///
  /// In en, this message translates to:
  /// **'Dark'**
  String get settingsThemeDark;

  /// No description provided for @settingsThemeSystem.
  ///
  /// In en, this message translates to:
  /// **'System'**
  String get settingsThemeSystem;

  /// No description provided for @settingsAccentColor.
  ///
  /// In en, this message translates to:
  /// **'Accent color'**
  String get settingsAccentColor;

  /// No description provided for @settingsAccentColorPick.
  ///
  /// In en, this message translates to:
  /// **'Pick color'**
  String get settingsAccentColorPick;

  /// No description provided for @settingsAccentColorDialogTitle.
  ///
  /// In en, this message translates to:
  /// **'Choose a color'**
  String get settingsAccentColorDialogTitle;

  /// No description provided for @settingsLanguageSection.
  ///
  /// In en, this message translates to:
  /// **'Language & text'**
  String get settingsLanguageSection;

  /// No description provided for @settingsLanguageLabel.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get settingsLanguageLabel;

  /// No description provided for @settingsAboutSection.
  ///
  /// In en, this message translates to:
  /// **'About the app'**
  String get settingsAboutSection;

  /// No description provided for @settingsVersionLabel.
  ///
  /// In en, this message translates to:
  /// **'Version'**
  String get settingsVersionLabel;

  /// No description provided for @languageEnglish.
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get languageEnglish;

  /// No description provided for @languageArabic.
  ///
  /// In en, this message translates to:
  /// **'Arabic'**
  String get languageArabic;

  /// No description provided for @navJobs.
  ///
  /// In en, this message translates to:
  /// **'Jobs'**
  String get navJobs;

  /// No description provided for @navCalendar.
  ///
  /// In en, this message translates to:
  /// **'Calendar'**
  String get navCalendar;

  /// No description provided for @navMap.
  ///
  /// In en, this message translates to:
  /// **'Map'**
  String get navMap;

  /// No description provided for @navProfile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get navProfile;

  /// No description provided for @profileSectionSettingsAndMore.
  ///
  /// In en, this message translates to:
  /// **'Settings & more'**
  String get profileSectionSettingsAndMore;

  /// No description provided for @profileSettingsTitle.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get profileSettingsTitle;

  /// No description provided for @profileSettingsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'App and theme settings'**
  String get profileSettingsSubtitle;

  /// No description provided for @profileLogoutTitle.
  ///
  /// In en, this message translates to:
  /// **'Logout'**
  String get profileLogoutTitle;

  /// No description provided for @profileLogoutSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Sign out of your account'**
  String get profileLogoutSubtitle;

  /// No description provided for @profileLoggedIn.
  ///
  /// In en, this message translates to:
  /// **'Logged in'**
  String get profileLoggedIn;

  /// No description provided for @jobDetailSchedule.
  ///
  /// In en, this message translates to:
  /// **'Schedule'**
  String get jobDetailSchedule;

  /// No description provided for @jobDetailStart.
  ///
  /// In en, this message translates to:
  /// **'Start'**
  String get jobDetailStart;

  /// No description provided for @jobDetailEnd.
  ///
  /// In en, this message translates to:
  /// **'End'**
  String get jobDetailEnd;

  /// No description provided for @jobDetailDuration.
  ///
  /// In en, this message translates to:
  /// **'Duration'**
  String get jobDetailDuration;

  /// No description provided for @jobDetailLocation.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get jobDetailLocation;

  /// No description provided for @jobDetailLatShort.
  ///
  /// In en, this message translates to:
  /// **'Lat'**
  String get jobDetailLatShort;

  /// No description provided for @jobDetailLngShort.
  ///
  /// In en, this message translates to:
  /// **'Lng'**
  String get jobDetailLngShort;

  /// No description provided for @jobDetailOpenInMaps.
  ///
  /// In en, this message translates to:
  /// **'Open in Maps'**
  String get jobDetailOpenInMaps;

  /// No description provided for @jobDetailNotes.
  ///
  /// In en, this message translates to:
  /// **'Notes'**
  String get jobDetailNotes;

  /// No description provided for @jobDetailCustomerNotes.
  ///
  /// In en, this message translates to:
  /// **'Customer notes'**
  String get jobDetailCustomerNotes;

  /// No description provided for @jobDetailInternalNotes.
  ///
  /// In en, this message translates to:
  /// **'Internal notes'**
  String get jobDetailInternalNotes;

  /// No description provided for @jobDetailPhotos.
  ///
  /// In en, this message translates to:
  /// **'Photos'**
  String get jobDetailPhotos;

  /// No description provided for @jobDetailAddPhotos.
  ///
  /// In en, this message translates to:
  /// **'Add photos'**
  String get jobDetailAddPhotos;

  /// No description provided for @jobDetailPhotosHint.
  ///
  /// In en, this message translates to:
  /// **'Tap anywhere on this card or use the button to attach photos from camera or gallery.'**
  String get jobDetailPhotosHint;

  /// No description provided for @jobDetailTakePhotoCamera.
  ///
  /// In en, this message translates to:
  /// **'Take photo (camera)'**
  String get jobDetailTakePhotoCamera;

  /// No description provided for @jobDetailChooseFromGallery.
  ///
  /// In en, this message translates to:
  /// **'Choose from gallery'**
  String get jobDetailChooseFromGallery;

  /// No description provided for @jobDetailAuth.
  ///
  /// In en, this message translates to:
  /// **'Authentication'**
  String get jobDetailAuth;

  /// No description provided for @jobDetailAuthTooltip.
  ///
  /// In en, this message translates to:
  /// **'Open authentication'**
  String get jobDetailAuthTooltip;

  /// No description provided for @jobDetailAuthHint.
  ///
  /// In en, this message translates to:
  /// **'Tap on this card to capture customer authentication (signature).'**
  String get jobDetailAuthHint;

  /// No description provided for @jobDetailAuthSavedSignature.
  ///
  /// In en, this message translates to:
  /// **'Saved signature'**
  String get jobDetailAuthSavedSignature;

  /// No description provided for @jobDetailNoCustomer.
  ///
  /// In en, this message translates to:
  /// **'No customer'**
  String get jobDetailNoCustomer;

  /// No description provided for @jobDetailUnassigned.
  ///
  /// In en, this message translates to:
  /// **'Unassigned'**
  String get jobDetailUnassigned;

  /// No description provided for @jobDetailStartButton.
  ///
  /// In en, this message translates to:
  /// **'Start'**
  String get jobDetailStartButton;

  /// No description provided for @jobDetailMarkDone.
  ///
  /// In en, this message translates to:
  /// **'Mark done'**
  String get jobDetailMarkDone;

  /// No description provided for @jobDetailAssign.
  ///
  /// In en, this message translates to:
  /// **'Assign'**
  String get jobDetailAssign;

  /// No description provided for @jobDetailUpdateFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to update job'**
  String get jobDetailUpdateFailed;

  /// No description provided for @locationServicesDisabled.
  ///
  /// In en, this message translates to:
  /// **'Location services are disabled'**
  String get locationServicesDisabled;

  /// No description provided for @locationPermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'Location permission denied'**
  String get locationPermissionDenied;

  /// No description provided for @jobDetailStartFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to start job'**
  String get jobDetailStartFailed;

  /// No description provided for @jobDetailNoLocationData.
  ///
  /// In en, this message translates to:
  /// **'No GPS or address available for this job'**
  String get jobDetailNoLocationData;

  /// No description provided for @jobDetailNoAddress.
  ///
  /// In en, this message translates to:
  /// **'No address available for this job'**
  String get jobDetailNoAddress;

  /// No description provided for @jobDetailMapOpenFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not open map app'**
  String get jobDetailMapOpenFailed;

  /// No description provided for @jobDetailMapError.
  ///
  /// In en, this message translates to:
  /// **'Failed to open maps'**
  String get jobDetailMapError;

  /// No description provided for @jobDetailPhotosUploaded.
  ///
  /// In en, this message translates to:
  /// **'photo(s) uploaded'**
  String get jobDetailPhotosUploaded;

  /// No description provided for @jobDetailPhotosUploadFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to upload photos'**
  String get jobDetailPhotosUploadFailed;

  /// No description provided for @authSaved.
  ///
  /// In en, this message translates to:
  /// **'Authentication saved'**
  String get authSaved;

  /// No description provided for @authSaveFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to save signature'**
  String get authSaveFailed;

  /// No description provided for @authSignInstruction.
  ///
  /// In en, this message translates to:
  /// **'Ask the customer to sign inside the box below.'**
  String get authSignInstruction;

  /// No description provided for @photoViewerTitle.
  ///
  /// In en, this message translates to:
  /// **'Photo'**
  String get photoViewerTitle;

  /// No description provided for @commonRefresh.
  ///
  /// In en, this message translates to:
  /// **'Refresh'**
  String get commonRefresh;

  /// No description provided for @commonClear.
  ///
  /// In en, this message translates to:
  /// **'Clear'**
  String get commonClear;

  /// No description provided for @commonCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get commonCancel;

  /// No description provided for @commonSave.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get commonSave;

  /// No description provided for @addJobTitle.
  ///
  /// In en, this message translates to:
  /// **'New job'**
  String get addJobTitle;

  /// No description provided for @addJobJobTitleLabel.
  ///
  /// In en, this message translates to:
  /// **'Job title'**
  String get addJobJobTitleLabel;

  /// No description provided for @addJobJobTitleHint.
  ///
  /// In en, this message translates to:
  /// **'Ex: AC Maintenance – Villa 12B'**
  String get addJobJobTitleHint;

  /// No description provided for @addJobJobTitleRequired.
  ///
  /// In en, this message translates to:
  /// **'Please enter job title'**
  String get addJobJobTitleRequired;

  /// No description provided for @addJobScheduledLabel.
  ///
  /// In en, this message translates to:
  /// **'Scheduled date & time'**
  String get addJobScheduledLabel;

  /// No description provided for @addJobDateTimeNotSet.
  ///
  /// In en, this message translates to:
  /// **'Not set'**
  String get addJobDateTimeNotSet;

  /// No description provided for @addJobCustomerNotesLabel.
  ///
  /// In en, this message translates to:
  /// **'Customer notes (optional)'**
  String get addJobCustomerNotesLabel;

  /// No description provided for @addJobCustomerNotesHint.
  ///
  /// In en, this message translates to:
  /// **'Notes from customer, access info, etc.'**
  String get addJobCustomerNotesHint;

  /// No description provided for @addJobInternalNotesLabel.
  ///
  /// In en, this message translates to:
  /// **'Internal notes (optional)'**
  String get addJobInternalNotesLabel;

  /// No description provided for @addJobInternalNotesHint.
  ///
  /// In en, this message translates to:
  /// **'Notes for your team only'**
  String get addJobInternalNotesHint;

  /// No description provided for @addJobCreateButton.
  ///
  /// In en, this message translates to:
  /// **'Create job'**
  String get addJobCreateButton;

  /// No description provided for @addJobCreated.
  ///
  /// In en, this message translates to:
  /// **'Job created'**
  String get addJobCreated;

  /// No description provided for @addJobCreateFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to create job'**
  String get addJobCreateFailed;

  /// No description provided for @calendarRefreshTooltip.
  ///
  /// In en, this message translates to:
  /// **'Refresh jobs'**
  String get calendarRefreshTooltip;

  /// No description provided for @calendarJobsOnPrefix.
  ///
  /// In en, this message translates to:
  /// **'Jobs on'**
  String get calendarJobsOnPrefix;

  /// No description provided for @calendarNoJobsOnDay.
  ///
  /// In en, this message translates to:
  /// **'No jobs on this day'**
  String get calendarNoJobsOnDay;

  /// No description provided for @mapTitle.
  ///
  /// In en, this message translates to:
  /// **'Jobs map'**
  String get mapTitle;

  /// No description provided for @mapEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No jobs to show on map'**
  String get mapEmptyTitle;

  /// No description provided for @mapBottomTitle.
  ///
  /// In en, this message translates to:
  /// **'Jobs on map'**
  String get mapBottomTitle;

  /// No description provided for @mapJobsLabel.
  ///
  /// In en, this message translates to:
  /// **'jobs'**
  String get mapJobsLabel;

  /// No description provided for @myJobsTitle.
  ///
  /// In en, this message translates to:
  /// **'My jobs'**
  String get myJobsTitle;

  /// No description provided for @mapYouAreHere.
  ///
  /// In en, this message translates to:
  /// **'You are here'**
  String get mapYouAreHere;

  /// Header title on login page
  ///
  /// In en, this message translates to:
  /// **'Welcome back'**
  String get loginWelcomeBack;

  /// Subtitle under the login title
  ///
  /// In en, this message translates to:
  /// **'Sign in to manage your field service jobs.'**
  String get loginSubtitle;

  /// Section title above login form fields
  ///
  /// In en, this message translates to:
  /// **'Login details'**
  String get loginDetailsTitle;

  /// Label for email / login field
  ///
  /// In en, this message translates to:
  /// **'Email / Login'**
  String get loginEmailLabel;

  /// Label for password field
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get loginPasswordLabel;

  /// Login button text
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get loginButton;

  /// Error message when login fails
  ///
  /// In en, this message translates to:
  /// **'Login failed. Check credentials and server.'**
  String get loginError;

  /// Validation message for required field
  ///
  /// In en, this message translates to:
  /// **'Required'**
  String get validationRequired;

  /// Title for connected server card on login screen
  ///
  /// In en, this message translates to:
  /// **'Connected server'**
  String get loginConnectedServer;

  /// Shown when no server is configured
  ///
  /// In en, this message translates to:
  /// **'No server configured yet'**
  String get loginNoServerConfigured;

  /// Database label with name
  ///
  /// In en, this message translates to:
  /// **'DB: {dbName}'**
  String loginServerDb(String dbName);

  /// Database label when no database is set
  ///
  /// In en, this message translates to:
  /// **'DB: -'**
  String get loginServerDbEmpty;

  /// Button text to change server configuration
  ///
  /// In en, this message translates to:
  /// **'Change server'**
  String get loginChangeServer;

  /// Footer text on login screen
  ///
  /// In en, this message translates to:
  /// **'Powered by Taqnix Field Service'**
  String get loginPoweredBy;

  /// Subtitle explaining server configuration
  ///
  /// In en, this message translates to:
  /// **'Tell the app which Odoo server and database to use.'**
  String get serverConfigSubtitle;

  /// Section title for connection details
  ///
  /// In en, this message translates to:
  /// **'Connection details'**
  String get serverConfigSectionConnectionDetails;

  /// Label for Odoo server URL field
  ///
  /// In en, this message translates to:
  /// **'Server URL'**
  String get serverConfigServerUrlLabel;

  /// Example Odoo server URL
  ///
  /// In en, this message translates to:
  /// **'https://your-odoo-domain.com'**
  String get serverConfigServerUrlHint;

  /// Label for Odoo database name field
  ///
  /// In en, this message translates to:
  /// **'Database name'**
  String get serverConfigDbNameLabel;

  /// Button text to save server config and continue
  ///
  /// In en, this message translates to:
  /// **'Save and continue'**
  String get serverConfigSaveButton;

  /// Helper text shown below the save button
  ///
  /// In en, this message translates to:
  /// **'You can always change this later from the login screen.'**
  String get serverConfigSaveHint;

  /// Error message when DB auto-detection fails
  ///
  /// In en, this message translates to:
  /// **'Could not auto-detect database. Please check URL.'**
  String get serverConfigDbAutoDetectError;

  /// No description provided for @attendanceDetailsTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance Details'**
  String get attendanceDetailsTitle;

  /// No description provided for @employeeLabel.
  ///
  /// In en, this message translates to:
  /// **'Employee'**
  String get employeeLabel;

  /// No description provided for @statusOpen.
  ///
  /// In en, this message translates to:
  /// **'OPEN'**
  String get statusOpen;

  /// No description provided for @statusClosed.
  ///
  /// In en, this message translates to:
  /// **'CLOSED'**
  String get statusClosed;

  /// No description provided for @workedTimeLabel.
  ///
  /// In en, this message translates to:
  /// **'Worked Time'**
  String get workedTimeLabel;

  /// No description provided for @extraHoursLabel.
  ///
  /// In en, this message translates to:
  /// **'Extra Hours'**
  String get extraHoursLabel;

  /// No description provided for @checkInTitle.
  ///
  /// In en, this message translates to:
  /// **'CHECK IN'**
  String get checkInTitle;

  /// No description provided for @checkOutTitle.
  ///
  /// In en, this message translates to:
  /// **'CHECK OUT'**
  String get checkOutTitle;

  /// No description provided for @ipAddressLabel.
  ///
  /// In en, this message translates to:
  /// **'IP Address'**
  String get ipAddressLabel;

  /// No description provided for @gpsCoordinatesLabel.
  ///
  /// In en, this message translates to:
  /// **'GPS Coordinates'**
  String get gpsCoordinatesLabel;

  /// No description provided for @unknownValue.
  ///
  /// In en, this message translates to:
  /// **'Unknown'**
  String get unknownValue;

  /// No description provided for @notAvailableValue.
  ///
  /// In en, this message translates to:
  /// **'Not available'**
  String get notAvailableValue;

  /// No description provided for @viewOnMaps.
  ///
  /// In en, this message translates to:
  /// **'View on Maps'**
  String get viewOnMaps;

  /// No description provided for @notCheckedOutYet.
  ///
  /// In en, this message translates to:
  /// **'Not Checked Out Yet'**
  String get notCheckedOutYet;

  /// Formats hours value like '2.50 hrs'
  ///
  /// In en, this message translates to:
  /// **'{hours} hrs'**
  String hoursValue(String hours);

  /// No description provided for @attendanceOnDuty.
  ///
  /// In en, this message translates to:
  /// **'On Duty'**
  String get attendanceOnDuty;

  /// No description provided for @attendanceOffDuty.
  ///
  /// In en, this message translates to:
  /// **'Off Duty'**
  String get attendanceOffDuty;

  /// No description provided for @attendanceSwipeToCheckIn.
  ///
  /// In en, this message translates to:
  /// **'Swipe to Check In'**
  String get attendanceSwipeToCheckIn;

  /// No description provided for @attendanceSwipeToCheckOut.
  ///
  /// In en, this message translates to:
  /// **'Swipe to Check Out'**
  String get attendanceSwipeToCheckOut;

  /// No description provided for @attendanceCurrentLocation.
  ///
  /// In en, this message translates to:
  /// **'Current Location'**
  String get attendanceCurrentLocation;

  /// No description provided for @attendanceRefresh.
  ///
  /// In en, this message translates to:
  /// **'REFRESH'**
  String get attendanceRefresh;

  /// No description provided for @attendanceFetchingAddress.
  ///
  /// In en, this message translates to:
  /// **'Fetching address...'**
  String get attendanceFetchingAddress;

  /// No description provided for @attendanceWaitingForGps.
  ///
  /// In en, this message translates to:
  /// **'Waiting for GPS...'**
  String get attendanceWaitingForGps;

  /// No description provided for @attendanceUploadSelfie.
  ///
  /// In en, this message translates to:
  /// **'Upload Selfie'**
  String get attendanceUploadSelfie;

  /// No description provided for @attendanceLocationRequired.
  ///
  /// In en, this message translates to:
  /// **'Location required to proceed.'**
  String get attendanceLocationRequired;

  /// No description provided for @attendanceCheckInSuccess.
  ///
  /// In en, this message translates to:
  /// **'Welcome! Check-in recorded.'**
  String get attendanceCheckInSuccess;

  /// No description provided for @attendanceCheckOutSuccess.
  ///
  /// In en, this message translates to:
  /// **'Shift ended. Good job!'**
  String get attendanceCheckOutSuccess;

  /// No description provided for @attendanceCheckInFirst.
  ///
  /// In en, this message translates to:
  /// **'Please check in first.'**
  String get attendanceCheckInFirst;

  /// No description provided for @attendanceSelfieUploaded.
  ///
  /// In en, this message translates to:
  /// **'Selfie uploaded'**
  String get attendanceSelfieUploaded;

  /// No description provided for @attendanceUploadFailed.
  ///
  /// In en, this message translates to:
  /// **'Upload failed'**
  String get attendanceUploadFailed;

  /// No description provided for @attendanceCameraError.
  ///
  /// In en, this message translates to:
  /// **'Camera error'**
  String get attendanceCameraError;

  /// No description provided for @attendanceStartedAt.
  ///
  /// In en, this message translates to:
  /// **'Started at {time}'**
  String attendanceStartedAt(String time);

  /// No description provided for @attendanceLatLng.
  ///
  /// In en, this message translates to:
  /// **'Lat: {lat}, Lng: {lng}'**
  String attendanceLatLng(String lat, String lng);

  /// No description provided for @attendanceReadyToStart.
  ///
  /// In en, this message translates to:
  /// **'Ready to start shift'**
  String get attendanceReadyToStart;

  /// No description provided for @attendanceTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance'**
  String get attendanceTitle;

  /// No description provided for @attNavAttendance.
  ///
  /// In en, this message translates to:
  /// **'Attendance'**
  String get attNavAttendance;

  /// No description provided for @attNavHistory.
  ///
  /// In en, this message translates to:
  /// **'History'**
  String get attNavHistory;

  /// No description provided for @attFiltersTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance Filters'**
  String get attFiltersTitle;

  /// No description provided for @attDateRangeLabel.
  ///
  /// In en, this message translates to:
  /// **'Date Range'**
  String get attDateRangeLabel;

  /// No description provided for @attStatusLabel.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get attStatusLabel;

  /// No description provided for @attFilterTooltip.
  ///
  /// In en, this message translates to:
  /// **'Filter'**
  String get attFilterTooltip;

  /// No description provided for @attClearFilters.
  ///
  /// In en, this message translates to:
  /// **'Clear Filters'**
  String get attClearFilters;

  /// No description provided for @attApplyFilters.
  ///
  /// In en, this message translates to:
  /// **'Apply Filters'**
  String get attApplyFilters;

  /// No description provided for @attFilterStatusAll.
  ///
  /// In en, this message translates to:
  /// **'All Statuses'**
  String get attFilterStatusAll;

  /// No description provided for @attFilterStatusOpen.
  ///
  /// In en, this message translates to:
  /// **'Open (Checked in)'**
  String get attFilterStatusOpen;

  /// No description provided for @attFilterStatusClosed.
  ///
  /// In en, this message translates to:
  /// **'Closed (Checked out)'**
  String get attFilterStatusClosed;

  /// No description provided for @attFilterRangeToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get attFilterRangeToday;

  /// No description provided for @attFilterRangeWeek.
  ///
  /// In en, this message translates to:
  /// **'This week'**
  String get attFilterRangeWeek;

  /// No description provided for @attFilterRangeMonth.
  ///
  /// In en, this message translates to:
  /// **'This month'**
  String get attFilterRangeMonth;

  /// No description provided for @attFilterRangeAll.
  ///
  /// In en, this message translates to:
  /// **'All time'**
  String get attFilterRangeAll;

  /// No description provided for @attFilterDescription.
  ///
  /// In en, this message translates to:
  /// **'{status} for {range}'**
  String attFilterDescription(String status, String range);

  /// No description provided for @attLoadingAttendance.
  ///
  /// In en, this message translates to:
  /// **'Loading attendance…'**
  String get attLoadingAttendance;

  /// No description provided for @attLoadingMore.
  ///
  /// In en, this message translates to:
  /// **'Loading more…'**
  String get attLoadingMore;

  /// No description provided for @attFailedToLoad.
  ///
  /// In en, this message translates to:
  /// **'Failed to load attendance'**
  String get attFailedToLoad;

  /// No description provided for @attFailedToLoadMore.
  ///
  /// In en, this message translates to:
  /// **'Failed to load more'**
  String get attFailedToLoadMore;

  /// No description provided for @attTryAgain.
  ///
  /// In en, this message translates to:
  /// **'Try again'**
  String get attTryAgain;

  /// No description provided for @attNoAttendanceTitle.
  ///
  /// In en, this message translates to:
  /// **'No attendance found'**
  String get attNoAttendanceTitle;

  /// No description provided for @attNoAttendanceSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Try adjusting your filters (date range or status).'**
  String get attNoAttendanceSubtitle;

  /// No description provided for @attNoMoreItems.
  ///
  /// In en, this message translates to:
  /// **'You\'ve reached the end of the list.'**
  String get attNoMoreItems;

  /// No description provided for @employeeFallback.
  ///
  /// In en, this message translates to:
  /// **'Employee #{id}'**
  String employeeFallback(String id);

  /// No description provided for @attDetailsTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance Details'**
  String get attDetailsTitle;

  /// No description provided for @attEmployeeLabel.
  ///
  /// In en, this message translates to:
  /// **'Employee'**
  String get attEmployeeLabel;

  /// No description provided for @attWorkedTimeLabel.
  ///
  /// In en, this message translates to:
  /// **'Worked Time'**
  String get attWorkedTimeLabel;

  /// No description provided for @attExtraHoursLabel.
  ///
  /// In en, this message translates to:
  /// **'Extra Hours'**
  String get attExtraHoursLabel;

  /// No description provided for @attCheckInSection.
  ///
  /// In en, this message translates to:
  /// **'CHECK IN'**
  String get attCheckInSection;

  /// No description provided for @attCheckOutSection.
  ///
  /// In en, this message translates to:
  /// **'CHECK OUT'**
  String get attCheckOutSection;

  /// No description provided for @attIpAddressLabel.
  ///
  /// In en, this message translates to:
  /// **'IP Address'**
  String get attIpAddressLabel;

  /// No description provided for @attGpsCoordinatesLabel.
  ///
  /// In en, this message translates to:
  /// **'GPS Coordinates'**
  String get attGpsCoordinatesLabel;

  /// No description provided for @attViewOnMaps.
  ///
  /// In en, this message translates to:
  /// **'View on Maps'**
  String get attViewOnMaps;

  /// No description provided for @attUnknownValue.
  ///
  /// In en, this message translates to:
  /// **'Unknown'**
  String get attUnknownValue;

  /// No description provided for @attNotAvailableValue.
  ///
  /// In en, this message translates to:
  /// **'Not available'**
  String get attNotAvailableValue;

  /// No description provided for @attNotCheckedOutYet.
  ///
  /// In en, this message translates to:
  /// **'Not Checked Out Yet'**
  String get attNotCheckedOutYet;

  /// No description provided for @attZeroHours.
  ///
  /// In en, this message translates to:
  /// **'0.00 hrs'**
  String get attZeroHours;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['ar', 'de', 'en', 'es', 'fil', 'fr', 'hi', 'it', 'nl', 'pt', 'ru', 'sw', 'th', 'tr', 'zh'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar': return AppLocalizationsAr();
    case 'de': return AppLocalizationsDe();
    case 'en': return AppLocalizationsEn();
    case 'es': return AppLocalizationsEs();
    case 'fil': return AppLocalizationsFil();
    case 'fr': return AppLocalizationsFr();
    case 'hi': return AppLocalizationsHi();
    case 'it': return AppLocalizationsIt();
    case 'nl': return AppLocalizationsNl();
    case 'pt': return AppLocalizationsPt();
    case 'ru': return AppLocalizationsRu();
    case 'sw': return AppLocalizationsSw();
    case 'th': return AppLocalizationsTh();
    case 'tr': return AppLocalizationsTr();
    case 'zh': return AppLocalizationsZh();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
