// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Swahili (`sw`).
class AppLocalizationsSw extends AppLocalizations {
  AppLocalizationsSw([String locale = 'sw']) : super(locale);

  @override
  String get configureOdooServer => 'Sanidi seva ya Odoo';

  @override
  String get jobs => 'Kazi';

  @override
  String get searchJobsHint => 'Tafuta kazi...';

  @override
  String get sortBy => 'Panga kwa';

  @override
  String get sortScheduledNearest => 'Ratiba (karibu zaidi kwanza)';

  @override
  String get sortScheduledFarthest => 'Ratiba (iliyopo mbali zaidi kwanza)';

  @override
  String get sortCustomerAZ => 'Mteja (A-Z)';

  @override
  String get sortStatus => 'Hali';

  @override
  String get tabAssigned => 'Zilizokabidhiwa';

  @override
  String get tabInProgress => 'Inaendelea';

  @override
  String get tabDone => 'Imekamilika';

  @override
  String get tabAll => 'Zote';

  @override
  String get emptyJobsTitle => 'Hakuna kazi';

  @override
  String get emptyJobsSubtitle => 'Jaribu kubadilisha utafutaji au vichujio';

  @override
  String get emptyJobsAddButton => 'Ongeza kazi mpya';

  @override
  String get noSchedule => 'Hakuna ratiba';

  @override
  String get statusDraft => 'Rasimu';

  @override
  String get statusAssigned => 'Imekabidhiwa';

  @override
  String get statusInProgress => 'Inaendelea';

  @override
  String get statusDone => 'Imekamilika';

  @override
  String get statusCancelled => 'Imebatilishwa';

  @override
  String get settingsTitle => 'Mipangilio ya programu';

  @override
  String get settingsAppearance => 'Muonekano';

  @override
  String get settingsTheme => 'Mandhari';

  @override
  String get settingsThemeLight => 'Nuru';

  @override
  String get settingsThemeDark => 'Giza';

  @override
  String get settingsThemeSystem => 'Mfumo';

  @override
  String get settingsAccentColor => 'Rangi ya msisitizo';

  @override
  String get settingsAccentColorPick => 'Chagua rangi';

  @override
  String get settingsAccentColorDialogTitle => 'Chagua rangi';

  @override
  String get settingsLanguageSection => 'Lugha na maandishi';

  @override
  String get settingsLanguageLabel => 'Lugha';

  @override
  String get settingsAboutSection => 'Kuhusu programu';

  @override
  String get settingsVersionLabel => 'Toleo';

  @override
  String get languageEnglish => 'Kiingereza';

  @override
  String get languageArabic => 'Kiarabu';

  @override
  String get navJobs => 'Kazi';

  @override
  String get navCalendar => 'Kalenda';

  @override
  String get navMap => 'Ramani';

  @override
  String get navProfile => 'Profaili';

  @override
  String get profileSectionSettingsAndMore => 'Mipangilio na zaidi';

  @override
  String get profileSettingsTitle => 'Mipangilio';

  @override
  String get profileSettingsSubtitle => 'Mipangilio ya programu na mandhari';

  @override
  String get profileLogoutTitle => 'Toka';

  @override
  String get profileLogoutSubtitle => 'Toka kwenye akaunti yako';

  @override
  String get profileLoggedIn => 'Umeingia';

  @override
  String get jobDetailSchedule => 'Ratiba';

  @override
  String get jobDetailStart => 'Anza';

  @override
  String get jobDetailEnd => 'Maliza';

  @override
  String get jobDetailDuration => 'Muda';

  @override
  String get jobDetailLocation => 'Mahali';

  @override
  String get jobDetailLatShort => 'Lat';

  @override
  String get jobDetailLngShort => 'Long';

  @override
  String get jobDetailOpenInMaps => 'Fungua kwenye Ramani';

  @override
  String get jobDetailNotes => 'Maelezo';

  @override
  String get jobDetailCustomerNotes => 'Maelezo ya mteja';

  @override
  String get jobDetailInternalNotes => 'Maelezo ya ndani';

  @override
  String get jobDetailPhotos => 'Picha';

  @override
  String get jobDetailAddPhotos => 'Ongeza picha';

  @override
  String get jobDetailPhotosHint => 'Gonga sehemu yoyote ya kadi hii au tumia kitufe kuongeza picha kutoka kwa kamera au maktaba.';

  @override
  String get jobDetailTakePhotoCamera => 'Piga picha (kamera)';

  @override
  String get jobDetailChooseFromGallery => 'Chagua kutoka maktaba';

  @override
  String get jobDetailAuth => 'Uthibitisho';

  @override
  String get jobDetailAuthTooltip => 'Fungua uthibitisho';

  @override
  String get jobDetailAuthHint => 'Gonga kadi hii ili kurekodi uthibitisho wa mteja (saini).';

  @override
  String get jobDetailAuthSavedSignature => 'Saini imehifadhiwa';

  @override
  String get jobDetailNoCustomer => 'Hakuna mteja';

  @override
  String get jobDetailUnassigned => 'Haijakabidhiwa';

  @override
  String get jobDetailStartButton => 'Anza';

  @override
  String get jobDetailMarkDone => 'Weka kuwa imekamilika';

  @override
  String get jobDetailAssign => 'Kabidhi';

  @override
  String get jobDetailUpdateFailed => 'Imeshindikana kusasisha kazi';

  @override
  String get locationServicesDisabled => 'Huduma za mahali zimezimwa';

  @override
  String get locationPermissionDenied => 'Ruhusa ya mahali imekataliwa';

  @override
  String get jobDetailStartFailed => 'Imeshindikana kuanza kazi';

  @override
  String get jobDetailNoLocationData => 'Hakuna GPS au anwani inayopatikana kwa kazi hii';

  @override
  String get jobDetailNoAddress => 'Hakuna anwani inayopatikana kwa kazi hii';

  @override
  String get jobDetailMapOpenFailed => 'Haiwezekani kufungua programu ya ramani';

  @override
  String get jobDetailMapError => 'Imeshindikana kufungua ramani';

  @override
  String get jobDetailPhotosUploaded => 'picha zimepakiwa';

  @override
  String get jobDetailPhotosUploadFailed => 'Imeshindikana kupakia picha';

  @override
  String get authSaved => 'Uthibitisho umehifadhiwa';

  @override
  String get authSaveFailed => 'Imeshindikana kuhifadhi saini';

  @override
  String get authSignInstruction => 'Mwombe mteja asaini ndani ya kisanduku hapa chini.';

  @override
  String get photoViewerTitle => 'Picha';

  @override
  String get commonRefresh => 'Onyesha upya';

  @override
  String get commonClear => 'Futa';

  @override
  String get commonCancel => 'Ghairi';

  @override
  String get commonSave => 'Hifadhi';

  @override
  String get addJobTitle => 'Kazi mpya';

  @override
  String get addJobJobTitleLabel => 'Kichwa cha kazi';

  @override
  String get addJobJobTitleHint => 'Mfano: Matengenezo ya AC – Nyumba 12B';

  @override
  String get addJobJobTitleRequired => 'Tafadhali weka kichwa cha kazi';

  @override
  String get addJobScheduledLabel => 'Tarehe na muda uliopangwa';

  @override
  String get addJobDateTimeNotSet => 'Haijawekwa';

  @override
  String get addJobCustomerNotesLabel => 'Maelezo ya mteja (si lazima)';

  @override
  String get addJobCustomerNotesHint => 'Maelezo kutoka kwa mteja, taarifa ya ufikiaji, n.k.';

  @override
  String get addJobInternalNotesLabel => 'Maelezo ya ndani (si lazima)';

  @override
  String get addJobInternalNotesHint => 'Maelezo kwa ajili ya timu yako pekee';

  @override
  String get addJobCreateButton => 'Unda kazi';

  @override
  String get addJobCreated => 'Kazi imeundwa';

  @override
  String get addJobCreateFailed => 'Imeshindikana kuunda kazi';

  @override
  String get calendarRefreshTooltip => 'Onyesha upya kazi';

  @override
  String get calendarJobsOnPrefix => 'Kazi tarehe';

  @override
  String get calendarNoJobsOnDay => 'Hakuna kazi siku hii';

  @override
  String get mapTitle => 'Ramani ya kazi';

  @override
  String get mapEmptyTitle => 'Hakuna kazi za kuonyesha kwenye ramani';

  @override
  String get mapBottomTitle => 'Kazi kwenye ramani';

  @override
  String get mapJobsLabel => 'kazi';

  @override
  String get myJobsTitle => 'Kazi zangu';

  @override
  String get mapYouAreHere => 'Uko hapa';

  @override
  String get loginWelcomeBack => 'Karibu tena';

  @override
  String get loginSubtitle => 'Ingia ili kudhibiti kazi za huduma ya uwanjani.';

  @override
  String get loginDetailsTitle => 'Taarifa za kuingia';

  @override
  String get loginEmailLabel => 'Barua pepe / Jina la mtumiaji';

  @override
  String get loginPasswordLabel => 'Nenosiri';

  @override
  String get loginButton => 'Ingia';

  @override
  String get loginError => 'Imeshindikana kuingia. Angalia kitambulisho na seva.';

  @override
  String get validationRequired => 'Lazima kujazwa';

  @override
  String get loginConnectedServer => 'Seva iliyounganishwa';

  @override
  String get loginNoServerConfigured => 'Hakuna seva iliyosanidiwa bado';

  @override
  String loginServerDb(String dbName) {
    return 'DB: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'DB: -';

  @override
  String get loginChangeServer => 'Badilisha seva';

  @override
  String get loginPoweredBy => 'Inaendeshwa na Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Iambie programu ni seva na hifadhidata gani ya Odoo itumie.';

  @override
  String get serverConfigSectionConnectionDetails => 'Maelezo ya muunganisho';

  @override
  String get serverConfigServerUrlLabel => 'URL ya seva';

  @override
  String get serverConfigServerUrlHint => 'https://your-odoo-domain.com';

  @override
  String get serverConfigDbNameLabel => 'Jina la hifadhidata';

  @override
  String get serverConfigSaveButton => 'Hifadhi na uendelee';

  @override
  String get serverConfigSaveHint => 'Unaweza kubadilisha hili wakati wowote kwenye skrini ya kuingia.';

  @override
  String get serverConfigDbAutoDetectError => 'Imeshindikana kutambua hifadhidata kiotomatiki. Tafadhali angalia URL.';

  @override
  String get attendanceDetailsTitle => 'Maelezo ya mahudhurio';

  @override
  String get employeeLabel => 'Mfanyakazi';

  @override
  String get statusOpen => 'WAZI';

  @override
  String get statusClosed => 'IMEFUNGWA';

  @override
  String get workedTimeLabel => 'Muda wa kazi';

  @override
  String get extraHoursLabel => 'Saa za ziada';

  @override
  String get checkInTitle => 'INGIA';

  @override
  String get checkOutTitle => 'TOKA';

  @override
  String get ipAddressLabel => 'Anwani ya IP';

  @override
  String get gpsCoordinatesLabel => 'Viunganishi vya GPS';

  @override
  String get unknownValue => 'Haijulikani';

  @override
  String get notAvailableValue => 'Haipatikani';

  @override
  String get viewOnMaps => 'Tazama kwenye ramani';

  @override
  String get notCheckedOutYet => 'Bado hajaondoka';

  @override
  String hoursValue(String hours) {
    return '$hours saa';
  }

  @override
  String get attendanceOnDuty => 'Kazini';

  @override
  String get attendanceOffDuty => 'Sio kazini';

  @override
  String get attendanceSwipeToCheckIn => 'Telezesha kuingia kazini';

  @override
  String get attendanceSwipeToCheckOut => 'Telezesha kutoka kazini';

  @override
  String get attendanceCurrentLocation => 'Eneo la sasa';

  @override
  String get attendanceRefresh => 'SASISHA';

  @override
  String get attendanceFetchingAddress => 'Inachukua anwani...';

  @override
  String get attendanceWaitingForGps => 'Inasubiri GPS...';

  @override
  String get attendanceUploadSelfie => 'Pakia selfie';

  @override
  String get attendanceLocationRequired => 'Eneo linahitajika ili kuendelea.';

  @override
  String get attendanceCheckInSuccess => 'Karibu! Umeingia kazini.';

  @override
  String get attendanceCheckOutSuccess => 'Zamu imeisha. Kazi nzuri!';

  @override
  String get attendanceCheckInFirst => 'Tafadhali ingia kazini kwanza.';

  @override
  String get attendanceSelfieUploaded => 'Selfie imepakiwa';

  @override
  String get attendanceUploadFailed => 'Kupakia kumeshindikana';

  @override
  String get attendanceCameraError => 'Hitilafu ya kamera';

  @override
  String attendanceStartedAt(String time) {
    return 'Ilianza saa $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Lat: $lat, Lng: $lng';
  }

  @override
  String get attendanceReadyToStart => 'Tayari kuanza zamu';

  @override
  String get attendanceTitle => 'Mahudhurio';

  @override
  String get attNavAttendance => 'Mahudhurio';

  @override
  String get attNavHistory => 'Historia';

  @override
  String get attFiltersTitle => 'Vichujio vya mahudhurio';

  @override
  String get attDateRangeLabel => 'Muda';

  @override
  String get attStatusLabel => 'Hali';

  @override
  String get attFilterTooltip => 'Chuja';

  @override
  String get attClearFilters => 'Futa vichujio';

  @override
  String get attApplyFilters => 'Tumia vichujio';

  @override
  String get attFilterStatusAll => 'Hali zote';

  @override
  String get attFilterStatusOpen => 'Wazi (Ameingia)';

  @override
  String get attFilterStatusClosed => 'Imefungwa (Ametoka)';

  @override
  String get attFilterRangeToday => 'Leo';

  @override
  String get attFilterRangeWeek => 'Wiki hii';

  @override
  String get attFilterRangeMonth => 'Mwezi huu';

  @override
  String get attFilterRangeAll => 'Muda wote';

  @override
  String attFilterDescription(String status, String range) {
    return '$status kwa $range';
  }

  @override
  String get attLoadingAttendance => 'Inapakia mahudhurio…';

  @override
  String get attLoadingMore => 'Inapakia zaidi…';

  @override
  String get attFailedToLoad => 'Imeshindikana kupakia';

  @override
  String get attFailedToLoadMore => 'Imeshindikana kupakia zaidi';

  @override
  String get attTryAgain => 'Jaribu tena';

  @override
  String get attNoAttendanceTitle => 'Hakuna mahudhurio';

  @override
  String get attNoAttendanceSubtitle => 'Jaribu kubadilisha vichujio (muda au hali).';

  @override
  String get attNoMoreItems => 'Umefika mwisho wa orodha.';

  @override
  String employeeFallback(String id) {
    return 'Mfanyakazi #$id';
  }

  @override
  String get attDetailsTitle => 'Maelezo ya Mahudhurio';

  @override
  String get attEmployeeLabel => 'Mfanyakazi';

  @override
  String get attWorkedTimeLabel => 'Muda Ulioufanya Kazi';

  @override
  String get attExtraHoursLabel => 'Saa za Ziada';

  @override
  String get attCheckInSection => 'INGIA';

  @override
  String get attCheckOutSection => 'TOKA';

  @override
  String get attIpAddressLabel => 'Anwani ya IP';

  @override
  String get attGpsCoordinatesLabel => 'Viashiria vya GPS';

  @override
  String get attViewOnMaps => 'Tazama kwenye Ramani';

  @override
  String get attUnknownValue => 'Haijulikani';

  @override
  String get attNotAvailableValue => 'Haipatikani';

  @override
  String get attNotCheckedOutYet => 'Bado hujatoka';

  @override
  String get attZeroHours => 'saa 0.00';
}
