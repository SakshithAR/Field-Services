// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Thai (`th`).
class AppLocalizationsTh extends AppLocalizations {
  AppLocalizationsTh([String locale = 'th']) : super(locale);

  @override
  String get configureOdooServer => 'กำหนดค่าเซิร์ฟเวอร์ Odoo';

  @override
  String get jobs => 'งาน';

  @override
  String get searchJobsHint => 'ค้นหางาน...';

  @override
  String get sortBy => 'เรียงตาม';

  @override
  String get sortScheduledNearest => 'กำหนดเวลา (ใกล้ที่สุดก่อน)';

  @override
  String get sortScheduledFarthest => 'กำหนดเวลา (ไกลที่สุดก่อน)';

  @override
  String get sortCustomerAZ => 'ลูกค้า (A-Z)';

  @override
  String get sortStatus => 'สถานะ';

  @override
  String get tabAssigned => 'มอบหมายแล้ว';

  @override
  String get tabInProgress => 'กำลังดำเนินการ';

  @override
  String get tabDone => 'เสร็จสิ้น';

  @override
  String get tabAll => 'ทั้งหมด';

  @override
  String get emptyJobsTitle => 'ยังไม่มีงาน';

  @override
  String get emptyJobsSubtitle => 'ลองเปลี่ยนการค้นหาหรือเงื่อนไขตัวกรอง';

  @override
  String get emptyJobsAddButton => 'เพิ่มงานใหม่';

  @override
  String get noSchedule => 'ยังไม่กำหนดเวลา';

  @override
  String get statusDraft => 'ฉบับร่าง';

  @override
  String get statusAssigned => 'มอบหมายแล้ว';

  @override
  String get statusInProgress => 'กำลังดำเนินการ';

  @override
  String get statusDone => 'เสร็จสิ้น';

  @override
  String get statusCancelled => 'ยกเลิก';

  @override
  String get settingsTitle => 'การตั้งค่าแอป';

  @override
  String get settingsAppearance => 'ลักษณะ';

  @override
  String get settingsTheme => 'ธีม';

  @override
  String get settingsThemeLight => 'สว่าง';

  @override
  String get settingsThemeDark => 'มืด';

  @override
  String get settingsThemeSystem => 'ตามระบบ';

  @override
  String get settingsAccentColor => 'สีเน้น';

  @override
  String get settingsAccentColorPick => 'เลือกสี';

  @override
  String get settingsAccentColorDialogTitle => 'เลือกสี';

  @override
  String get settingsLanguageSection => 'ภาษาและข้อความ';

  @override
  String get settingsLanguageLabel => 'ภาษา';

  @override
  String get settingsAboutSection => 'เกี่ยวกับแอป';

  @override
  String get settingsVersionLabel => 'เวอร์ชัน';

  @override
  String get languageEnglish => 'อังกฤษ';

  @override
  String get languageArabic => 'อาหรับ';

  @override
  String get navJobs => 'งาน';

  @override
  String get navCalendar => 'ปฏิทิน';

  @override
  String get navMap => 'แผนที่';

  @override
  String get navProfile => 'โปรไฟล์';

  @override
  String get profileSectionSettingsAndMore => 'การตั้งค่าและอื่น ๆ';

  @override
  String get profileSettingsTitle => 'การตั้งค่า';

  @override
  String get profileSettingsSubtitle => 'การตั้งค่าแอปและธีม';

  @override
  String get profileLogoutTitle => 'ออกจากระบบ';

  @override
  String get profileLogoutSubtitle => 'ออกจากบัญชีของคุณ';

  @override
  String get profileLoggedIn => 'เข้าสู่ระบบแล้ว';

  @override
  String get jobDetailSchedule => 'ตารางงาน';

  @override
  String get jobDetailStart => 'เริ่มต้น';

  @override
  String get jobDetailEnd => 'สิ้นสุด';

  @override
  String get jobDetailDuration => 'ระยะเวลา';

  @override
  String get jobDetailLocation => 'ตำแหน่ง';

  @override
  String get jobDetailLatShort => 'ละติจูด';

  @override
  String get jobDetailLngShort => 'ลองจิจูด';

  @override
  String get jobDetailOpenInMaps => 'เปิดใน Maps';

  @override
  String get jobDetailNotes => 'บันทึก';

  @override
  String get jobDetailCustomerNotes => 'บันทึกของลูกค้า';

  @override
  String get jobDetailInternalNotes => 'บันทึกภายใน';

  @override
  String get jobDetailPhotos => 'รูปภาพ';

  @override
  String get jobDetailAddPhotos => 'เพิ่มรูปภาพ';

  @override
  String get jobDetailPhotosHint => 'แตะที่ใดก็ได้บนการ์ดนี้หรือใช้ปุ่มเพื่อเพิ่มรูปภาพจากกล้องหรือแกลเลอรี';

  @override
  String get jobDetailTakePhotoCamera => 'ถ่ายรูป (กล้อง)';

  @override
  String get jobDetailChooseFromGallery => 'เลือกจากแกลเลอรี';

  @override
  String get jobDetailAuth => 'การยืนยัน';

  @override
  String get jobDetailAuthTooltip => 'เปิดหน้าการยืนยัน';

  @override
  String get jobDetailAuthHint => 'แตะที่การ์ดนี้เพื่อบันทึกลายเซ็นยืนยันของลูกค้า';

  @override
  String get jobDetailAuthSavedSignature => 'บันทึกลายเซ็นแล้ว';

  @override
  String get jobDetailNoCustomer => 'ไม่มีลูกค้า';

  @override
  String get jobDetailUnassigned => 'ยังไม่มอบหมาย';

  @override
  String get jobDetailStartButton => 'เริ่มงาน';

  @override
  String get jobDetailMarkDone => 'ทำเครื่องหมายว่าเสร็จสิ้น';

  @override
  String get jobDetailAssign => 'มอบหมาย';

  @override
  String get jobDetailUpdateFailed => 'อัปเดตงานไม่สำเร็จ';

  @override
  String get locationServicesDisabled => 'บริการระบุตำแหน่งถูกปิดใช้งาน';

  @override
  String get locationPermissionDenied => 'ปฏิเสธการอนุญาตตำแหน่งที่ตั้ง';

  @override
  String get jobDetailStartFailed => 'เริ่มงานไม่สำเร็จ';

  @override
  String get jobDetailNoLocationData => 'ไม่มีข้อมูล GPS หรือที่อยู่สำหรับงานนี้';

  @override
  String get jobDetailNoAddress => 'ไม่มีที่อยู่สำหรับงานนี้';

  @override
  String get jobDetailMapOpenFailed => 'ไม่สามารถเปิดแอปแผนที่ได้';

  @override
  String get jobDetailMapError => 'เปิดแผนที่ไม่สำเร็จ';

  @override
  String get jobDetailPhotosUploaded => 'อัปโหลดรูปภาพแล้ว';

  @override
  String get jobDetailPhotosUploadFailed => 'อัปโหลดรูปภาพไม่สำเร็จ';

  @override
  String get authSaved => 'บันทึกการยืนยันแล้ว';

  @override
  String get authSaveFailed => 'บันทึกลายเซ็นไม่สำเร็จ';

  @override
  String get authSignInstruction => 'โปรดให้ลูกค้าเซ็นภายในกรอบด้านล่าง';

  @override
  String get photoViewerTitle => 'รูปภาพ';

  @override
  String get commonRefresh => 'รีเฟรช';

  @override
  String get commonClear => 'ล้าง';

  @override
  String get commonCancel => 'ยกเลิก';

  @override
  String get commonSave => 'บันทึก';

  @override
  String get addJobTitle => 'งานใหม่';

  @override
  String get addJobJobTitleLabel => 'ชื่องาน';

  @override
  String get addJobJobTitleHint => 'เช่น ซ่อมบำรุงแอร์ – วิลลา 12B';

  @override
  String get addJobJobTitleRequired => 'กรุณากรอกชื่องาน';

  @override
  String get addJobScheduledLabel => 'วันที่และเวลาที่กำหนด';

  @override
  String get addJobDateTimeNotSet => 'ยังไม่ได้ตั้งค่า';

  @override
  String get addJobCustomerNotesLabel => 'บันทึกของลูกค้า (ไม่บังคับ)';

  @override
  String get addJobCustomerNotesHint => 'บันทึกจากลูกค้า ข้อมูลการเข้าอาคาร ฯลฯ';

  @override
  String get addJobInternalNotesLabel => 'บันทึกภายใน (ไม่บังคับ)';

  @override
  String get addJobInternalNotesHint => 'บันทึกสำหรับทีมของคุณเท่านั้น';

  @override
  String get addJobCreateButton => 'สร้างงาน';

  @override
  String get addJobCreated => 'สร้างงานแล้ว';

  @override
  String get addJobCreateFailed => 'สร้างงานไม่สำเร็จ';

  @override
  String get calendarRefreshTooltip => 'รีเฟรชงาน';

  @override
  String get calendarJobsOnPrefix => 'งานวันที่';

  @override
  String get calendarNoJobsOnDay => 'ไม่มีงานในวันนั้น';

  @override
  String get mapTitle => 'แผนที่งาน';

  @override
  String get mapEmptyTitle => 'ไม่มีงานที่จะแสดงบนแผนที่';

  @override
  String get mapBottomTitle => 'งานบนแผนที่';

  @override
  String get mapJobsLabel => 'งาน';

  @override
  String get myJobsTitle => 'งานของฉัน';

  @override
  String get mapYouAreHere => 'คุณอยู่ที่นี่';

  @override
  String get loginWelcomeBack => 'ยินดีต้อนรับกลับ';

  @override
  String get loginSubtitle => 'ลงชื่อเข้าใช้เพื่อจัดการงานบริการภาคสนามของคุณ。';

  @override
  String get loginDetailsTitle => 'ข้อมูลเข้าสู่ระบบ';

  @override
  String get loginEmailLabel => 'อีเมล / ชื่อผู้ใช้';

  @override
  String get loginPasswordLabel => 'รหัสผ่าน';

  @override
  String get loginButton => 'เข้าสู่ระบบ';

  @override
  String get loginError => 'เข้าสู่ระบบไม่สำเร็จ โปรดตรวจสอบข้อมูลและเซิร์ฟเวอร์';

  @override
  String get validationRequired => 'จำเป็น';

  @override
  String get loginConnectedServer => 'เซิร์ฟเวอร์ที่เชื่อมต่อ';

  @override
  String get loginNoServerConfigured => 'ยังไม่ได้กำหนดค่าเซิร์ฟเวอร์';

  @override
  String loginServerDb(String dbName) {
    return 'ฐานข้อมูล: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'ฐานข้อมูล: -';

  @override
  String get loginChangeServer => 'เปลี่ยนเซิร์ฟเวอร์';

  @override
  String get loginPoweredBy => 'ขับเคลื่อนโดย Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'ระบุให้แอปทราบว่าจะใช้เซิร์ฟเวอร์และฐานข้อมูล Odoo ใด';

  @override
  String get serverConfigSectionConnectionDetails => 'รายละเอียดการเชื่อมต่อ';

  @override
  String get serverConfigServerUrlLabel => 'URL ของเซิร์ฟเวอร์';

  @override
  String get serverConfigServerUrlHint => 'https://your-odoo-domain.com';

  @override
  String get serverConfigDbNameLabel => 'ชื่อฐานข้อมูล';

  @override
  String get serverConfigSaveButton => 'บันทึกและดำเนินการต่อ';

  @override
  String get serverConfigSaveHint => 'คุณสามารถเปลี่ยนสิ่งนี้ได้ตลอดเวลาจากหน้าล็อกอิน';

  @override
  String get serverConfigDbAutoDetectError => 'ไม่สามารถตรวจหาฐานข้อมูลอัตโนมัติ โปรดตรวจสอบ URL';

  @override
  String get attendanceDetailsTitle => 'Devam detayları';

  @override
  String get employeeLabel => 'Çalışan';

  @override
  String get statusOpen => 'AÇIK';

  @override
  String get statusClosed => 'KAPALI';

  @override
  String get workedTimeLabel => 'Çalışılan süre';

  @override
  String get extraHoursLabel => 'Fazla mesai';

  @override
  String get checkInTitle => 'GİRİŞ';

  @override
  String get checkOutTitle => 'ÇIKIŞ';

  @override
  String get ipAddressLabel => 'IP adresi';

  @override
  String get gpsCoordinatesLabel => 'GPS koordinatları';

  @override
  String get unknownValue => 'Bilinmiyor';

  @override
  String get notAvailableValue => 'Mevcut değil';

  @override
  String get viewOnMaps => 'Haritada görüntüle';

  @override
  String get notCheckedOutYet => 'Henüz çıkış yapılmadı';

  @override
  String hoursValue(String hours) {
    return '$hours saat';
  }

  @override
  String get attendanceOnDuty => 'กำลังปฏิบัติงาน';

  @override
  String get attendanceOffDuty => 'นอกเวลางาน';

  @override
  String get attendanceSwipeToCheckIn => 'ปัดเพื่อเช็คอิน';

  @override
  String get attendanceSwipeToCheckOut => 'ปัดเพื่อเช็คเอาท์';

  @override
  String get attendanceCurrentLocation => 'ตำแหน่งปัจจุบัน';

  @override
  String get attendanceRefresh => 'รีเฟรช';

  @override
  String get attendanceFetchingAddress => 'กำลังดึงที่อยู่...';

  @override
  String get attendanceWaitingForGps => 'กำลังรอ GPS...';

  @override
  String get attendanceUploadSelfie => 'อัปโหลดเซลฟี่';

  @override
  String get attendanceLocationRequired => 'ต้องใช้ตำแหน่งเพื่อดำเนินการต่อ';

  @override
  String get attendanceCheckInSuccess => 'ยินดีต้อนรับ! บันทึกเช็คอินแล้ว';

  @override
  String get attendanceCheckOutSuccess => 'สิ้นสุดกะงานแล้ว ทำได้ดีมาก!';

  @override
  String get attendanceCheckInFirst => 'กรุณาเช็คอินก่อน';

  @override
  String get attendanceSelfieUploaded => 'อัปโหลดเซลฟี่แล้ว';

  @override
  String get attendanceUploadFailed => 'อัปโหลดไม่สำเร็จ';

  @override
  String get attendanceCameraError => 'ข้อผิดพลาดของกล้อง';

  @override
  String attendanceStartedAt(String time) {
    return 'เริ่มเวลา $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'ละติจูด: $lat, ลองจิจูด: $lng';
  }

  @override
  String get attendanceReadyToStart => 'พร้อมเริ่มกะงาน';

  @override
  String get attendanceTitle => 'การเข้างาน';

  @override
  String get attNavAttendance => 'การเข้างาน';

  @override
  String get attNavHistory => 'ประวัติ';

  @override
  String get attFiltersTitle => 'ตัวกรองการเข้างาน';

  @override
  String get attDateRangeLabel => 'ช่วงวันที่';

  @override
  String get attStatusLabel => 'สถานะ';

  @override
  String get attFilterTooltip => 'กรอง';

  @override
  String get attClearFilters => 'ล้างตัวกรอง';

  @override
  String get attApplyFilters => 'ใช้ตัวกรอง';

  @override
  String get attFilterStatusAll => 'ทุกสถานะ';

  @override
  String get attFilterStatusOpen => 'เปิด (เช็คอิน)';

  @override
  String get attFilterStatusClosed => 'ปิด (เช็คเอาท์)';

  @override
  String get attFilterRangeToday => 'วันนี้';

  @override
  String get attFilterRangeWeek => 'สัปดาห์นี้';

  @override
  String get attFilterRangeMonth => 'เดือนนี้';

  @override
  String get attFilterRangeAll => 'ทั้งหมด';

  @override
  String attFilterDescription(String status, String range) {
    return '$status สำหรับ $range';
  }

  @override
  String get attLoadingAttendance => 'กำลังโหลดการเข้างาน…';

  @override
  String get attLoadingMore => 'กำลังโหลดเพิ่ม…';

  @override
  String get attFailedToLoad => 'โหลดไม่สำเร็จ';

  @override
  String get attFailedToLoadMore => 'โหลดเพิ่มไม่สำเร็จ';

  @override
  String get attTryAgain => 'ลองอีกครั้ง';

  @override
  String get attNoAttendanceTitle => 'ไม่พบข้อมูลการเข้างาน';

  @override
  String get attNoAttendanceSubtitle => 'ลองปรับตัวกรอง (ช่วงวันที่หรือสถานะ)';

  @override
  String get attNoMoreItems => 'คุณมาถึงท้ายรายการแล้ว';

  @override
  String employeeFallback(String id) {
    return 'พนักงาน #$id';
  }

  @override
  String get attDetailsTitle => 'รายละเอียดการเข้างาน';

  @override
  String get attEmployeeLabel => 'พนักงาน';

  @override
  String get attWorkedTimeLabel => 'เวลาทำงาน';

  @override
  String get attExtraHoursLabel => 'ชั่วโมงล่วงเวลา';

  @override
  String get attCheckInSection => 'เช็คอิน';

  @override
  String get attCheckOutSection => 'เช็คเอาต์';

  @override
  String get attIpAddressLabel => 'ที่อยู่ IP';

  @override
  String get attGpsCoordinatesLabel => 'พิกัด GPS';

  @override
  String get attViewOnMaps => 'ดูบนแผนที่';

  @override
  String get attUnknownValue => 'ไม่ทราบ';

  @override
  String get attNotAvailableValue => 'ไม่พร้อมใช้งาน';

  @override
  String get attNotCheckedOutYet => 'ยังไม่ได้เช็คเอาต์';

  @override
  String get attZeroHours => '0.00 ชม.';
}
