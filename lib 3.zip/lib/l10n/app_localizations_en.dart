// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get configureOdooServer => 'Configure Odoo Server';

  @override
  String get jobs => 'Jobs';

  @override
  String get searchJobsHint => 'Search jobs...';

  @override
  String get sortBy => 'Sort by';

  @override
  String get sortScheduledNearest => 'Scheduled (nearest first)';

  @override
  String get sortScheduledFarthest => 'Scheduled (farthest first)';

  @override
  String get sortCustomerAZ => 'Customer (A-Z)';

  @override
  String get sortStatus => 'Status';

  @override
  String get tabAssigned => 'Assigned';

  @override
  String get tabInProgress => 'In progress';

  @override
  String get tabDone => 'Done';

  @override
  String get tabAll => 'All';

  @override
  String get emptyJobsTitle => 'No jobs';

  @override
  String get emptyJobsSubtitle => 'Try changing search or filters';

  @override
  String get emptyJobsAddButton => 'Add new job';

  @override
  String get noSchedule => 'No schedule';

  @override
  String get statusDraft => 'Draft';

  @override
  String get statusAssigned => 'Assigned';

  @override
  String get statusInProgress => 'In progress';

  @override
  String get statusDone => 'Done';

  @override
  String get statusCancelled => 'Cancelled';

  @override
  String get settingsTitle => 'App settings';

  @override
  String get settingsAppearance => 'Appearance';

  @override
  String get settingsTheme => 'Theme';

  @override
  String get settingsThemeLight => 'Light';

  @override
  String get settingsThemeDark => 'Dark';

  @override
  String get settingsThemeSystem => 'System';

  @override
  String get settingsAccentColor => 'Accent color';

  @override
  String get settingsAccentColorPick => 'Pick color';

  @override
  String get settingsAccentColorDialogTitle => 'Choose a color';

  @override
  String get settingsLanguageSection => 'Language & text';

  @override
  String get settingsLanguageLabel => 'Language';

  @override
  String get settingsAboutSection => 'About the app';

  @override
  String get settingsVersionLabel => 'Version';

  @override
  String get languageEnglish => 'English';

  @override
  String get languageArabic => 'Arabic';

  @override
  String get navJobs => 'Jobs';

  @override
  String get navCalendar => 'Calendar';

  @override
  String get navMap => 'Map';

  @override
  String get navProfile => 'Profile';

  @override
  String get profileSectionSettingsAndMore => 'Settings & more';

  @override
  String get profileSettingsTitle => 'Settings';

  @override
  String get profileSettingsSubtitle => 'App and theme settings';

  @override
  String get profileLogoutTitle => 'Logout';

  @override
  String get profileLogoutSubtitle => 'Sign out of your account';

  @override
  String get profileLoggedIn => 'Logged in';

  @override
  String get jobDetailSchedule => 'Schedule';

  @override
  String get jobDetailStart => 'Start';

  @override
  String get jobDetailEnd => 'End';

  @override
  String get jobDetailDuration => 'Duration';

  @override
  String get jobDetailLocation => 'Location';

  @override
  String get jobDetailLatShort => 'Lat';

  @override
  String get jobDetailLngShort => 'Lng';

  @override
  String get jobDetailOpenInMaps => 'Open in Maps';

  @override
  String get jobDetailNotes => 'Notes';

  @override
  String get jobDetailCustomerNotes => 'Customer notes';

  @override
  String get jobDetailInternalNotes => 'Internal notes';

  @override
  String get jobDetailPhotos => 'Photos';

  @override
  String get jobDetailAddPhotos => 'Add photos';

  @override
  String get jobDetailPhotosHint => 'Tap anywhere on this card or use the button to attach photos from camera or gallery.';

  @override
  String get jobDetailTakePhotoCamera => 'Take photo (camera)';

  @override
  String get jobDetailChooseFromGallery => 'Choose from gallery';

  @override
  String get jobDetailAuth => 'Authentication';

  @override
  String get jobDetailAuthTooltip => 'Open authentication';

  @override
  String get jobDetailAuthHint => 'Tap on this card to capture customer authentication (signature).';

  @override
  String get jobDetailAuthSavedSignature => 'Saved signature';

  @override
  String get jobDetailNoCustomer => 'No customer';

  @override
  String get jobDetailUnassigned => 'Unassigned';

  @override
  String get jobDetailStartButton => 'Start';

  @override
  String get jobDetailMarkDone => 'Mark done';

  @override
  String get jobDetailAssign => 'Assign';

  @override
  String get jobDetailUpdateFailed => 'Failed to update job';

  @override
  String get locationServicesDisabled => 'Location services are disabled';

  @override
  String get locationPermissionDenied => 'Location permission denied';

  @override
  String get jobDetailStartFailed => 'Failed to start job';

  @override
  String get jobDetailNoLocationData => 'No GPS or address available for this job';

  @override
  String get jobDetailNoAddress => 'No address available for this job';

  @override
  String get jobDetailMapOpenFailed => 'Could not open map app';

  @override
  String get jobDetailMapError => 'Failed to open maps';

  @override
  String get jobDetailPhotosUploaded => 'photo(s) uploaded';

  @override
  String get jobDetailPhotosUploadFailed => 'Failed to upload photos';

  @override
  String get authSaved => 'Authentication saved';

  @override
  String get authSaveFailed => 'Failed to save signature';

  @override
  String get authSignInstruction => 'Ask the customer to sign inside the box below.';

  @override
  String get photoViewerTitle => 'Photo';

  @override
  String get commonRefresh => 'Refresh';

  @override
  String get commonClear => 'Clear';

  @override
  String get commonCancel => 'Cancel';

  @override
  String get commonSave => 'Save';

  @override
  String get addJobTitle => 'New job';

  @override
  String get addJobJobTitleLabel => 'Job title';

  @override
  String get addJobJobTitleHint => 'Ex: AC Maintenance – Villa 12B';

  @override
  String get addJobJobTitleRequired => 'Please enter job title';

  @override
  String get addJobScheduledLabel => 'Scheduled date & time';

  @override
  String get addJobDateTimeNotSet => 'Not set';

  @override
  String get addJobCustomerNotesLabel => 'Customer notes (optional)';

  @override
  String get addJobCustomerNotesHint => 'Notes from customer, access info, etc.';

  @override
  String get addJobInternalNotesLabel => 'Internal notes (optional)';

  @override
  String get addJobInternalNotesHint => 'Notes for your team only';

  @override
  String get addJobCreateButton => 'Create job';

  @override
  String get addJobCreated => 'Job created';

  @override
  String get addJobCreateFailed => 'Failed to create job';

  @override
  String get calendarRefreshTooltip => 'Refresh jobs';

  @override
  String get calendarJobsOnPrefix => 'Jobs on';

  @override
  String get calendarNoJobsOnDay => 'No jobs on this day';

  @override
  String get mapTitle => 'Jobs map';

  @override
  String get mapEmptyTitle => 'No jobs to show on map';

  @override
  String get mapBottomTitle => 'Jobs on map';

  @override
  String get mapJobsLabel => 'jobs';

  @override
  String get myJobsTitle => 'My jobs';

  @override
  String get mapYouAreHere => 'You are here';

  @override
  String get loginWelcomeBack => 'Welcome back';

  @override
  String get loginSubtitle => 'Sign in to manage your field service jobs.';

  @override
  String get loginDetailsTitle => 'Login details';

  @override
  String get loginEmailLabel => 'Email / Login';

  @override
  String get loginPasswordLabel => 'Password';

  @override
  String get loginButton => 'Login';

  @override
  String get loginError => 'Login failed. Check credentials and server.';

  @override
  String get validationRequired => 'Required';

  @override
  String get loginConnectedServer => 'Connected server';

  @override
  String get loginNoServerConfigured => 'No server configured yet';

  @override
  String loginServerDb(String dbName) {
    return 'DB: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'DB: -';

  @override
  String get loginChangeServer => 'Change server';

  @override
  String get loginPoweredBy => 'Powered by Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Tell the app which Odoo server and database to use.';

  @override
  String get serverConfigSectionConnectionDetails => 'Connection details';

  @override
  String get serverConfigServerUrlLabel => 'Server URL';

  @override
  String get serverConfigServerUrlHint => 'https://your-odoo-domain.com';

  @override
  String get serverConfigDbNameLabel => 'Database name';

  @override
  String get serverConfigSaveButton => 'Save and continue';

  @override
  String get serverConfigSaveHint => 'You can always change this later from the login screen.';

  @override
  String get serverConfigDbAutoDetectError => 'Could not auto-detect database. Please check URL.';

  @override
  String get attendanceDetailsTitle => 'Attendance Details';

  @override
  String get employeeLabel => 'Employee';

  @override
  String get statusOpen => 'OPEN';

  @override
  String get statusClosed => 'CLOSED';

  @override
  String get workedTimeLabel => 'Worked Time';

  @override
  String get extraHoursLabel => 'Extra Hours';

  @override
  String get checkInTitle => 'CHECK IN';

  @override
  String get checkOutTitle => 'CHECK OUT';

  @override
  String get ipAddressLabel => 'IP Address';

  @override
  String get gpsCoordinatesLabel => 'GPS Coordinates';

  @override
  String get unknownValue => 'Unknown';

  @override
  String get notAvailableValue => 'Not available';

  @override
  String get viewOnMaps => 'View on Maps';

  @override
  String get notCheckedOutYet => 'Not Checked Out Yet';

  @override
  String hoursValue(String hours) {
    return '$hours hrs';
  }

  @override
  String get attendanceOnDuty => 'On Duty';

  @override
  String get attendanceOffDuty => 'Off Duty';

  @override
  String get attendanceSwipeToCheckIn => 'Swipe to Check In';

  @override
  String get attendanceSwipeToCheckOut => 'Swipe to Check Out';

  @override
  String get attendanceCurrentLocation => 'Current Location';

  @override
  String get attendanceRefresh => 'REFRESH';

  @override
  String get attendanceFetchingAddress => 'Fetching address...';

  @override
  String get attendanceWaitingForGps => 'Waiting for GPS...';

  @override
  String get attendanceUploadSelfie => 'Upload Selfie';

  @override
  String get attendanceLocationRequired => 'Location required to proceed.';

  @override
  String get attendanceCheckInSuccess => 'Welcome! Check-in recorded.';

  @override
  String get attendanceCheckOutSuccess => 'Shift ended. Good job!';

  @override
  String get attendanceCheckInFirst => 'Please check in first.';

  @override
  String get attendanceSelfieUploaded => 'Selfie uploaded';

  @override
  String get attendanceUploadFailed => 'Upload failed';

  @override
  String get attendanceCameraError => 'Camera error';

  @override
  String attendanceStartedAt(String time) {
    return 'Started at $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Lat: $lat, Lng: $lng';
  }

  @override
  String get attendanceReadyToStart => 'Ready to start shift';

  @override
  String get attendanceTitle => 'Attendance';

  @override
  String get attNavAttendance => 'Attendance';

  @override
  String get attNavHistory => 'History';

  @override
  String get attFiltersTitle => 'Attendance Filters';

  @override
  String get attDateRangeLabel => 'Date Range';

  @override
  String get attStatusLabel => 'Status';

  @override
  String get attFilterTooltip => 'Filter';

  @override
  String get attClearFilters => 'Clear Filters';

  @override
  String get attApplyFilters => 'Apply Filters';

  @override
  String get attFilterStatusAll => 'All Statuses';

  @override
  String get attFilterStatusOpen => 'Open (Checked in)';

  @override
  String get attFilterStatusClosed => 'Closed (Checked out)';

  @override
  String get attFilterRangeToday => 'Today';

  @override
  String get attFilterRangeWeek => 'This week';

  @override
  String get attFilterRangeMonth => 'This month';

  @override
  String get attFilterRangeAll => 'All time';

  @override
  String attFilterDescription(String status, String range) {
    return '$status for $range';
  }

  @override
  String get attLoadingAttendance => 'Loading attendance…';

  @override
  String get attLoadingMore => 'Loading more…';

  @override
  String get attFailedToLoad => 'Failed to load attendance';

  @override
  String get attFailedToLoadMore => 'Failed to load more';

  @override
  String get attTryAgain => 'Try again';

  @override
  String get attNoAttendanceTitle => 'No attendance found';

  @override
  String get attNoAttendanceSubtitle => 'Try adjusting your filters (date range or status).';

  @override
  String get attNoMoreItems => 'You\'ve reached the end of the list.';

  @override
  String employeeFallback(String id) {
    return 'Employee #$id';
  }

  @override
  String get attDetailsTitle => 'Attendance Details';

  @override
  String get attEmployeeLabel => 'Employee';

  @override
  String get attWorkedTimeLabel => 'Worked Time';

  @override
  String get attExtraHoursLabel => 'Extra Hours';

  @override
  String get attCheckInSection => 'CHECK IN';

  @override
  String get attCheckOutSection => 'CHECK OUT';

  @override
  String get attIpAddressLabel => 'IP Address';

  @override
  String get attGpsCoordinatesLabel => 'GPS Coordinates';

  @override
  String get attViewOnMaps => 'View on Maps';

  @override
  String get attUnknownValue => 'Unknown';

  @override
  String get attNotAvailableValue => 'Not available';

  @override
  String get attNotCheckedOutYet => 'Not Checked Out Yet';

  @override
  String get attZeroHours => '0.00 hrs';
}
