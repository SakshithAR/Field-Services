// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Hindi (`hi`).
class AppLocalizationsHi extends AppLocalizations {
  AppLocalizationsHi([String locale = 'hi']) : super(locale);

  @override
  String get configureOdooServer => 'Odoo सर्वर कॉन्फ़िगर करें';

  @override
  String get jobs => 'जॉब्स';

  @override
  String get searchJobsHint => 'जॉब्स खोजें...';

  @override
  String get sortBy => 'इसके अनुसार क्रम';

  @override
  String get sortScheduledNearest => 'शेड्यूल (सबसे नज़दीक पहले)';

  @override
  String get sortScheduledFarthest => 'शेड्यूल (सबसे दूर पहले)';

  @override
  String get sortCustomerAZ => 'ग्राहक (A-Z)';

  @override
  String get sortStatus => 'स्थिति';

  @override
  String get tabAssigned => 'असाइन की गई';

  @override
  String get tabInProgress => 'प्रगति में';

  @override
  String get tabDone => 'पूर्ण';

  @override
  String get tabAll => 'सभी';

  @override
  String get emptyJobsTitle => 'कोई जॉब नहीं';

  @override
  String get emptyJobsSubtitle => 'सर्च या फ़िल्टर बदलकर देखें';

  @override
  String get emptyJobsAddButton => 'नई जॉब जोड़ें';

  @override
  String get noSchedule => 'कोई शेड्यूल नहीं';

  @override
  String get statusDraft => 'ड्राफ्ट';

  @override
  String get statusAssigned => 'असाइन की गई';

  @override
  String get statusInProgress => 'प्रगति में';

  @override
  String get statusDone => 'पूर्ण';

  @override
  String get statusCancelled => 'रद्द';

  @override
  String get settingsTitle => 'ऐप सेटिंग्स';

  @override
  String get settingsAppearance => 'दिखावट';

  @override
  String get settingsTheme => 'थीम';

  @override
  String get settingsThemeLight => 'लाइट';

  @override
  String get settingsThemeDark => 'डार्क';

  @override
  String get settingsThemeSystem => 'सिस्टम';

  @override
  String get settingsAccentColor => 'एक्सेंट रंग';

  @override
  String get settingsAccentColorPick => 'रंग चुनें';

  @override
  String get settingsAccentColorDialogTitle => 'रंग चुनें';

  @override
  String get settingsLanguageSection => 'भाषा और टेक्स्ट';

  @override
  String get settingsLanguageLabel => 'भाषा';

  @override
  String get settingsAboutSection => 'ऐप के बारे में';

  @override
  String get settingsVersionLabel => 'वर्ज़न';

  @override
  String get languageEnglish => 'अंग्रेज़ी';

  @override
  String get languageArabic => 'अरबी';

  @override
  String get navJobs => 'जॉब्स';

  @override
  String get navCalendar => 'कैलेंडर';

  @override
  String get navMap => 'मैप';

  @override
  String get navProfile => 'प्रोफ़ाइल';

  @override
  String get profileSectionSettingsAndMore => 'सेटिंग्स और अन्य';

  @override
  String get profileSettingsTitle => 'सेटिंग्स';

  @override
  String get profileSettingsSubtitle => 'ऐप और थीम सेटिंग्स';

  @override
  String get profileLogoutTitle => 'लॉगआउट';

  @override
  String get profileLogoutSubtitle => 'अपने अकाउंट से साइन आउट करें';

  @override
  String get profileLoggedIn => 'लॉग इन';

  @override
  String get jobDetailSchedule => 'शेड्यूल';

  @override
  String get jobDetailStart => 'शुरू';

  @override
  String get jobDetailEnd => 'समाप्त';

  @override
  String get jobDetailDuration => 'अवधि';

  @override
  String get jobDetailLocation => 'लोकेशन';

  @override
  String get jobDetailLatShort => 'Lat';

  @override
  String get jobDetailLngShort => 'Lng';

  @override
  String get jobDetailOpenInMaps => 'मैप्स में खोलें';

  @override
  String get jobDetailNotes => 'नोट्स';

  @override
  String get jobDetailCustomerNotes => 'ग्राहक नोट्स';

  @override
  String get jobDetailInternalNotes => 'आंतरिक नोट्स';

  @override
  String get jobDetailPhotos => 'फ़ोटो';

  @override
  String get jobDetailAddPhotos => 'फ़ोटो जोड़ें';

  @override
  String get jobDetailPhotosHint => 'इस कार्ड पर कहीं भी टैप करें या बटन का उपयोग करके कैमरा/गैलरी से फ़ोटो जोड़ें।';

  @override
  String get jobDetailTakePhotoCamera => 'फ़ोटो लें (कैमरा)';

  @override
  String get jobDetailChooseFromGallery => 'गैलरी से चुनें';

  @override
  String get jobDetailAuth => 'ऑथेंटिकेशन';

  @override
  String get jobDetailAuthTooltip => 'ऑथेंटिकेशन खोलें';

  @override
  String get jobDetailAuthHint => 'ग्राहक ऑथेंटिकेशन (सिग्नेचर) लेने के लिए इस कार्ड पर टैप करें।';

  @override
  String get jobDetailAuthSavedSignature => 'सेव किया हुआ सिग्नेचर';

  @override
  String get jobDetailNoCustomer => 'कोई ग्राहक नहीं';

  @override
  String get jobDetailUnassigned => 'असाइन नहीं';

  @override
  String get jobDetailStartButton => 'शुरू करें';

  @override
  String get jobDetailMarkDone => 'पूर्ण मार्क करें';

  @override
  String get jobDetailAssign => 'असाइन करें';

  @override
  String get jobDetailUpdateFailed => 'जॉब अपडेट नहीं हो पाई';

  @override
  String get locationServicesDisabled => 'लोकेशन सेवाएं बंद हैं';

  @override
  String get locationPermissionDenied => 'लोकेशन अनुमति अस्वीकृत';

  @override
  String get jobDetailStartFailed => 'जॉब शुरू नहीं हो पाई';

  @override
  String get jobDetailNoLocationData => 'इस जॉब के लिए GPS या पता उपलब्ध नहीं है';

  @override
  String get jobDetailNoAddress => 'इस जॉब के लिए पता उपलब्ध नहीं है';

  @override
  String get jobDetailMapOpenFailed => 'मैप ऐप नहीं खुल सका';

  @override
  String get jobDetailMapError => 'मैप्स खोलने में विफल';

  @override
  String get jobDetailPhotosUploaded => 'फ़ोटो अपलोड हुईं';

  @override
  String get jobDetailPhotosUploadFailed => 'फ़ोटो अपलोड विफल';

  @override
  String get authSaved => 'ऑथेंटिकेशन सेव हो गया';

  @override
  String get authSaveFailed => 'सिग्नेचर सेव नहीं हो सका';

  @override
  String get authSignInstruction => 'ग्राहक से नीचे दिए बॉक्स में साइन करवाएं।';

  @override
  String get photoViewerTitle => 'फ़ोटो';

  @override
  String get commonRefresh => 'रीफ़्रेश';

  @override
  String get commonClear => 'क्लियर';

  @override
  String get commonCancel => 'कैंसल';

  @override
  String get commonSave => 'सेव';

  @override
  String get addJobTitle => 'नई जॉब';

  @override
  String get addJobJobTitleLabel => 'जॉब शीर्षक';

  @override
  String get addJobJobTitleHint => 'उदा: AC मेंटेनेंस – विला 12B';

  @override
  String get addJobJobTitleRequired => 'कृपया जॉब शीर्षक दर्ज करें';

  @override
  String get addJobScheduledLabel => 'शेड्यूल तारीख और समय';

  @override
  String get addJobDateTimeNotSet => 'सेट नहीं';

  @override
  String get addJobCustomerNotesLabel => 'ग्राहक नोट्स (वैकल्पिक)';

  @override
  String get addJobCustomerNotesHint => 'ग्राहक के नोट्स, एक्सेस जानकारी आदि';

  @override
  String get addJobInternalNotesLabel => 'आंतरिक नोट्स (वैकल्पिक)';

  @override
  String get addJobInternalNotesHint => 'केवल आपकी टीम के लिए';

  @override
  String get addJobCreateButton => 'जॉब बनाएं';

  @override
  String get addJobCreated => 'जॉब बन गई';

  @override
  String get addJobCreateFailed => 'जॉब बनाना विफल';

  @override
  String get calendarRefreshTooltip => 'जॉब्स रीफ़्रेश करें';

  @override
  String get calendarJobsOnPrefix => 'इस तारीख पर जॉब्स';

  @override
  String get calendarNoJobsOnDay => 'इस दिन कोई जॉब नहीं';

  @override
  String get mapTitle => 'जॉब्स मैप';

  @override
  String get mapEmptyTitle => 'मैप पर दिखाने के लिए कोई जॉब नहीं';

  @override
  String get mapBottomTitle => 'मैप पर जॉब्स';

  @override
  String get mapJobsLabel => 'जॉब्स';

  @override
  String get myJobsTitle => 'मेरी जॉब्स';

  @override
  String get mapYouAreHere => 'आप यहाँ हैं';

  @override
  String get loginWelcomeBack => 'वापसी पर स्वागत है';

  @override
  String get loginSubtitle => 'अपने फील्ड सर्विस जॉब्स मैनेज करने के लिए साइन इन करें।';

  @override
  String get loginDetailsTitle => 'लॉगिन विवरण';

  @override
  String get loginEmailLabel => 'ईमेल / लॉगिन';

  @override
  String get loginPasswordLabel => 'पासवर्ड';

  @override
  String get loginButton => 'लॉगिन';

  @override
  String get loginError => 'लॉगिन विफल। क्रेडेंशियल्स और सर्वर जांचें।';

  @override
  String get validationRequired => 'आवश्यक';

  @override
  String get loginConnectedServer => 'कनेक्टेड सर्वर';

  @override
  String get loginNoServerConfigured => 'अभी कोई सर्वर कॉन्फ़िगर नहीं है';

  @override
  String loginServerDb(String dbName) {
    return 'DB: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'DB: -';

  @override
  String get loginChangeServer => 'सर्वर बदलें';

  @override
  String get loginPoweredBy => 'Powered by Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'ऐप को बताएं कि कौन सा Odoo सर्वर और डेटाबेस उपयोग करना है।';

  @override
  String get serverConfigSectionConnectionDetails => 'कनेक्शन विवरण';

  @override
  String get serverConfigServerUrlLabel => 'सर्वर URL';

  @override
  String get serverConfigServerUrlHint => 'https://your-odoo-domain.com';

  @override
  String get serverConfigDbNameLabel => 'डेटाबेस नाम';

  @override
  String get serverConfigSaveButton => 'सेव करें और आगे बढ़ें';

  @override
  String get serverConfigSaveHint => 'आप इसे बाद में लॉगिन स्क्रीन से बदल सकते हैं।';

  @override
  String get serverConfigDbAutoDetectError => 'डेटाबेस ऑटो-डिटेक्ट नहीं हो सका। कृपया URL जांचें।';

  @override
  String get attendanceDetailsTitle => 'अटेंडेंस विवरण';

  @override
  String get employeeLabel => 'कर्मचारी';

  @override
  String get statusOpen => 'ओपन';

  @override
  String get statusClosed => 'क्लोज़्ड';

  @override
  String get workedTimeLabel => 'काम का समय';

  @override
  String get extraHoursLabel => 'अतिरिक्त घंटे';

  @override
  String get checkInTitle => 'चेक-इन';

  @override
  String get checkOutTitle => 'चेक-आउट';

  @override
  String get ipAddressLabel => 'IP पता';

  @override
  String get gpsCoordinatesLabel => 'GPS निर्देशांक';

  @override
  String get unknownValue => 'अज्ञात';

  @override
  String get notAvailableValue => 'उपलब्ध नहीं';

  @override
  String get viewOnMaps => 'मैप पर देखें';

  @override
  String get notCheckedOutYet => 'अभी चेक-आउट नहीं हुआ';

  @override
  String hoursValue(String hours) {
    return '$hours घंटे';
  }

  @override
  String get attendanceOnDuty => 'ड्यूटी पर';

  @override
  String get attendanceOffDuty => 'ड्यूटी से बाहर';

  @override
  String get attendanceSwipeToCheckIn => 'चेक-इन के लिए स्वाइप करें';

  @override
  String get attendanceSwipeToCheckOut => 'चेक-आउट के लिए स्वाइप करें';

  @override
  String get attendanceCurrentLocation => 'वर्तमान स्थान';

  @override
  String get attendanceRefresh => 'रीफ़्रेश';

  @override
  String get attendanceFetchingAddress => 'पता प्राप्त किया जा रहा है...';

  @override
  String get attendanceWaitingForGps => 'GPS का इंतज़ार...';

  @override
  String get attendanceUploadSelfie => 'सेल्फ़ी अपलोड करें';

  @override
  String get attendanceLocationRequired => 'आगे बढ़ने के लिए लोकेशन आवश्यक है।';

  @override
  String get attendanceCheckInSuccess => 'स्वागत है! चेक-इन दर्ज हो गया।';

  @override
  String get attendanceCheckOutSuccess => 'शिफ्ट समाप्त। अच्छा काम!';

  @override
  String get attendanceCheckInFirst => 'कृपया पहले चेक-इन करें।';

  @override
  String get attendanceSelfieUploaded => 'सेल्फ़ी अपलोड हो गई';

  @override
  String get attendanceUploadFailed => 'अपलोड विफल';

  @override
  String get attendanceCameraError => 'कैमरा त्रुटि';

  @override
  String attendanceStartedAt(String time) {
    return '$time पर शुरू हुआ';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Lat: $lat, Lng: $lng';
  }

  @override
  String get attendanceReadyToStart => 'शिफ्ट शुरू करने के लिए तैयार';

  @override
  String get attendanceTitle => 'अटेंडेंस';

  @override
  String get attNavAttendance => 'अटेंडेंस';

  @override
  String get attNavHistory => 'हिस्ट्री';

  @override
  String get attFiltersTitle => 'अटेंडेंस फ़िल्टर';

  @override
  String get attDateRangeLabel => 'तारीख सीमा';

  @override
  String get attStatusLabel => 'स्थिति';

  @override
  String get attFilterTooltip => 'फ़िल्टर';

  @override
  String get attClearFilters => 'फ़िल्टर साफ़ करें';

  @override
  String get attApplyFilters => 'फ़िल्टर लागू करें';

  @override
  String get attFilterStatusAll => 'सभी स्थितियाँ';

  @override
  String get attFilterStatusOpen => 'ओपन (चेक-इन)';

  @override
  String get attFilterStatusClosed => 'क्लोज़्ड (चेक-आउट)';

  @override
  String get attFilterRangeToday => 'आज';

  @override
  String get attFilterRangeWeek => 'इस सप्ताह';

  @override
  String get attFilterRangeMonth => 'इस माह';

  @override
  String get attFilterRangeAll => 'सभी समय';

  @override
  String attFilterDescription(String status, String range) {
    return '$range के लिए $status';
  }

  @override
  String get attLoadingAttendance => 'अटेंडेंस लोड हो रही है…';

  @override
  String get attLoadingMore => 'और लोड हो रहा है…';

  @override
  String get attFailedToLoad => 'अटेंडेंस लोड नहीं हो सकी';

  @override
  String get attFailedToLoadMore => 'और लोड नहीं हो सका';

  @override
  String get attTryAgain => 'फिर कोशिश करें';

  @override
  String get attNoAttendanceTitle => 'कोई अटेंडेंस नहीं मिली';

  @override
  String get attNoAttendanceSubtitle => 'फ़िल्टर (तारीख सीमा या स्थिति) बदलकर देखें।';

  @override
  String get attNoMoreItems => 'आप सूची के अंत तक पहुँच गए हैं।';

  @override
  String employeeFallback(String id) {
    return 'कर्मचारी #$id';
  }

  @override
  String get attDetailsTitle => 'अटेंडेंस विवरण';

  @override
  String get attEmployeeLabel => 'कर्मचारी';

  @override
  String get attWorkedTimeLabel => 'काम का समय';

  @override
  String get attExtraHoursLabel => 'अतिरिक्त घंटे';

  @override
  String get attCheckInSection => 'चेक-इन';

  @override
  String get attCheckOutSection => 'चेक-आउट';

  @override
  String get attIpAddressLabel => '';

  @override
  String get attGpsCoordinatesLabel => 'GPS निर्देशांक';

  @override
  String get attViewOnMaps => 'मैप पर देखें';

  @override
  String get attUnknownValue => 'अज्ञात';

  @override
  String get attNotAvailableValue => 'उपलब्ध नहीं';

  @override
  String get attNotCheckedOutYet => 'अभी चेक-आउट नहीं हुआ';

  @override
  String get attZeroHours => '0.00 घंटे';
}
