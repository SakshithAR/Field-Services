// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Turkish (`tr`).
class AppLocalizationsTr extends AppLocalizations {
  AppLocalizationsTr([String locale = 'tr']) : super(locale);

  @override
  String get configureOdooServer => 'Configurar servidor Odoo';

  @override
  String get jobs => 'Trabajos';

  @override
  String get searchJobsHint => 'Buscar trabajos...';

  @override
  String get sortBy => 'Ordenar por';

  @override
  String get sortScheduledNearest => 'Programadas (más próximas primero)';

  @override
  String get sortScheduledFarthest => 'Programadas (más lejanas primero)';

  @override
  String get sortCustomerAZ => 'Cliente (A-Z)';

  @override
  String get sortStatus => 'Estado';

  @override
  String get tabAssigned => 'Asignados';

  @override
  String get tabInProgress => 'En curso';

  @override
  String get tabDone => 'Completados';

  @override
  String get tabAll => 'Todos';

  @override
  String get emptyJobsTitle => 'No hay trabajos';

  @override
  String get emptyJobsSubtitle => 'Prueba a cambiar la búsqueda o los filtros';

  @override
  String get emptyJobsAddButton => 'Añadir nuevo trabajo';

  @override
  String get noSchedule => 'Sin programación';

  @override
  String get statusDraft => 'Borrador';

  @override
  String get statusAssigned => 'Asignado';

  @override
  String get statusInProgress => 'En curso';

  @override
  String get statusDone => 'Completado';

  @override
  String get statusCancelled => 'Cancelado';

  @override
  String get settingsTitle => 'Ajustes de la aplicación';

  @override
  String get settingsAppearance => 'Apariencia';

  @override
  String get settingsTheme => 'Tema';

  @override
  String get settingsThemeLight => 'Claro';

  @override
  String get settingsThemeDark => 'Oscuro';

  @override
  String get settingsThemeSystem => 'Sistema';

  @override
  String get settingsAccentColor => 'Color de acento';

  @override
  String get settingsAccentColorPick => 'Elegir color';

  @override
  String get settingsAccentColorDialogTitle => 'Elige un color';

  @override
  String get settingsLanguageSection => 'Idioma y texto';

  @override
  String get settingsLanguageLabel => 'Idioma';

  @override
  String get settingsAboutSection => 'Acerca de la aplicación';

  @override
  String get settingsVersionLabel => 'Versión';

  @override
  String get languageEnglish => 'Inglés';

  @override
  String get languageArabic => 'Árabe';

  @override
  String get navJobs => 'Trabajos';

  @override
  String get navCalendar => 'Calendario';

  @override
  String get navMap => 'Mapa';

  @override
  String get navProfile => 'Perfil';

  @override
  String get profileSectionSettingsAndMore => 'Ajustes y más';

  @override
  String get profileSettingsTitle => 'Ajustes';

  @override
  String get profileSettingsSubtitle => 'Ajustes de la aplicación y del tema';

  @override
  String get profileLogoutTitle => 'Cerrar sesión';

  @override
  String get profileLogoutSubtitle => 'Cerrar sesión de tu cuenta';

  @override
  String get profileLoggedIn => 'Sesión iniciada';

  @override
  String get jobDetailSchedule => 'Programación';

  @override
  String get jobDetailStart => 'Inicio';

  @override
  String get jobDetailEnd => 'Fin';

  @override
  String get jobDetailDuration => 'Duración';

  @override
  String get jobDetailLocation => 'Ubicación';

  @override
  String get jobDetailLatShort => 'Lat';

  @override
  String get jobDetailLngShort => 'Lng';

  @override
  String get jobDetailOpenInMaps => 'Abrir en Maps';

  @override
  String get jobDetailNotes => 'Notas';

  @override
  String get jobDetailCustomerNotes => 'Notas del cliente';

  @override
  String get jobDetailInternalNotes => 'Notas internas';

  @override
  String get jobDetailPhotos => 'Fotos';

  @override
  String get jobDetailAddPhotos => 'Añadir fotos';

  @override
  String get jobDetailPhotosHint => 'Toca en cualquier parte de esta tarjeta o usa el botón para añadir fotos desde la cámara o la galería.';

  @override
  String get jobDetailTakePhotoCamera => 'Hacer foto (cámara)';

  @override
  String get jobDetailChooseFromGallery => 'Elegir desde la galería';

  @override
  String get jobDetailAuth => 'Autenticación';

  @override
  String get jobDetailAuthTooltip => 'Abrir autenticación';

  @override
  String get jobDetailAuthHint => 'Toca esta tarjeta para capturar la autenticación del cliente (firma).';

  @override
  String get jobDetailAuthSavedSignature => 'Firma guardada';

  @override
  String get jobDetailNoCustomer => 'Sin cliente';

  @override
  String get jobDetailUnassigned => 'Sin asignar';

  @override
  String get jobDetailStartButton => 'Iniciar';

  @override
  String get jobDetailMarkDone => 'Marcar como completado';

  @override
  String get jobDetailAssign => 'Asignar';

  @override
  String get jobDetailUpdateFailed => 'Error al actualizar el trabajo';

  @override
  String get locationServicesDisabled => 'Los servicios de ubicación están desactivados';

  @override
  String get locationPermissionDenied => 'Permiso de ubicación denegado';

  @override
  String get jobDetailStartFailed => 'Error al iniciar el trabajo';

  @override
  String get jobDetailNoLocationData => 'No hay GPS ni dirección disponible para este trabajo';

  @override
  String get jobDetailNoAddress => 'No hay dirección disponible para este trabajo';

  @override
  String get jobDetailMapOpenFailed => 'No se pudo abrir la aplicación de mapas';

  @override
  String get jobDetailMapError => 'Error al abrir los mapas';

  @override
  String get jobDetailPhotosUploaded => 'foto(s) subida(s)';

  @override
  String get jobDetailPhotosUploadFailed => 'Error al subir las fotos';

  @override
  String get authSaved => 'Autenticación guardada';

  @override
  String get authSaveFailed => 'Error al guardar la firma';

  @override
  String get authSignInstruction => 'Pide al cliente que firme dentro del recuadro de abajo.';

  @override
  String get photoViewerTitle => 'Foto';

  @override
  String get commonRefresh => 'Actualizar';

  @override
  String get commonClear => 'Borrar';

  @override
  String get commonCancel => 'Cancelar';

  @override
  String get commonSave => 'Guardar';

  @override
  String get addJobTitle => 'Nuevo trabajo';

  @override
  String get addJobJobTitleLabel => 'Título del trabajo';

  @override
  String get addJobJobTitleHint => 'Ej.: Mantenimiento de aire acondicionado – Villa 12B';

  @override
  String get addJobJobTitleRequired => 'Introduce el título del trabajo';

  @override
  String get addJobScheduledLabel => 'Fecha y hora programadas';

  @override
  String get addJobDateTimeNotSet => 'Sin definir';

  @override
  String get addJobCustomerNotesLabel => 'Notas del cliente (opcional)';

  @override
  String get addJobCustomerNotesHint => 'Notas del cliente, información de acceso, etc.';

  @override
  String get addJobInternalNotesLabel => 'Notas internas (opcional)';

  @override
  String get addJobInternalNotesHint => 'Notas solo para tu equipo';

  @override
  String get addJobCreateButton => 'Crear trabajo';

  @override
  String get addJobCreated => 'Trabajo creado';

  @override
  String get addJobCreateFailed => 'Error al crear el trabajo';

  @override
  String get calendarRefreshTooltip => 'Actualizar trabajos';

  @override
  String get calendarJobsOnPrefix => 'Trabajos el';

  @override
  String get calendarNoJobsOnDay => 'No hay trabajos este día';

  @override
  String get mapTitle => 'Mapa de trabajos';

  @override
  String get mapEmptyTitle => 'No hay trabajos para mostrar en el mapa';

  @override
  String get mapBottomTitle => 'Trabajos en el mapa';

  @override
  String get mapJobsLabel => 'trabajos';

  @override
  String get myJobsTitle => 'Mis trabajos';

  @override
  String get mapYouAreHere => 'Estás aquí';

  @override
  String get loginWelcomeBack => 'Bienvenido de nuevo';

  @override
  String get loginSubtitle => 'Inicia sesión para gestionar tus trabajos de servicio de campo.';

  @override
  String get loginDetailsTitle => 'Datos de acceso';

  @override
  String get loginEmailLabel => 'Correo electrónico / Usuario';

  @override
  String get loginPasswordLabel => 'Contraseña';

  @override
  String get loginButton => 'Iniciar sesión';

  @override
  String get loginError => 'Error al iniciar sesión. Comprueba las credenciales y el servidor.';

  @override
  String get validationRequired => 'Obligatorio';

  @override
  String get loginConnectedServer => 'Servidor conectado';

  @override
  String get loginNoServerConfigured => 'Todavía no hay ningún servidor configurado';

  @override
  String loginServerDb(String dbName) {
    return 'BD: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'BD: -';

  @override
  String get loginChangeServer => 'Cambiar servidor';

  @override
  String get loginPoweredBy => 'Desarrollado por Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Indica a la aplicación qué servidor y base de datos de Odoo debe usar.';

  @override
  String get serverConfigSectionConnectionDetails => 'Detalles de conexión';

  @override
  String get serverConfigServerUrlLabel => 'URL del servidor';

  @override
  String get serverConfigServerUrlHint => 'https://tu-dominio-odoo.com';

  @override
  String get serverConfigDbNameLabel => 'Nombre de la base de datos';

  @override
  String get serverConfigSaveButton => 'Guardar y continuar';

  @override
  String get serverConfigSaveHint => 'Siempre podrás cambiar esto más tarde desde la pantalla de inicio de sesión.';

  @override
  String get serverConfigDbAutoDetectError => 'No se pudo detectar la base de datos automáticamente. Comprueba la URL.';

  @override
  String get attendanceDetailsTitle => 'Devam detayları';

  @override
  String get employeeLabel => 'Çalışan';

  @override
  String get statusOpen => 'AÇIK';

  @override
  String get statusClosed => 'KAPALI';

  @override
  String get workedTimeLabel => 'Çalışılan süre';

  @override
  String get extraHoursLabel => 'Fazla mesai';

  @override
  String get checkInTitle => 'GİRİŞ';

  @override
  String get checkOutTitle => 'ÇIKIŞ';

  @override
  String get ipAddressLabel => 'IP adresi';

  @override
  String get gpsCoordinatesLabel => 'GPS koordinatları';

  @override
  String get unknownValue => 'Bilinmiyor';

  @override
  String get notAvailableValue => 'Mevcut değil';

  @override
  String get viewOnMaps => 'Haritada görüntüle';

  @override
  String get notCheckedOutYet => 'Henüz çıkış yapılmadı';

  @override
  String hoursValue(String hours) {
    return '$hours saat';
  }

  @override
  String get attendanceOnDuty => 'Görevde';

  @override
  String get attendanceOffDuty => 'Görevde değil';

  @override
  String get attendanceSwipeToCheckIn => 'Giriş yapmak için kaydırın';

  @override
  String get attendanceSwipeToCheckOut => 'Çıkış yapmak için kaydırın';

  @override
  String get attendanceCurrentLocation => 'Mevcut Konum';

  @override
  String get attendanceRefresh => 'YENİLE';

  @override
  String get attendanceFetchingAddress => 'Adres alınıyor...';

  @override
  String get attendanceWaitingForGps => 'GPS bekleniyor...';

  @override
  String get attendanceUploadSelfie => 'Selfie yükle';

  @override
  String get attendanceLocationRequired => 'Devam etmek için konum gerekli.';

  @override
  String get attendanceCheckInSuccess => 'Hoş geldiniz! Giriş kaydedildi.';

  @override
  String get attendanceCheckOutSuccess => 'Vardiya bitti. İyi iş!';

  @override
  String get attendanceCheckInFirst => 'Lütfen önce giriş yapın.';

  @override
  String get attendanceSelfieUploaded => 'Selfie yüklendi';

  @override
  String get attendanceUploadFailed => 'Yükleme başarısız';

  @override
  String get attendanceCameraError => 'Kamera hatası';

  @override
  String attendanceStartedAt(String time) {
    return '$time saatinde başladı';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Enlem: $lat, Boylam: $lng';
  }

  @override
  String get attendanceReadyToStart => 'Vardiyaya başlamak için hazır';

  @override
  String get attendanceTitle => 'Devam';

  @override
  String get attNavAttendance => 'Katılım';

  @override
  String get attNavHistory => 'Geçmiş';

  @override
  String get attFiltersTitle => 'Devam filtreleri';

  @override
  String get attDateRangeLabel => 'Tarih aralığı';

  @override
  String get attStatusLabel => 'Durum';

  @override
  String get attFilterTooltip => 'Filtre';

  @override
  String get attClearFilters => 'Filtreleri temizle';

  @override
  String get attApplyFilters => 'Filtreleri uygula';

  @override
  String get attFilterStatusAll => 'Tüm durumlar';

  @override
  String get attFilterStatusOpen => 'Açık (Giriş)';

  @override
  String get attFilterStatusClosed => 'Kapalı (Çıkış)';

  @override
  String get attFilterRangeToday => 'Bugün';

  @override
  String get attFilterRangeWeek => 'Bu hafta';

  @override
  String get attFilterRangeMonth => 'Bu ay';

  @override
  String get attFilterRangeAll => 'Tüm zamanlar';

  @override
  String attFilterDescription(String status, String range) {
    return '$range için $status';
  }

  @override
  String get attLoadingAttendance => 'Devam yükleniyor…';

  @override
  String get attLoadingMore => 'Daha fazla yükleniyor…';

  @override
  String get attFailedToLoad => 'Devam yüklenemedi';

  @override
  String get attFailedToLoadMore => 'Daha fazla yüklenemedi';

  @override
  String get attTryAgain => 'Tekrar dene';

  @override
  String get attNoAttendanceTitle => 'Kayıt bulunamadı';

  @override
  String get attNoAttendanceSubtitle => 'Filtreleri değiştirin (tarih aralığı veya durum).';

  @override
  String get attNoMoreItems => 'Listenin sonuna ulaştınız.';

  @override
  String employeeFallback(String id) {
    return 'Çalışan #$id';
  }

  @override
  String get attDetailsTitle => 'Devam Detayları';

  @override
  String get attEmployeeLabel => 'Çalışan';

  @override
  String get attWorkedTimeLabel => 'Çalışılan Süre';

  @override
  String get attExtraHoursLabel => 'Fazla Mesai';

  @override
  String get attCheckInSection => 'GİRİŞ';

  @override
  String get attCheckOutSection => 'ÇIKIŞ';

  @override
  String get attIpAddressLabel => 'IP Adresi';

  @override
  String get attGpsCoordinatesLabel => 'GPS Koordinatları';

  @override
  String get attViewOnMaps => 'Haritalarda Gör';

  @override
  String get attUnknownValue => 'Bilinmiyor';

  @override
  String get attNotAvailableValue => 'Mevcut değil';

  @override
  String get attNotCheckedOutYet => 'Henüz çıkış yapılmadı';

  @override
  String get attZeroHours => '0.00 sa';
}
