// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Spanish Castilian (`es`).
class AppLocalizationsEs extends AppLocalizations {
  AppLocalizationsEs([String locale = 'es']) : super(locale);

  @override
  String get configureOdooServer => 'Configurar servidor Odoo';

  @override
  String get jobs => 'Trabajos';

  @override
  String get searchJobsHint => 'Buscar trabajos...';

  @override
  String get sortBy => 'Ordenar por';

  @override
  String get sortScheduledNearest => 'Programadas (más próximas primero)';

  @override
  String get sortScheduledFarthest => 'Programadas (más lejanas primero)';

  @override
  String get sortCustomerAZ => 'Cliente (A-Z)';

  @override
  String get sortStatus => 'Estado';

  @override
  String get tabAssigned => 'Asignados';

  @override
  String get tabInProgress => 'En curso';

  @override
  String get tabDone => 'Completados';

  @override
  String get tabAll => 'Todos';

  @override
  String get emptyJobsTitle => 'No hay trabajos';

  @override
  String get emptyJobsSubtitle => 'Prueba a cambiar la búsqueda o los filtros';

  @override
  String get emptyJobsAddButton => 'Añadir nuevo trabajo';

  @override
  String get noSchedule => 'Sin programación';

  @override
  String get statusDraft => 'Borrador';

  @override
  String get statusAssigned => 'Asignado';

  @override
  String get statusInProgress => 'En curso';

  @override
  String get statusDone => 'Completado';

  @override
  String get statusCancelled => 'Cancelado';

  @override
  String get settingsTitle => 'Ajustes de la aplicación';

  @override
  String get settingsAppearance => 'Apariencia';

  @override
  String get settingsTheme => 'Tema';

  @override
  String get settingsThemeLight => 'Claro';

  @override
  String get settingsThemeDark => 'Oscuro';

  @override
  String get settingsThemeSystem => 'Sistema';

  @override
  String get settingsAccentColor => 'Color de acento';

  @override
  String get settingsAccentColorPick => 'Elegir color';

  @override
  String get settingsAccentColorDialogTitle => 'Elige un color';

  @override
  String get settingsLanguageSection => 'Idioma y texto';

  @override
  String get settingsLanguageLabel => 'Idioma';

  @override
  String get settingsAboutSection => 'Acerca de la aplicación';

  @override
  String get settingsVersionLabel => 'Versión';

  @override
  String get languageEnglish => 'Inglés';

  @override
  String get languageArabic => 'Árabe';

  @override
  String get navJobs => 'Trabajos';

  @override
  String get navCalendar => 'Calendario';

  @override
  String get navMap => 'Mapa';

  @override
  String get navProfile => 'Perfil';

  @override
  String get profileSectionSettingsAndMore => 'Ajustes y más';

  @override
  String get profileSettingsTitle => 'Ajustes';

  @override
  String get profileSettingsSubtitle => 'Ajustes de la aplicación y del tema';

  @override
  String get profileLogoutTitle => 'Cerrar sesión';

  @override
  String get profileLogoutSubtitle => 'Cerrar sesión de tu cuenta';

  @override
  String get profileLoggedIn => 'Sesión iniciada';

  @override
  String get jobDetailSchedule => 'Programación';

  @override
  String get jobDetailStart => 'Inicio';

  @override
  String get jobDetailEnd => 'Fin';

  @override
  String get jobDetailDuration => 'Duración';

  @override
  String get jobDetailLocation => 'Ubicación';

  @override
  String get jobDetailLatShort => 'Lat';

  @override
  String get jobDetailLngShort => 'Lng';

  @override
  String get jobDetailOpenInMaps => 'Abrir en Maps';

  @override
  String get jobDetailNotes => 'Notas';

  @override
  String get jobDetailCustomerNotes => 'Notas del cliente';

  @override
  String get jobDetailInternalNotes => 'Notas internas';

  @override
  String get jobDetailPhotos => 'Fotos';

  @override
  String get jobDetailAddPhotos => 'Añadir fotos';

  @override
  String get jobDetailPhotosHint => 'Toca en cualquier parte de esta tarjeta o usa el botón para añadir fotos desde la cámara o la galería.';

  @override
  String get jobDetailTakePhotoCamera => 'Hacer foto (cámara)';

  @override
  String get jobDetailChooseFromGallery => 'Elegir desde la galería';

  @override
  String get jobDetailAuth => 'Autenticación';

  @override
  String get jobDetailAuthTooltip => 'Abrir autenticación';

  @override
  String get jobDetailAuthHint => 'Toca esta tarjeta para capturar la autenticación del cliente (firma).';

  @override
  String get jobDetailAuthSavedSignature => 'Firma guardada';

  @override
  String get jobDetailNoCustomer => 'Sin cliente';

  @override
  String get jobDetailUnassigned => 'Sin asignar';

  @override
  String get jobDetailStartButton => 'Iniciar';

  @override
  String get jobDetailMarkDone => 'Marcar como completado';

  @override
  String get jobDetailAssign => 'Asignar';

  @override
  String get jobDetailUpdateFailed => 'Error al actualizar el trabajo';

  @override
  String get locationServicesDisabled => 'Los servicios de ubicación están desactivados';

  @override
  String get locationPermissionDenied => 'Permiso de ubicación denegado';

  @override
  String get jobDetailStartFailed => 'Error al iniciar el trabajo';

  @override
  String get jobDetailNoLocationData => 'No hay GPS ni dirección disponible para este trabajo';

  @override
  String get jobDetailNoAddress => 'No hay dirección disponible para este trabajo';

  @override
  String get jobDetailMapOpenFailed => 'No se pudo abrir la aplicación de mapas';

  @override
  String get jobDetailMapError => 'Error al abrir los mapas';

  @override
  String get jobDetailPhotosUploaded => 'foto(s) subida(s)';

  @override
  String get jobDetailPhotosUploadFailed => 'Error al subir las fotos';

  @override
  String get authSaved => 'Autenticación guardada';

  @override
  String get authSaveFailed => 'Error al guardar la firma';

  @override
  String get authSignInstruction => 'Pide al cliente que firme dentro del recuadro de abajo.';

  @override
  String get photoViewerTitle => 'Foto';

  @override
  String get commonRefresh => 'Actualizar';

  @override
  String get commonClear => 'Borrar';

  @override
  String get commonCancel => 'Cancelar';

  @override
  String get commonSave => 'Guardar';

  @override
  String get addJobTitle => 'Nuevo trabajo';

  @override
  String get addJobJobTitleLabel => 'Título del trabajo';

  @override
  String get addJobJobTitleHint => 'Ej.: Mantenimiento de aire acondicionado – Villa 12B';

  @override
  String get addJobJobTitleRequired => 'Introduce el título del trabajo';

  @override
  String get addJobScheduledLabel => 'Fecha y hora programadas';

  @override
  String get addJobDateTimeNotSet => 'Sin definir';

  @override
  String get addJobCustomerNotesLabel => 'Notas del cliente (opcional)';

  @override
  String get addJobCustomerNotesHint => 'Notas del cliente, información de acceso, etc.';

  @override
  String get addJobInternalNotesLabel => 'Notas internas (opcional)';

  @override
  String get addJobInternalNotesHint => 'Notas solo para tu equipo';

  @override
  String get addJobCreateButton => 'Crear trabajo';

  @override
  String get addJobCreated => 'Trabajo creado';

  @override
  String get addJobCreateFailed => 'Error al crear el trabajo';

  @override
  String get calendarRefreshTooltip => 'Actualizar trabajos';

  @override
  String get calendarJobsOnPrefix => 'Trabajos el';

  @override
  String get calendarNoJobsOnDay => 'No hay trabajos este día';

  @override
  String get mapTitle => 'Mapa de trabajos';

  @override
  String get mapEmptyTitle => 'No hay trabajos para mostrar en el mapa';

  @override
  String get mapBottomTitle => 'Trabajos en el mapa';

  @override
  String get mapJobsLabel => 'trabajos';

  @override
  String get myJobsTitle => 'Mis trabajos';

  @override
  String get mapYouAreHere => 'Estás aquí';

  @override
  String get loginWelcomeBack => 'Bienvenido de nuevo';

  @override
  String get loginSubtitle => 'Inicia sesión para gestionar tus trabajos de servicio de campo.';

  @override
  String get loginDetailsTitle => 'Datos de acceso';

  @override
  String get loginEmailLabel => 'Correo electrónico / Usuario';

  @override
  String get loginPasswordLabel => 'Contraseña';

  @override
  String get loginButton => 'Iniciar sesión';

  @override
  String get loginError => 'Error al iniciar sesión. Comprueba las credenciales y el servidor.';

  @override
  String get validationRequired => 'Obligatorio';

  @override
  String get loginConnectedServer => 'Servidor conectado';

  @override
  String get loginNoServerConfigured => 'Todavía no hay ningún servidor configurado';

  @override
  String loginServerDb(String dbName) {
    return 'BD: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'BD: -';

  @override
  String get loginChangeServer => 'Cambiar servidor';

  @override
  String get loginPoweredBy => 'Desarrollado por Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Indica a la aplicación qué servidor y base de datos de Odoo debe usar.';

  @override
  String get serverConfigSectionConnectionDetails => 'Detalles de conexión';

  @override
  String get serverConfigServerUrlLabel => 'URL del servidor';

  @override
  String get serverConfigServerUrlHint => 'https://tu-dominio-odoo.com';

  @override
  String get serverConfigDbNameLabel => 'Nombre de la base de datos';

  @override
  String get serverConfigSaveButton => 'Guardar y continuar';

  @override
  String get serverConfigSaveHint => 'Siempre podrás cambiar esto más tarde desde la pantalla de inicio de sesión.';

  @override
  String get serverConfigDbAutoDetectError => 'No se pudo detectar la base de datos automáticamente. Comprueba la URL.';

  @override
  String get attendanceDetailsTitle => 'Detalles de asistencia';

  @override
  String get employeeLabel => 'Empleado';

  @override
  String get statusOpen => 'ABIERTO';

  @override
  String get statusClosed => 'CERRADO';

  @override
  String get workedTimeLabel => 'Tiempo trabajado';

  @override
  String get extraHoursLabel => 'Horas extra';

  @override
  String get checkInTitle => 'ENTRADA';

  @override
  String get checkOutTitle => 'SALIDA';

  @override
  String get ipAddressLabel => 'Dirección IP';

  @override
  String get gpsCoordinatesLabel => 'Coordenadas GPS';

  @override
  String get unknownValue => 'Desconocido';

  @override
  String get notAvailableValue => 'No disponible';

  @override
  String get viewOnMaps => 'Ver en Maps';

  @override
  String get notCheckedOutYet => 'Aún no ha registrado salida';

  @override
  String hoursValue(String hours) {
    return '$hours h';
  }

  @override
  String get attendanceOnDuty => 'En servicio';

  @override
  String get attendanceOffDuty => 'Fuera de servicio';

  @override
  String get attendanceSwipeToCheckIn => 'Desliza para registrar entrada';

  @override
  String get attendanceSwipeToCheckOut => 'Desliza para registrar salida';

  @override
  String get attendanceCurrentLocation => 'Ubicación actual';

  @override
  String get attendanceRefresh => 'ACTUALIZAR';

  @override
  String get attendanceFetchingAddress => 'Obteniendo dirección...';

  @override
  String get attendanceWaitingForGps => 'Esperando GPS...';

  @override
  String get attendanceUploadSelfie => 'Subir selfie';

  @override
  String get attendanceLocationRequired => 'Se requiere ubicación para continuar.';

  @override
  String get attendanceCheckInSuccess => '¡Bienvenido! Entrada registrada.';

  @override
  String get attendanceCheckOutSuccess => 'Turno finalizado. ¡Buen trabajo!';

  @override
  String get attendanceCheckInFirst => 'Por favor, registra la entrada primero.';

  @override
  String get attendanceSelfieUploaded => 'Selfie subida';

  @override
  String get attendanceUploadFailed => 'Error al subir';

  @override
  String get attendanceCameraError => 'Error de cámara';

  @override
  String attendanceStartedAt(String time) {
    return 'Iniciado a las $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Lat: $lat, Lng: $lng';
  }

  @override
  String get attendanceReadyToStart => 'Listo para iniciar el turno';

  @override
  String get attendanceTitle => 'Asistencia';

  @override
  String get attNavAttendance => 'Asistencia';

  @override
  String get attNavHistory => 'Historial';

  @override
  String get attFiltersTitle => 'Filtros de asistencia';

  @override
  String get attDateRangeLabel => 'Rango de fechas';

  @override
  String get attStatusLabel => 'Estado';

  @override
  String get attFilterTooltip => 'Filtrar';

  @override
  String get attClearFilters => 'Borrar filtros';

  @override
  String get attApplyFilters => 'Aplicar filtros';

  @override
  String get attFilterStatusAll => 'Todos los estados';

  @override
  String get attFilterStatusOpen => 'Abierto (Entrada)';

  @override
  String get attFilterStatusClosed => 'Cerrado (Salida)';

  @override
  String get attFilterRangeToday => 'Hoy';

  @override
  String get attFilterRangeWeek => 'Esta semana';

  @override
  String get attFilterRangeMonth => 'Este mes';

  @override
  String get attFilterRangeAll => 'Todo el tiempo';

  @override
  String attFilterDescription(String status, String range) {
    return '$status para $range';
  }

  @override
  String get attLoadingAttendance => 'Cargando asistencia…';

  @override
  String get attLoadingMore => 'Cargando más…';

  @override
  String get attFailedToLoad => 'No se pudo cargar la asistencia';

  @override
  String get attFailedToLoadMore => 'No se pudo cargar más';

  @override
  String get attTryAgain => 'Intentar de nuevo';

  @override
  String get attNoAttendanceTitle => 'No se encontró asistencia';

  @override
  String get attNoAttendanceSubtitle => 'Prueba a ajustar los filtros (rango de fechas o estado).';

  @override
  String get attNoMoreItems => 'Has llegado al final de la lista.';

  @override
  String employeeFallback(String id) {
    return 'Empleado #$id';
  }

  @override
  String get attDetailsTitle => 'Detalles de asistencia';

  @override
  String get attEmployeeLabel => 'Empleado';

  @override
  String get attWorkedTimeLabel => 'Tiempo trabajado';

  @override
  String get attExtraHoursLabel => 'Horas extra';

  @override
  String get attCheckInSection => 'ENTRADA';

  @override
  String get attCheckOutSection => 'SALIDA';

  @override
  String get attIpAddressLabel => 'Dirección IP';

  @override
  String get attGpsCoordinatesLabel => 'Coordenadas GPS';

  @override
  String get attViewOnMaps => 'Ver en Maps';

  @override
  String get attUnknownValue => 'Desconocido';

  @override
  String get attNotAvailableValue => 'No disponible';

  @override
  String get attNotCheckedOutYet => 'Aún no ha registrado salida';

  @override
  String get attZeroHours => '0.00 h';
}
