// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for German (`de`).
class AppLocalizationsDe extends AppLocalizations {
  AppLocalizationsDe([String locale = 'de']) : super(locale);

  @override
  String get configureOdooServer => 'Odoo-Server konfigurieren';

  @override
  String get jobs => 'Aufträge';

  @override
  String get searchJobsHint => 'Aufträge suchen...';

  @override
  String get sortBy => 'Sortieren nach';

  @override
  String get sortScheduledNearest => 'Geplant (nächste zuerst)';

  @override
  String get sortScheduledFarthest => 'Geplant (weiteste zuerst)';

  @override
  String get sortCustomerAZ => 'Kunde (A–Z)';

  @override
  String get sortStatus => 'Status';

  @override
  String get tabAssigned => 'Zugewiesen';

  @override
  String get tabInProgress => 'In Bearbeitung';

  @override
  String get tabDone => 'Erledigt';

  @override
  String get tabAll => 'Alle';

  @override
  String get emptyJobsTitle => 'Keine Aufträge';

  @override
  String get emptyJobsSubtitle => 'Versuche, Suche oder Filter zu ändern';

  @override
  String get emptyJobsAddButton => 'Neuen Auftrag hinzufügen';

  @override
  String get noSchedule => 'Kein Termin';

  @override
  String get statusDraft => 'Entwurf';

  @override
  String get statusAssigned => 'Zugewiesen';

  @override
  String get statusInProgress => 'In Bearbeitung';

  @override
  String get statusDone => 'Erledigt';

  @override
  String get statusCancelled => 'Storniert';

  @override
  String get settingsTitle => 'App-Einstellungen';

  @override
  String get settingsAppearance => 'Darstellung';

  @override
  String get settingsTheme => 'Design';

  @override
  String get settingsThemeLight => 'Hell';

  @override
  String get settingsThemeDark => 'Dunkel';

  @override
  String get settingsThemeSystem => 'System';

  @override
  String get settingsAccentColor => 'Akzentfarbe';

  @override
  String get settingsAccentColorPick => 'Farbe wählen';

  @override
  String get settingsAccentColorDialogTitle => 'Farbe auswählen';

  @override
  String get settingsLanguageSection => 'Sprache & Text';

  @override
  String get settingsLanguageLabel => 'Sprache';

  @override
  String get settingsAboutSection => 'Über die App';

  @override
  String get settingsVersionLabel => 'Version';

  @override
  String get languageEnglish => 'Englisch';

  @override
  String get languageArabic => 'Arabisch';

  @override
  String get navJobs => 'Aufträge';

  @override
  String get navCalendar => 'Kalender';

  @override
  String get navMap => 'Karte';

  @override
  String get navProfile => 'Profil';

  @override
  String get profileSectionSettingsAndMore => 'Einstellungen & mehr';

  @override
  String get profileSettingsTitle => 'Einstellungen';

  @override
  String get profileSettingsSubtitle => 'App- und Design-Einstellungen';

  @override
  String get profileLogoutTitle => 'Abmelden';

  @override
  String get profileLogoutSubtitle => 'Aus deinem Konto abmelden';

  @override
  String get profileLoggedIn => 'Angemeldet';

  @override
  String get jobDetailSchedule => 'Zeitplan';

  @override
  String get jobDetailStart => 'Start';

  @override
  String get jobDetailEnd => 'Ende';

  @override
  String get jobDetailDuration => 'Dauer';

  @override
  String get jobDetailLocation => 'Ort';

  @override
  String get jobDetailLatShort => 'Breite';

  @override
  String get jobDetailLngShort => 'Länge';

  @override
  String get jobDetailOpenInMaps => 'In Karten öffnen';

  @override
  String get jobDetailNotes => 'Notizen';

  @override
  String get jobDetailCustomerNotes => 'Kundennotizen';

  @override
  String get jobDetailInternalNotes => 'Interne Notizen';

  @override
  String get jobDetailPhotos => 'Fotos';

  @override
  String get jobDetailAddPhotos => 'Fotos hinzufügen';

  @override
  String get jobDetailPhotosHint => 'Tippe auf diese Karte oder nutze die Schaltfläche, um Fotos aus Kamera oder Galerie anzuhängen.';

  @override
  String get jobDetailTakePhotoCamera => 'Foto aufnehmen (Kamera)';

  @override
  String get jobDetailChooseFromGallery => 'Aus Galerie auswählen';

  @override
  String get jobDetailAuth => 'Authentifizierung';

  @override
  String get jobDetailAuthTooltip => 'Authentifizierung öffnen';

  @override
  String get jobDetailAuthHint => 'Tippe auf diese Karte, um die Kundenbestätigung (Unterschrift) aufzunehmen.';

  @override
  String get jobDetailAuthSavedSignature => 'Gespeicherte Unterschrift';

  @override
  String get jobDetailNoCustomer => 'Kein Kunde';

  @override
  String get jobDetailUnassigned => 'Nicht zugewiesen';

  @override
  String get jobDetailStartButton => 'Starten';

  @override
  String get jobDetailMarkDone => 'Als erledigt markieren';

  @override
  String get jobDetailAssign => 'Zuweisen';

  @override
  String get jobDetailUpdateFailed => 'Auftrag konnte nicht aktualisiert werden';

  @override
  String get locationServicesDisabled => 'Standortdienste sind deaktiviert';

  @override
  String get locationPermissionDenied => 'Standortberechtigung verweigert';

  @override
  String get jobDetailStartFailed => 'Auftrag konnte nicht gestartet werden';

  @override
  String get jobDetailNoLocationData => 'Keine GPS- oder Adressdaten für diesen Auftrag verfügbar';

  @override
  String get jobDetailNoAddress => 'Keine Adresse für diesen Auftrag verfügbar';

  @override
  String get jobDetailMapOpenFailed => 'Karten-App konnte nicht geöffnet werden';

  @override
  String get jobDetailMapError => 'Karten konnten nicht geöffnet werden';

  @override
  String get jobDetailPhotosUploaded => 'Foto(s) hochgeladen';

  @override
  String get jobDetailPhotosUploadFailed => 'Fotos konnten nicht hochgeladen werden';

  @override
  String get authSaved => 'Authentifizierung gespeichert';

  @override
  String get authSaveFailed => 'Unterschrift konnte nicht gespeichert werden';

  @override
  String get authSignInstruction => 'Bitte den Kunden im Feld unten unterschreiben lassen.';

  @override
  String get photoViewerTitle => 'Foto';

  @override
  String get commonRefresh => 'Aktualisieren';

  @override
  String get commonClear => 'Löschen';

  @override
  String get commonCancel => 'Abbrechen';

  @override
  String get commonSave => 'Speichern';

  @override
  String get addJobTitle => 'Neuer Auftrag';

  @override
  String get addJobJobTitleLabel => 'Auftragstitel';

  @override
  String get addJobJobTitleHint => 'z. B.: AC-Wartung – Villa 12B';

  @override
  String get addJobJobTitleRequired => 'Bitte Auftragstitel eingeben';

  @override
  String get addJobScheduledLabel => 'Geplantes Datum & Uhrzeit';

  @override
  String get addJobDateTimeNotSet => 'Nicht festgelegt';

  @override
  String get addJobCustomerNotesLabel => 'Kundennotizen (optional)';

  @override
  String get addJobCustomerNotesHint => 'Notizen vom Kunden, Zugangsdaten usw.';

  @override
  String get addJobInternalNotesLabel => 'Interne Notizen (optional)';

  @override
  String get addJobInternalNotesHint => 'Nur für dein Team';

  @override
  String get addJobCreateButton => 'Auftrag erstellen';

  @override
  String get addJobCreated => 'Auftrag erstellt';

  @override
  String get addJobCreateFailed => 'Auftrag konnte nicht erstellt werden';

  @override
  String get calendarRefreshTooltip => 'Aufträge aktualisieren';

  @override
  String get calendarJobsOnPrefix => 'Aufträge am';

  @override
  String get calendarNoJobsOnDay => 'Keine Aufträge an diesem Tag';

  @override
  String get mapTitle => 'Auftragskarte';

  @override
  String get mapEmptyTitle => 'Keine Aufträge auf der Karte';

  @override
  String get mapBottomTitle => 'Aufträge auf der Karte';

  @override
  String get mapJobsLabel => 'Aufträge';

  @override
  String get myJobsTitle => 'Meine Aufträge';

  @override
  String get mapYouAreHere => 'Du bist hier';

  @override
  String get loginWelcomeBack => 'Willkommen zurück';

  @override
  String get loginSubtitle => 'Melde dich an, um deine Außendienstaufträge zu verwalten.';

  @override
  String get loginDetailsTitle => 'Anmeldedaten';

  @override
  String get loginEmailLabel => 'E-Mail / Login';

  @override
  String get loginPasswordLabel => 'Passwort';

  @override
  String get loginButton => 'Anmelden';

  @override
  String get loginError => 'Anmeldung fehlgeschlagen. Bitte Zugangsdaten und Server prüfen.';

  @override
  String get validationRequired => 'Erforderlich';

  @override
  String get loginConnectedServer => 'Verbundenes System';

  @override
  String get loginNoServerConfigured => 'Noch kein Server konfiguriert';

  @override
  String loginServerDb(String dbName) {
    return 'DB: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'DB: -';

  @override
  String get loginChangeServer => 'Server ändern';

  @override
  String get loginPoweredBy => 'Powered by Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Gib an, welchen Odoo-Server und welche Datenbank verwendet werden soll.';

  @override
  String get serverConfigSectionConnectionDetails => 'Verbindungsdetails';

  @override
  String get serverConfigServerUrlLabel => 'Server-URL';

  @override
  String get serverConfigServerUrlHint => 'https://your-odoo-domain.com';

  @override
  String get serverConfigDbNameLabel => 'Datenbankname';

  @override
  String get serverConfigSaveButton => 'Speichern und fortfahren';

  @override
  String get serverConfigSaveHint => 'Du kannst dies später jederzeit auf der Login-Seite ändern.';

  @override
  String get serverConfigDbAutoDetectError => 'Datenbank konnte nicht automatisch erkannt werden. Bitte URL prüfen.';

  @override
  String get attendanceDetailsTitle => 'Anwesenheitsdetails';

  @override
  String get employeeLabel => 'Mitarbeiter';

  @override
  String get statusOpen => 'OFFEN';

  @override
  String get statusClosed => 'GESCHLOSSEN';

  @override
  String get workedTimeLabel => 'Arbeitszeit';

  @override
  String get extraHoursLabel => 'Überstunden';

  @override
  String get checkInTitle => 'EINSTEMPELN';

  @override
  String get checkOutTitle => 'AUSSTEMPELN';

  @override
  String get ipAddressLabel => 'IP-Adresse';

  @override
  String get gpsCoordinatesLabel => 'GPS-Koordinaten';

  @override
  String get unknownValue => 'Unbekannt';

  @override
  String get notAvailableValue => 'Nicht verfügbar';

  @override
  String get viewOnMaps => 'In Maps ansehen';

  @override
  String get notCheckedOutYet => 'Noch nicht ausgestempelt';

  @override
  String hoursValue(String hours) {
    return '$hours Std.';
  }

  @override
  String get attendanceOnDuty => 'Im Dienst';

  @override
  String get attendanceOffDuty => 'Außer Dienst';

  @override
  String get attendanceSwipeToCheckIn => 'Zum Einstempeln wischen';

  @override
  String get attendanceSwipeToCheckOut => 'Zum Ausstempeln wischen';

  @override
  String get attendanceCurrentLocation => 'Aktueller Standort';

  @override
  String get attendanceRefresh => 'AKTUALISIEREN';

  @override
  String get attendanceFetchingAddress => 'Adresse wird abgerufen...';

  @override
  String get attendanceWaitingForGps => 'Warte auf GPS...';

  @override
  String get attendanceUploadSelfie => 'Selfie hochladen';

  @override
  String get attendanceLocationRequired => 'Standort erforderlich, um fortzufahren.';

  @override
  String get attendanceCheckInSuccess => 'Willkommen! Einstempeln gespeichert.';

  @override
  String get attendanceCheckOutSuccess => 'Schicht beendet. Gute Arbeit!';

  @override
  String get attendanceCheckInFirst => 'Bitte zuerst einstempeln.';

  @override
  String get attendanceSelfieUploaded => 'Selfie hochgeladen';

  @override
  String get attendanceUploadFailed => 'Upload fehlgeschlagen';

  @override
  String get attendanceCameraError => 'Kamera-Fehler';

  @override
  String attendanceStartedAt(String time) {
    return 'Gestartet um $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Breite: $lat, Länge: $lng';
  }

  @override
  String get attendanceReadyToStart => 'Bereit, die Schicht zu starten';

  @override
  String get attendanceTitle => 'Anwesenheit';

  @override
  String get attNavAttendance => 'Anwesenheit';

  @override
  String get attNavHistory => 'Verlauf';

  @override
  String get attFiltersTitle => 'Anwesenheitsfilter';

  @override
  String get attDateRangeLabel => 'Datumsbereich';

  @override
  String get attStatusLabel => 'Status';

  @override
  String get attFilterTooltip => 'Filter';

  @override
  String get attClearFilters => 'Filter löschen';

  @override
  String get attApplyFilters => 'Filter anwenden';

  @override
  String get attFilterStatusAll => 'Alle Status';

  @override
  String get attFilterStatusOpen => 'Offen (eingestempelt)';

  @override
  String get attFilterStatusClosed => 'Geschlossen (ausgestempelt)';

  @override
  String get attFilterRangeToday => 'Heute';

  @override
  String get attFilterRangeWeek => 'Diese Woche';

  @override
  String get attFilterRangeMonth => 'Dieser Monat';

  @override
  String get attFilterRangeAll => 'Gesamter Zeitraum';

  @override
  String attFilterDescription(String status, String range) {
    return '$status für $range';
  }

  @override
  String get attLoadingAttendance => 'Anwesenheit wird geladen…';

  @override
  String get attLoadingMore => 'Mehr wird geladen…';

  @override
  String get attFailedToLoad => 'Anwesenheit konnte nicht geladen werden';

  @override
  String get attFailedToLoadMore => 'Mehr konnte nicht geladen werden';

  @override
  String get attTryAgain => 'Erneut versuchen';

  @override
  String get attNoAttendanceTitle => 'Keine Anwesenheit gefunden';

  @override
  String get attNoAttendanceSubtitle => 'Versuche, die Filter (Datumsbereich oder Status) anzupassen.';

  @override
  String get attNoMoreItems => 'Du hast das Ende der Liste erreicht.';

  @override
  String employeeFallback(String id) {
    return 'Mitarbeiter #$id';
  }

  @override
  String get attDetailsTitle => 'Anwesenheitsdetails';

  @override
  String get attEmployeeLabel => 'Mitarbeiter';

  @override
  String get attWorkedTimeLabel => 'Arbeitszeit';

  @override
  String get attExtraHoursLabel => 'Überstunden';

  @override
  String get attCheckInSection => 'EINSTEMPELN';

  @override
  String get attCheckOutSection => 'AUSSTEMPELN';

  @override
  String get attIpAddressLabel => 'IP-Adresse';

  @override
  String get attGpsCoordinatesLabel => 'GPS-Koordinaten';

  @override
  String get attViewOnMaps => 'In Maps ansehen';

  @override
  String get attUnknownValue => 'Unbekannt';

  @override
  String get attNotAvailableValue => 'Nicht verfügbar';

  @override
  String get attNotCheckedOutYet => 'Noch nicht ausgestempelt';

  @override
  String get attZeroHours => '0,00 Std.';
}
