import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:field_service/l10n/app_localizations.dart';
import 'attendance_record.dart';

class AttendanceDetailsPage extends StatelessWidget {
  final AttendanceRecord record;

  const AttendanceDetailsPage({super.key, required this.record});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final t = AppLocalizations.of(context)!;
    final isClosed = record.checkOut != null;

    return Scaffold(
      backgroundColor: theme.colorScheme.surfaceContainerLowest,
      appBar: AppBar(
        title: Text(t.attendanceDetailsTitle),
        centerTitle: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: theme.colorScheme.outlineVariant),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 24,
                          backgroundColor: theme.colorScheme.primaryContainer,
                          child: Text(
                            record.employee.name.isNotEmpty
                                ? record.employee.name[0].toUpperCase()
                                : "#",
                            style: TextStyle(
                              color: theme.colorScheme.onPrimaryContainer,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                t.employeeLabel,
                                style: theme.textTheme.labelMedium?.copyWith(
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                              Text(
                                record.employee.name,
                                style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        _StatusBadge(
                          isOpen: !isClosed,
                          openText: t.statusOpen,
                          closedText: t.statusClosed,
                        ),
                      ],
                    ),
                    const Divider(height: 32),
                    IntrinsicHeight(
                      child: Row(
                        children: [
                          _StatItem(
                            label: t.workedTimeLabel,
                            value: t.hoursValue(record.workedHours.toStringAsFixed(2)),
                            icon: Icons.timer_outlined,
                            theme: theme,
                          ),
                          const VerticalDivider(),
                          _StatItem(
                            label: t.extraHoursLabel,
                            value: t.hoursValue(_formatOvertime(record.validatedOvertimeHours)),
                            icon: Icons.more_time_rounded,
                            theme: theme,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            _SectionHeader(title: t.checkInTitle),
            const SizedBox(height: 8),
            _DetailCard(
              theme: theme,
              time: record.checkIn,
              ipAddress: record.inIpAddress,
              lat: record.inLatitude,
              long: record.inLongitude,
              isCheckIn: true,
              ipLabel: t.ipAddressLabel,
              gpsLabel: t.gpsCoordinatesLabel,
              unknownText: t.unknownValue,
              notAvailableText: t.notAvailableValue,
              viewOnMapsText: t.viewOnMaps,
            ),

            const SizedBox(height: 24),

            _SectionHeader(title: t.checkOutTitle),
            const SizedBox(height: 8),
            if (record.checkOut != null)
              _DetailCard(
                theme: theme,
                time: record.checkOut!,
                ipAddress: record.outIpAddress,
                lat: record.outLatitude,
                long: record.outLongitude,
                isCheckIn: false,
                ipLabel: t.ipAddressLabel,
                gpsLabel: t.gpsCoordinatesLabel,
                unknownText: t.unknownValue,
                notAvailableText: t.notAvailableValue,
                viewOnMapsText: t.viewOnMaps,
              )
            else
              _MissingCheckoutCard(
                theme: theme,
                title: t.notCheckedOutYet,
              ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  String _formatOvertime(double? val) {
    if (val == null) return "0.00";
    return val.toStringAsFixed(2);
  }
}

class _DetailCard extends StatelessWidget {
  final ThemeData theme;
  final DateTime time;
  final String? ipAddress;
  final double? lat;
  final double? long;
  final bool isCheckIn;

  final String ipLabel;
  final String gpsLabel;
  final String unknownText;
  final String notAvailableText;
  final String viewOnMapsText;

  const _DetailCard({
    required this.theme,
    required this.time,
    required this.ipAddress,
    required this.lat,
    required this.long,
    required this.isCheckIn,
    required this.ipLabel,
    required this.gpsLabel,
    required this.unknownText,
    required this.notAvailableText,
    required this.viewOnMapsText,
  });

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat("MM/dd/yyyy HH:mm:ss");
    final formattedDate = dateFormat.format(time);

    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainer,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: Row(
              children: [
                Icon(
                  isCheckIn ? Icons.login_rounded : Icons.logout_rounded,
                  size: 20,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 12),
                Text(
                  formattedDate,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontFamily: 'Monospace',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _DetailRow(
                  label: ipLabel,
                  value: ipAddress ?? unknownText,
                  theme: theme,
                ),
                const SizedBox(height: 12),
                _DetailRow(
                  label: gpsLabel,
                  value: (lat != null && long != null)
                      ? "$lat , $long"
                      : notAvailableText,
                  theme: theme,
                ),
                if (lat != null && long != null) ...[
                  const SizedBox(height: 16),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final uri = Uri.parse(
                          'https://www.google.com/maps/search/?api=1&query=$lat,$long',
                        );
                        if (await canLaunchUrl(uri)) {
                          await launchUrl(uri, mode: LaunchMode.externalApplication);
                        }
                      },
                      icon: const Icon(Icons.map_outlined, size: 18),
                      label: Text(viewOnMapsText),
                      style: OutlinedButton.styleFrom(
                        visualDensity: VisualDensity.compact,
                      ),
                    ),
                  )
                ]
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final ThemeData theme;

  const _DetailRow({required this.label, required this.value, required this.theme});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 120,
          child: Text(
            label,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }
}

class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final ThemeData theme;

  const _StatItem({
    required this.label,
    required this.value,
    required this.icon,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: theme.colorScheme.primary, size: 20),
          const SizedBox(height: 4),
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final bool isOpen;
  final String openText;
  final String closedText;

  const _StatusBadge({
    required this.isOpen,
    required this.openText,
    required this.closedText,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = isOpen ? theme.colorScheme.tertiary : theme.colorScheme.secondary;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Text(
        isOpen ? openText : closedText,
        style: theme.textTheme.labelSmall?.copyWith(
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: Theme.of(context).textTheme.labelLarge?.copyWith(
        color: Theme.of(context).colorScheme.onSurfaceVariant,
        fontWeight: FontWeight.bold,
        letterSpacing: 1.2,
      ),
    );
  }
}

class _MissingCheckoutCard extends StatelessWidget {
  final ThemeData theme;
  final String title;

  const _MissingCheckoutCard({required this.theme, required this.title});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.3),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: theme.colorScheme.outlineVariant.withOpacity(0.5)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            children: [
              Icon(Icons.hourglass_empty_rounded,
                  color: theme.colorScheme.onSurfaceVariant),
              const SizedBox(height: 8),
              Text(
                title,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
