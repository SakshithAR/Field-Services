// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Russian (`ru`).
class AppLocalizationsRu extends AppLocalizations {
  AppLocalizationsRu([String locale = 'ru']) : super(locale);

  @override
  String get configureOdooServer => 'Настроить сервер Odoo';

  @override
  String get jobs => 'Заявки';

  @override
  String get searchJobsHint => 'Поиск заявок...';

  @override
  String get sortBy => 'Сортировать по';

  @override
  String get sortScheduledNearest => 'Запланировано (самые ближайшие)';

  @override
  String get sortScheduledFarthest => 'Запланировано (самые поздние)';

  @override
  String get sortCustomerAZ => 'Клиент (A–Z)';

  @override
  String get sortStatus => 'Статус';

  @override
  String get tabAssigned => 'Назначенные';

  @override
  String get tabInProgress => 'В работе';

  @override
  String get tabDone => 'Завершенные';

  @override
  String get tabAll => 'Все';

  @override
  String get emptyJobsTitle => 'Нет заявок';

  @override
  String get emptyJobsSubtitle => 'Попробуйте изменить поиск или фильтры';

  @override
  String get emptyJobsAddButton => 'Добавить новую заявку';

  @override
  String get noSchedule => 'Без расписания';

  @override
  String get statusDraft => 'Черновик';

  @override
  String get statusAssigned => 'Назначено';

  @override
  String get statusInProgress => 'В работе';

  @override
  String get statusDone => 'Завершено';

  @override
  String get statusCancelled => 'Отменено';

  @override
  String get settingsTitle => 'Настройки приложения';

  @override
  String get settingsAppearance => 'Оформление';

  @override
  String get settingsTheme => 'Тема';

  @override
  String get settingsThemeLight => 'Светлая';

  @override
  String get settingsThemeDark => 'Тёмная';

  @override
  String get settingsThemeSystem => 'Системная';

  @override
  String get settingsAccentColor => 'Акцентный цвет';

  @override
  String get settingsAccentColorPick => 'Выбрать цвет';

  @override
  String get settingsAccentColorDialogTitle => 'Выберите цвет';

  @override
  String get settingsLanguageSection => 'Язык и текст';

  @override
  String get settingsLanguageLabel => 'Язык';

  @override
  String get settingsAboutSection => 'О приложении';

  @override
  String get settingsVersionLabel => 'Версия';

  @override
  String get languageEnglish => 'Английский';

  @override
  String get languageArabic => 'Арабский';

  @override
  String get navJobs => 'Заявки';

  @override
  String get navCalendar => 'Календарь';

  @override
  String get navMap => 'Карта';

  @override
  String get navProfile => 'Профиль';

  @override
  String get profileSectionSettingsAndMore => 'Настройки и другое';

  @override
  String get profileSettingsTitle => 'Настройки';

  @override
  String get profileSettingsSubtitle => 'Настройки приложения и оформления';

  @override
  String get profileLogoutTitle => 'Выйти';

  @override
  String get profileLogoutSubtitle => 'Выйти из учётной записи';

  @override
  String get profileLoggedIn => 'Выполнен вход';

  @override
  String get jobDetailSchedule => 'Расписание';

  @override
  String get jobDetailStart => 'Начало';

  @override
  String get jobDetailEnd => 'Окончание';

  @override
  String get jobDetailDuration => 'Длительность';

  @override
  String get jobDetailLocation => 'Местоположение';

  @override
  String get jobDetailLatShort => 'Шир.';

  @override
  String get jobDetailLngShort => 'Долг.';

  @override
  String get jobDetailOpenInMaps => 'Открыть в Maps';

  @override
  String get jobDetailNotes => 'Заметки';

  @override
  String get jobDetailCustomerNotes => 'Заметки клиента';

  @override
  String get jobDetailInternalNotes => 'Внутренние заметки';

  @override
  String get jobDetailPhotos => 'Фотографии';

  @override
  String get jobDetailAddPhotos => 'Добавить фото';

  @override
  String get jobDetailPhotosHint => 'Нажмите в любом месте этой карточки или используйте кнопку, чтобы добавить фото с камеры или из галереи.';

  @override
  String get jobDetailTakePhotoCamera => 'Сделать фото (камера)';

  @override
  String get jobDetailChooseFromGallery => 'Выбрать из галереи';

  @override
  String get jobDetailAuth => 'Подтверждение';

  @override
  String get jobDetailAuthTooltip => 'Открыть подтверждение';

  @override
  String get jobDetailAuthHint => 'Нажмите на эту карточку, чтобы зафиксировать подтверждение клиента (подпись).';

  @override
  String get jobDetailAuthSavedSignature => 'Подпись сохранена';

  @override
  String get jobDetailNoCustomer => 'Нет клиента';

  @override
  String get jobDetailUnassigned => 'Не назначено';

  @override
  String get jobDetailStartButton => 'Начать';

  @override
  String get jobDetailMarkDone => 'Отметить как выполнено';

  @override
  String get jobDetailAssign => 'Назначить';

  @override
  String get jobDetailUpdateFailed => 'Не удалось обновить заявку';

  @override
  String get locationServicesDisabled => 'Службы геолокации отключены';

  @override
  String get locationPermissionDenied => 'Доступ к местоположению запрещён';

  @override
  String get jobDetailStartFailed => 'Не удалось запустить заявку';

  @override
  String get jobDetailNoLocationData => 'Для этой заявки нет GPS или адреса';

  @override
  String get jobDetailNoAddress => 'Для этой заявки нет доступного адреса';

  @override
  String get jobDetailMapOpenFailed => 'Не удалось открыть приложение карт';

  @override
  String get jobDetailMapError => 'Ошибка при открытии карт';

  @override
  String get jobDetailPhotosUploaded => 'фото загружено';

  @override
  String get jobDetailPhotosUploadFailed => 'Не удалось загрузить фото';

  @override
  String get authSaved => 'Подтверждение сохранено';

  @override
  String get authSaveFailed => 'Не удалось сохранить подпись';

  @override
  String get authSignInstruction => 'Попросите клиента расписаться в рамке ниже.';

  @override
  String get photoViewerTitle => 'Фото';

  @override
  String get commonRefresh => 'Обновить';

  @override
  String get commonClear => 'Очистить';

  @override
  String get commonCancel => 'Отмена';

  @override
  String get commonSave => 'Сохранить';

  @override
  String get addJobTitle => 'Новая заявка';

  @override
  String get addJobJobTitleLabel => 'Название заявки';

  @override
  String get addJobJobTitleHint => 'Например: Обслуживание кондиционера – Вилла 12B';

  @override
  String get addJobJobTitleRequired => 'Введите название заявки';

  @override
  String get addJobScheduledLabel => 'Запланированная дата и время';

  @override
  String get addJobDateTimeNotSet => 'Не задано';

  @override
  String get addJobCustomerNotesLabel => 'Заметки клиента (необязательно)';

  @override
  String get addJobCustomerNotesHint => 'Заметки клиента, информация о доступе и т.д.';

  @override
  String get addJobInternalNotesLabel => 'Внутренние заметки (необязательно)';

  @override
  String get addJobInternalNotesHint => 'Заметки только для вашей команды';

  @override
  String get addJobCreateButton => 'Создать заявку';

  @override
  String get addJobCreated => 'Заявка создана';

  @override
  String get addJobCreateFailed => 'Не удалось создать заявку';

  @override
  String get calendarRefreshTooltip => 'Обновить заявки';

  @override
  String get calendarJobsOnPrefix => 'Заявки на';

  @override
  String get calendarNoJobsOnDay => 'На этот день заявок нет';

  @override
  String get mapTitle => 'Карта заявок';

  @override
  String get mapEmptyTitle => 'Нет заявок для отображения на карте';

  @override
  String get mapBottomTitle => 'Заявки на карте';

  @override
  String get mapJobsLabel => 'заявок';

  @override
  String get myJobsTitle => 'Мои заявки';

  @override
  String get mapYouAreHere => 'Вы здесь';

  @override
  String get loginWelcomeBack => 'С возвращением';

  @override
  String get loginSubtitle => 'Войдите, чтобы управлять заявками выездного сервиса.';

  @override
  String get loginDetailsTitle => 'Данные для входа';

  @override
  String get loginEmailLabel => 'E-mail / Логин';

  @override
  String get loginPasswordLabel => 'Пароль';

  @override
  String get loginButton => 'Войти';

  @override
  String get loginError => 'Не удалось войти. Проверьте учётные данные и сервер.';

  @override
  String get validationRequired => 'Обязательно';

  @override
  String get loginConnectedServer => 'Подключённый сервер';

  @override
  String get loginNoServerConfigured => 'Сервер ещё не настроен';

  @override
  String loginServerDb(String dbName) {
    return 'БД: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'БД: -';

  @override
  String get loginChangeServer => 'Изменить сервер';

  @override
  String get loginPoweredBy => 'Работает на Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Укажите, какой сервер и базу данных Odoo должно использовать приложение.';

  @override
  String get serverConfigSectionConnectionDetails => 'Параметры подключения';

  @override
  String get serverConfigServerUrlLabel => 'URL сервера';

  @override
  String get serverConfigServerUrlHint => 'https://ваш-odoo-домен.com';

  @override
  String get serverConfigDbNameLabel => 'Имя базы данных';

  @override
  String get serverConfigSaveButton => 'Сохранить и продолжить';

  @override
  String get serverConfigSaveHint => 'Вы всегда можете изменить это позже на экране входа.';

  @override
  String get serverConfigDbAutoDetectError => 'Не удалось автоматически определить базу данных. Проверьте URL.';

  @override
  String get attendanceDetailsTitle => 'Детали посещаемости';

  @override
  String get employeeLabel => 'Сотрудник';

  @override
  String get statusOpen => 'ОТКРЫТО';

  @override
  String get statusClosed => 'ЗАКРЫТО';

  @override
  String get workedTimeLabel => 'Отработанное время';

  @override
  String get extraHoursLabel => 'Сверхурочные';

  @override
  String get checkInTitle => 'ВХОД';

  @override
  String get checkOutTitle => 'ВЫХОД';

  @override
  String get ipAddressLabel => 'IP-адрес';

  @override
  String get gpsCoordinatesLabel => 'GPS-координаты';

  @override
  String get unknownValue => 'Неизвестно';

  @override
  String get notAvailableValue => 'Недоступно';

  @override
  String get viewOnMaps => 'Открыть в картах';

  @override
  String get notCheckedOutYet => 'Выход не выполнен';

  @override
  String hoursValue(String hours) {
    return '$hours ч';
  }

  @override
  String get attendanceOnDuty => 'На смене';

  @override
  String get attendanceOffDuty => 'Не на смене';

  @override
  String get attendanceSwipeToCheckIn => 'Проведите, чтобы отметиться (вход)';

  @override
  String get attendanceSwipeToCheckOut => 'Проведите, чтобы отметиться (выход)';

  @override
  String get attendanceCurrentLocation => 'Текущее местоположение';

  @override
  String get attendanceRefresh => 'ОБНОВИТЬ';

  @override
  String get attendanceFetchingAddress => 'Получение адреса...';

  @override
  String get attendanceWaitingForGps => 'Ожидание GPS...';

  @override
  String get attendanceUploadSelfie => 'Загрузить селфи';

  @override
  String get attendanceLocationRequired => 'Для продолжения требуется местоположение.';

  @override
  String get attendanceCheckInSuccess => 'Добро пожаловать! Вход отмечен.';

  @override
  String get attendanceCheckOutSuccess => 'Смена завершена. Отличная работа!';

  @override
  String get attendanceCheckInFirst => 'Сначала отметьте вход.';

  @override
  String get attendanceSelfieUploaded => 'Селфи загружено';

  @override
  String get attendanceUploadFailed => 'Не удалось загрузить';

  @override
  String get attendanceCameraError => 'Ошибка камеры';

  @override
  String attendanceStartedAt(String time) {
    return 'Начато в $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Шир: $lat, Дол: $lng';
  }

  @override
  String get attendanceReadyToStart => 'Готовы начать смену';

  @override
  String get attendanceTitle => 'Посещаемость';

  @override
  String get attNavAttendance => 'Посещаемость';

  @override
  String get attNavHistory => 'История';

  @override
  String get attFiltersTitle => 'Фильтры посещаемости';

  @override
  String get attDateRangeLabel => 'Период';

  @override
  String get attStatusLabel => 'Статус';

  @override
  String get attFilterTooltip => 'Фильтр';

  @override
  String get attClearFilters => 'Сбросить фильтры';

  @override
  String get attApplyFilters => 'Применить';

  @override
  String get attFilterStatusAll => 'Все статусы';

  @override
  String get attFilterStatusOpen => 'Открыто (Вход)';

  @override
  String get attFilterStatusClosed => 'Закрыто (Выход)';

  @override
  String get attFilterRangeToday => 'Сегодня';

  @override
  String get attFilterRangeWeek => 'Эта неделя';

  @override
  String get attFilterRangeMonth => 'Этот месяц';

  @override
  String get attFilterRangeAll => 'За всё время';

  @override
  String attFilterDescription(String status, String range) {
    return '$status за $range';
  }

  @override
  String get attLoadingAttendance => 'Загрузка посещаемости…';

  @override
  String get attLoadingMore => 'Загрузка…';

  @override
  String get attFailedToLoad => 'Не удалось загрузить';

  @override
  String get attFailedToLoadMore => 'Не удалось загрузить ещё';

  @override
  String get attTryAgain => 'Повторить';

  @override
  String get attNoAttendanceTitle => 'Записей нет';

  @override
  String get attNoAttendanceSubtitle => 'Попробуйте изменить фильтры (период или статус).';

  @override
  String get attNoMoreItems => 'Вы дошли до конца списка.';

  @override
  String employeeFallback(String id) {
    return 'Сотрудник #$id';
  }

  @override
  String get attDetailsTitle => 'Детали посещаемости';

  @override
  String get attEmployeeLabel => 'Сотрудник';

  @override
  String get attWorkedTimeLabel => 'Отработанное время';

  @override
  String get attExtraHoursLabel => 'Сверхурочно';

  @override
  String get attCheckInSection => 'ВХОД';

  @override
  String get attCheckOutSection => 'ВЫХОД';

  @override
  String get attIpAddressLabel => 'IP-адрес';

  @override
  String get attGpsCoordinatesLabel => 'Координаты GPS';

  @override
  String get attViewOnMaps => 'Открыть в Maps';

  @override
  String get attUnknownValue => 'Неизвестно';

  @override
  String get attNotAvailableValue => 'Недоступно';

  @override
  String get attNotCheckedOutYet => 'Выход еще не отмечен';

  @override
  String get attZeroHours => '0.00 ч';
}
