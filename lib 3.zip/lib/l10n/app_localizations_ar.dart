// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get configureOdooServer => 'تكوين خادم Odoo';

  @override
  String get jobs => 'الوظائف';

  @override
  String get searchJobsHint => 'ابحث عن الوظائف...';

  @override
  String get sortBy => 'ترتيب حسب';

  @override
  String get sortScheduledNearest => 'المجدولة (الأقرب أولاً)';

  @override
  String get sortScheduledFarthest => 'المجدولة (الأبعد أولاً)';

  @override
  String get sortCustomerAZ => 'العميل (A-Z)';

  @override
  String get sortStatus => 'الحالة';

  @override
  String get tabAssigned => 'مُسندة';

  @override
  String get tabInProgress => 'قيد التنفيذ';

  @override
  String get tabDone => 'مكتملة';

  @override
  String get tabAll => 'الكل';

  @override
  String get emptyJobsTitle => 'لا توجد وظائف';

  @override
  String get emptyJobsSubtitle => 'جرّب تغيير البحث أو عوامل التصفية';

  @override
  String get emptyJobsAddButton => 'إضافة وظيفة جديدة';

  @override
  String get noSchedule => 'بدون موعد';

  @override
  String get statusDraft => 'مسودة';

  @override
  String get statusAssigned => 'مُسندة';

  @override
  String get statusInProgress => 'قيد التنفيذ';

  @override
  String get statusDone => 'مكتملة';

  @override
  String get statusCancelled => 'ملغاة';

  @override
  String get settingsTitle => 'إعدادات التطبيق';

  @override
  String get settingsAppearance => 'المظهر';

  @override
  String get settingsTheme => 'السمة';

  @override
  String get settingsThemeLight => 'فاتح';

  @override
  String get settingsThemeDark => 'داكن';

  @override
  String get settingsThemeSystem => 'النظام';

  @override
  String get settingsAccentColor => 'لون التمييز';

  @override
  String get settingsAccentColorPick => 'اختيار اللون';

  @override
  String get settingsAccentColorDialogTitle => 'اختر لونًا';

  @override
  String get settingsLanguageSection => 'اللغة والنص';

  @override
  String get settingsLanguageLabel => 'اللغة';

  @override
  String get settingsAboutSection => 'حول التطبيق';

  @override
  String get settingsVersionLabel => 'الإصدار';

  @override
  String get languageEnglish => 'الإنجليزية';

  @override
  String get languageArabic => 'العربية';

  @override
  String get navJobs => 'الوظائف';

  @override
  String get navCalendar => 'التقويم';

  @override
  String get navMap => 'الخريطة';

  @override
  String get navProfile => 'الملف الشخصي';

  @override
  String get profileSectionSettingsAndMore => 'الإعدادات والمزيد';

  @override
  String get profileSettingsTitle => 'الإعدادات';

  @override
  String get profileSettingsSubtitle => 'إعدادات التطبيق والسمة';

  @override
  String get profileLogoutTitle => 'تسجيل الخروج';

  @override
  String get profileLogoutSubtitle => 'تسجيل الخروج من حسابك';

  @override
  String get profileLoggedIn => 'تم تسجيل الدخول';

  @override
  String get jobDetailSchedule => 'الجدول';

  @override
  String get jobDetailStart => 'البدء';

  @override
  String get jobDetailEnd => 'الانتهاء';

  @override
  String get jobDetailDuration => 'المدة';

  @override
  String get jobDetailLocation => 'الموقع';

  @override
  String get jobDetailLatShort => 'خط العرض';

  @override
  String get jobDetailLngShort => 'خط الطول';

  @override
  String get jobDetailOpenInMaps => 'فتح في الخرائط';

  @override
  String get jobDetailNotes => 'الملاحظات';

  @override
  String get jobDetailCustomerNotes => 'ملاحظات العميل';

  @override
  String get jobDetailInternalNotes => 'ملاحظات داخلية';

  @override
  String get jobDetailPhotos => 'الصور';

  @override
  String get jobDetailAddPhotos => 'إضافة صور';

  @override
  String get jobDetailPhotosHint => 'اضغط في أي مكان داخل هذه البطاقة أو استخدم الزر لإضافة صور من الكاميرا أو المعرض.';

  @override
  String get jobDetailTakePhotoCamera => 'التقاط صورة (الكاميرا)';

  @override
  String get jobDetailChooseFromGallery => 'اختيار من المعرض';

  @override
  String get jobDetailAuth => 'التوثيق';

  @override
  String get jobDetailAuthTooltip => 'فتح شاشة التوثيق';

  @override
  String get jobDetailAuthHint => 'اضغط على هذه البطاقة لالتقاط توثيق العميل (التوقيع).';

  @override
  String get jobDetailAuthSavedSignature => 'التوقيع المحفوظ';

  @override
  String get jobDetailNoCustomer => 'لا يوجد عميل';

  @override
  String get jobDetailUnassigned => 'غير مُسند';

  @override
  String get jobDetailStartButton => 'بدء';

  @override
  String get jobDetailMarkDone => 'تحديد كمكتمل';

  @override
  String get jobDetailAssign => 'إسناد';

  @override
  String get jobDetailUpdateFailed => 'فشل تحديث المهمة';

  @override
  String get locationServicesDisabled => 'خدمات الموقع معطلة';

  @override
  String get locationPermissionDenied => 'تم رفض إذن الموقع';

  @override
  String get jobDetailStartFailed => 'فشل بدء المهمة';

  @override
  String get jobDetailNoLocationData => 'لا توجد بيانات GPS أو عنوان لهذه المهمة';

  @override
  String get jobDetailNoAddress => 'لا يوجد عنوان لهذه المهمة';

  @override
  String get jobDetailMapOpenFailed => 'تعذر فتح تطبيق الخرائط';

  @override
  String get jobDetailMapError => 'فشل فتح الخرائط';

  @override
  String get jobDetailPhotosUploaded => 'تم رفع صورة/صور';

  @override
  String get jobDetailPhotosUploadFailed => 'فشل رفع الصور';

  @override
  String get authSaved => 'تم حفظ التوثيق';

  @override
  String get authSaveFailed => 'فشل حفظ التوقيع';

  @override
  String get authSignInstruction => 'اطلب من العميل التوقيع داخل المربع أدناه.';

  @override
  String get photoViewerTitle => 'الصورة';

  @override
  String get commonRefresh => 'تحديث';

  @override
  String get commonClear => 'مسح';

  @override
  String get commonCancel => 'إلغاء';

  @override
  String get commonSave => 'حفظ';

  @override
  String get addJobTitle => 'مهمة جديدة';

  @override
  String get addJobJobTitleLabel => 'عنوان المهمة';

  @override
  String get addJobJobTitleHint => 'مثال: صيانة المكيف – فيلا 12B';

  @override
  String get addJobJobTitleRequired => 'يرجى إدخال عنوان المهمة';

  @override
  String get addJobScheduledLabel => 'تاريخ ووقت الجدولة';

  @override
  String get addJobDateTimeNotSet => 'غير محدد';

  @override
  String get addJobCustomerNotesLabel => 'ملاحظات العميل (اختياري)';

  @override
  String get addJobCustomerNotesHint => 'ملاحظات من العميل، معلومات الدخول، إلخ.';

  @override
  String get addJobInternalNotesLabel => 'ملاحظات داخلية (اختياري)';

  @override
  String get addJobInternalNotesHint => 'ملاحظات لفريقك فقط';

  @override
  String get addJobCreateButton => 'إنشاء مهمة';

  @override
  String get addJobCreated => 'تم إنشاء المهمة';

  @override
  String get addJobCreateFailed => 'فشل إنشاء المهمة';

  @override
  String get calendarRefreshTooltip => 'تحديث المهام';

  @override
  String get calendarJobsOnPrefix => 'المهام بتاريخ';

  @override
  String get calendarNoJobsOnDay => 'لا توجد مهام في هذا اليوم';

  @override
  String get mapTitle => 'خريطة المهام';

  @override
  String get mapEmptyTitle => 'لا توجد مهام لعرضها على الخريطة';

  @override
  String get mapBottomTitle => 'المهام على الخريطة';

  @override
  String get mapJobsLabel => 'مهام';

  @override
  String get myJobsTitle => 'مهامي';

  @override
  String get mapYouAreHere => 'أنت هنا';

  @override
  String get loginWelcomeBack => 'أهلاً بعودتك';

  @override
  String get loginSubtitle => 'سجّل الدخول لإدارة مهام الخدمة الميدانية.';

  @override
  String get loginDetailsTitle => 'بيانات تسجيل الدخول';

  @override
  String get loginEmailLabel => 'البريد الإلكتروني / اسم الدخول';

  @override
  String get loginPasswordLabel => 'كلمة المرور';

  @override
  String get loginButton => 'تسجيل الدخول';

  @override
  String get loginError => 'فشل تسجيل الدخول. تحقّق من البيانات والخادم.';

  @override
  String get validationRequired => 'مطلوب';

  @override
  String get loginConnectedServer => 'الخادم المتصل';

  @override
  String get loginNoServerConfigured => 'لم يتم إعداد خادم بعد';

  @override
  String loginServerDb(String dbName) {
    return 'قاعدة البيانات: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'قاعدة البيانات: -';

  @override
  String get loginChangeServer => 'تغيير الخادم';

  @override
  String get loginPoweredBy => 'بدعم من Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'حدد للتطبيق خادم Odoo وقاعدة البيانات التي سيستخدمها.';

  @override
  String get serverConfigSectionConnectionDetails => 'تفاصيل الاتصال';

  @override
  String get serverConfigServerUrlLabel => 'رابط الخادم';

  @override
  String get serverConfigServerUrlHint => 'https://your-odoo-domain.com';

  @override
  String get serverConfigDbNameLabel => 'اسم قاعدة البيانات';

  @override
  String get serverConfigSaveButton => 'حفظ والمتابعة';

  @override
  String get serverConfigSaveHint => 'يمكنك تغيير ذلك لاحقًا من شاشة تسجيل الدخول.';

  @override
  String get serverConfigDbAutoDetectError => 'تعذر اكتشاف قاعدة البيانات تلقائيًا. يرجى التحقق من الرابط.';

  @override
  String get attendanceDetailsTitle => 'تفاصيل الحضور';

  @override
  String get employeeLabel => 'الموظف';

  @override
  String get statusOpen => 'مفتوح';

  @override
  String get statusClosed => 'مغلق';

  @override
  String get workedTimeLabel => 'وقت العمل';

  @override
  String get extraHoursLabel => 'ساعات إضافية';

  @override
  String get checkInTitle => 'تسجيل الدخول';

  @override
  String get checkOutTitle => 'تسجيل الخروج';

  @override
  String get ipAddressLabel => 'عنوان IP';

  @override
  String get gpsCoordinatesLabel => 'إحداثيات GPS';

  @override
  String get unknownValue => 'غير معروف';

  @override
  String get notAvailableValue => 'غير متوفر';

  @override
  String get viewOnMaps => 'عرض على الخريطة';

  @override
  String get notCheckedOutYet => 'لم يتم تسجيل الخروج بعد';

  @override
  String hoursValue(String hours) {
    return '$hours ساعة';
  }

  @override
  String get attendanceOnDuty => 'على رأس العمل';

  @override
  String get attendanceOffDuty => 'خارج العمل';

  @override
  String get attendanceSwipeToCheckIn => 'اسحب لتسجيل الدخول';

  @override
  String get attendanceSwipeToCheckOut => 'اسحب لتسجيل الخروج';

  @override
  String get attendanceCurrentLocation => 'الموقع الحالي';

  @override
  String get attendanceRefresh => 'تحديث';

  @override
  String get attendanceFetchingAddress => 'جارٍ جلب العنوان...';

  @override
  String get attendanceWaitingForGps => 'بانتظار GPS...';

  @override
  String get attendanceUploadSelfie => 'رفع سيلفي';

  @override
  String get attendanceLocationRequired => 'الموقع مطلوب للمتابعة.';

  @override
  String get attendanceCheckInSuccess => 'مرحباً! تم تسجيل الدخول.';

  @override
  String get attendanceCheckOutSuccess => 'انتهى الدوام. أحسنت!';

  @override
  String get attendanceCheckInFirst => 'يرجى تسجيل الدخول أولاً.';

  @override
  String get attendanceSelfieUploaded => 'تم رفع السيلفي';

  @override
  String get attendanceUploadFailed => 'فشل الرفع';

  @override
  String get attendanceCameraError => 'خطأ في الكاميرا';

  @override
  String attendanceStartedAt(String time) {
    return 'بدأ في $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'خط العرض: $lat، خط الطول: $lng';
  }

  @override
  String get attendanceReadyToStart => 'جاهز لبدء الدوام';

  @override
  String get attendanceTitle => 'الحضور';

  @override
  String get attNavAttendance => 'الحضور';

  @override
  String get attNavHistory => 'السجل';

  @override
  String get attFiltersTitle => 'فلاتر الحضور';

  @override
  String get attDateRangeLabel => 'نطاق التاريخ';

  @override
  String get attStatusLabel => 'الحالة';

  @override
  String get attFilterTooltip => 'تصفية';

  @override
  String get attClearFilters => 'مسح الفلاتر';

  @override
  String get attApplyFilters => 'تطبيق الفلاتر';

  @override
  String get attFilterStatusAll => 'كل الحالات';

  @override
  String get attFilterStatusOpen => 'مفتوح (تم تسجيل الدخول)';

  @override
  String get attFilterStatusClosed => 'مغلق (تم تسجيل الخروج)';

  @override
  String get attFilterRangeToday => 'اليوم';

  @override
  String get attFilterRangeWeek => 'هذا الأسبوع';

  @override
  String get attFilterRangeMonth => 'هذا الشهر';

  @override
  String get attFilterRangeAll => 'كل الوقت';

  @override
  String attFilterDescription(String status, String range) {
    return '$status خلال $range';
  }

  @override
  String get attLoadingAttendance => 'جارٍ تحميل الحضور…';

  @override
  String get attLoadingMore => 'جارٍ تحميل المزيد…';

  @override
  String get attFailedToLoad => 'فشل تحميل الحضور';

  @override
  String get attFailedToLoadMore => 'فشل تحميل المزيد';

  @override
  String get attTryAgain => 'حاول مرة أخرى';

  @override
  String get attNoAttendanceTitle => 'لم يتم العثور على حضور';

  @override
  String get attNoAttendanceSubtitle => 'جرّب تعديل الفلاتر (نطاق التاريخ أو الحالة).';

  @override
  String get attNoMoreItems => 'لقد وصلت إلى نهاية القائمة.';

  @override
  String employeeFallback(String id) {
    return 'الموظف #$id';
  }

  @override
  String get attDetailsTitle => 'تفاصيل الحضور';

  @override
  String get attEmployeeLabel => 'الموظف';

  @override
  String get attWorkedTimeLabel => 'وقت العمل';

  @override
  String get attExtraHoursLabel => 'ساعات إضافية';

  @override
  String get attCheckInSection => 'تسجيل الدخول';

  @override
  String get attCheckOutSection => 'تسجيل الخروج';

  @override
  String get attIpAddressLabel => 'عنوان IP';

  @override
  String get attGpsCoordinatesLabel => 'إحداثيات GPS';

  @override
  String get attViewOnMaps => 'عرض على الخريطة';

  @override
  String get attUnknownValue => 'غير معروف';

  @override
  String get attNotAvailableValue => 'غير متوفر';

  @override
  String get attNotCheckedOutYet => 'لم يتم تسجيل الخروج بعد';

  @override
  String get attZeroHours => '0.00 ساعة';
}
