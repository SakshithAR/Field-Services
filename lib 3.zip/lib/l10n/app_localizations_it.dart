// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Italian (`it`).
class AppLocalizationsIt extends AppLocalizations {
  AppLocalizationsIt([String locale = 'it']) : super(locale);

  @override
  String get configureOdooServer => 'Configura server Odoo';

  @override
  String get jobs => 'Interventi';

  @override
  String get searchJobsHint => 'Cerca interventi...';

  @override
  String get sortBy => 'Ordina per';

  @override
  String get sortScheduledNearest => 'Pianificati (più vicini per primi)';

  @override
  String get sortScheduledFarthest => 'Pianificati (più lontani per primi)';

  @override
  String get sortCustomerAZ => 'Cliente (A-Z)';

  @override
  String get sortStatus => 'Stato';

  @override
  String get tabAssigned => 'Assegnati';

  @override
  String get tabInProgress => 'In corso';

  @override
  String get tabDone => 'Completati';

  @override
  String get tabAll => 'Tutti';

  @override
  String get emptyJobsTitle => 'Nessun intervento';

  @override
  String get emptyJobsSubtitle => 'Prova a modificare la ricerca o i filtri';

  @override
  String get emptyJobsAddButton => 'Aggiungi nuovo intervento';

  @override
  String get noSchedule => 'Nessuna pianificazione';

  @override
  String get statusDraft => 'Bozza';

  @override
  String get statusAssigned => 'Assegnato';

  @override
  String get statusInProgress => 'In corso';

  @override
  String get statusDone => 'Completato';

  @override
  String get statusCancelled => 'Annullato';

  @override
  String get settingsTitle => 'Impostazioni app';

  @override
  String get settingsAppearance => 'Aspetto';

  @override
  String get settingsTheme => 'Tema';

  @override
  String get settingsThemeLight => 'Chiaro';

  @override
  String get settingsThemeDark => 'Scuro';

  @override
  String get settingsThemeSystem => 'Sistema';

  @override
  String get settingsAccentColor => 'Colore di accento';

  @override
  String get settingsAccentColorPick => 'Scegli colore';

  @override
  String get settingsAccentColorDialogTitle => 'Scegli un colore';

  @override
  String get settingsLanguageSection => 'Lingua e testo';

  @override
  String get settingsLanguageLabel => 'Lingua';

  @override
  String get settingsAboutSection => 'Informazioni sull\'app';

  @override
  String get settingsVersionLabel => 'Versione';

  @override
  String get languageEnglish => 'Inglese';

  @override
  String get languageArabic => 'Arabo';

  @override
  String get navJobs => 'Interventi';

  @override
  String get navCalendar => 'Calendario';

  @override
  String get navMap => 'Mappa';

  @override
  String get navProfile => 'Profilo';

  @override
  String get profileSectionSettingsAndMore => 'Impostazioni e altro';

  @override
  String get profileSettingsTitle => 'Impostazioni';

  @override
  String get profileSettingsSubtitle => 'Impostazioni dell\'app e del tema';

  @override
  String get profileLogoutTitle => 'Disconnetti';

  @override
  String get profileLogoutSubtitle => 'Esci dal tuo account';

  @override
  String get profileLoggedIn => 'Accesso effettuato';

  @override
  String get jobDetailSchedule => 'Pianificazione';

  @override
  String get jobDetailStart => 'Inizio';

  @override
  String get jobDetailEnd => 'Fine';

  @override
  String get jobDetailDuration => 'Durata';

  @override
  String get jobDetailLocation => 'Posizione';

  @override
  String get jobDetailLatShort => 'Lat';

  @override
  String get jobDetailLngShort => 'Lng';

  @override
  String get jobDetailOpenInMaps => 'Apri in Maps';

  @override
  String get jobDetailNotes => 'Note';

  @override
  String get jobDetailCustomerNotes => 'Note del cliente';

  @override
  String get jobDetailInternalNotes => 'Note interne';

  @override
  String get jobDetailPhotos => 'Foto';

  @override
  String get jobDetailAddPhotos => 'Aggiungi foto';

  @override
  String get jobDetailPhotosHint => 'Tocca in qualsiasi punto di questa scheda o usa il pulsante per aggiungere foto dalla fotocamera o dalla galleria.';

  @override
  String get jobDetailTakePhotoCamera => 'Scatta foto (fotocamera)';

  @override
  String get jobDetailChooseFromGallery => 'Scegli dalla galleria';

  @override
  String get jobDetailAuth => 'Autenticazione';

  @override
  String get jobDetailAuthTooltip => 'Apri autenticazione';

  @override
  String get jobDetailAuthHint => 'Tocca questa scheda per acquisire l\'autenticazione del cliente (firma).';

  @override
  String get jobDetailAuthSavedSignature => 'Firma salvata';

  @override
  String get jobDetailNoCustomer => 'Nessun cliente';

  @override
  String get jobDetailUnassigned => 'Non assegnato';

  @override
  String get jobDetailStartButton => 'Avvia';

  @override
  String get jobDetailMarkDone => 'Segna come completato';

  @override
  String get jobDetailAssign => 'Assegna';

  @override
  String get jobDetailUpdateFailed => 'Impossibile aggiornare l\'intervento';

  @override
  String get locationServicesDisabled => 'I servizi di localizzazione sono disattivati';

  @override
  String get locationPermissionDenied => 'Autorizzazione alla posizione negata';

  @override
  String get jobDetailStartFailed => 'Impossibile avviare l\'intervento';

  @override
  String get jobDetailNoLocationData => 'Nessun GPS o indirizzo disponibile per questo intervento';

  @override
  String get jobDetailNoAddress => 'Nessun indirizzo disponibile per questo intervento';

  @override
  String get jobDetailMapOpenFailed => 'Impossibile aprire l\'app mappe';

  @override
  String get jobDetailMapError => 'Errore durante l\'apertura delle mappe';

  @override
  String get jobDetailPhotosUploaded => 'foto caricate';

  @override
  String get jobDetailPhotosUploadFailed => 'Errore nel caricamento delle foto';

  @override
  String get authSaved => 'Autenticazione salvata';

  @override
  String get authSaveFailed => 'Errore nel salvataggio della firma';

  @override
  String get authSignInstruction => 'Chiedi al cliente di firmare all\'interno del riquadro qui sotto.';

  @override
  String get photoViewerTitle => 'Foto';

  @override
  String get commonRefresh => 'Aggiorna';

  @override
  String get commonClear => 'Cancella';

  @override
  String get commonCancel => 'Annulla';

  @override
  String get commonSave => 'Salva';

  @override
  String get addJobTitle => 'Nuovo intervento';

  @override
  String get addJobJobTitleLabel => 'Titolo intervento';

  @override
  String get addJobJobTitleHint => 'Es: Manutenzione AC – Villa 12B';

  @override
  String get addJobJobTitleRequired => 'Inserisci il titolo dell\'intervento';

  @override
  String get addJobScheduledLabel => 'Data e ora pianificate';

  @override
  String get addJobDateTimeNotSet => 'Non impostato';

  @override
  String get addJobCustomerNotesLabel => 'Note del cliente (facoltativo)';

  @override
  String get addJobCustomerNotesHint => 'Note del cliente, informazioni di accesso, ecc.';

  @override
  String get addJobInternalNotesLabel => 'Note interne (facoltativo)';

  @override
  String get addJobInternalNotesHint => 'Note solo per il tuo team';

  @override
  String get addJobCreateButton => 'Crea intervento';

  @override
  String get addJobCreated => 'Intervento creato';

  @override
  String get addJobCreateFailed => 'Errore nella creazione dell\'intervento';

  @override
  String get calendarRefreshTooltip => 'Aggiorna interventi';

  @override
  String get calendarJobsOnPrefix => 'Interventi il';

  @override
  String get calendarNoJobsOnDay => 'Nessun intervento in questo giorno';

  @override
  String get mapTitle => 'Mappa interventi';

  @override
  String get mapEmptyTitle => 'Nessun intervento da mostrare sulla mappa';

  @override
  String get mapBottomTitle => 'Interventi sulla mappa';

  @override
  String get mapJobsLabel => 'interventi';

  @override
  String get myJobsTitle => 'I miei interventi';

  @override
  String get mapYouAreHere => 'Ti trovi qui';

  @override
  String get loginWelcomeBack => 'Bentornato';

  @override
  String get loginSubtitle => 'Accedi per gestire i tuoi interventi di assistenza sul campo.';

  @override
  String get loginDetailsTitle => 'Dati di accesso';

  @override
  String get loginEmailLabel => 'Email / Login';

  @override
  String get loginPasswordLabel => 'Password';

  @override
  String get loginButton => 'Accedi';

  @override
  String get loginError => 'Accesso non riuscito. Controlla credenziali e server.';

  @override
  String get validationRequired => 'Obbligatorio';

  @override
  String get loginConnectedServer => 'Server connesso';

  @override
  String get loginNoServerConfigured => 'Nessun server ancora configurato';

  @override
  String loginServerDb(String dbName) {
    return 'DB: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'DB: -';

  @override
  String get loginChangeServer => 'Cambia server';

  @override
  String get loginPoweredBy => 'Basato su Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Indica all\'app quale server e database Odoo utilizzare.';

  @override
  String get serverConfigSectionConnectionDetails => 'Dettagli di connessione';

  @override
  String get serverConfigServerUrlLabel => 'URL del server';

  @override
  String get serverConfigServerUrlHint => 'https://il-tuo-dominio-odoo.com';

  @override
  String get serverConfigDbNameLabel => 'Nome del database';

  @override
  String get serverConfigSaveButton => 'Salva e continua';

  @override
  String get serverConfigSaveHint => 'Puoi sempre modificarlo in seguito dalla schermata di accesso.';

  @override
  String get serverConfigDbAutoDetectError => 'Impossibile rilevare automaticamente il database. Controlla l\'URL.';

  @override
  String get attendanceDetailsTitle => 'Dettagli presenze';

  @override
  String get employeeLabel => 'Dipendente';

  @override
  String get statusOpen => 'APERTO';

  @override
  String get statusClosed => 'CHIUSO';

  @override
  String get workedTimeLabel => 'Tempo lavorato';

  @override
  String get extraHoursLabel => 'Ore extra';

  @override
  String get checkInTitle => 'ENTRATA';

  @override
  String get checkOutTitle => 'USCITA';

  @override
  String get ipAddressLabel => 'Indirizzo IP';

  @override
  String get gpsCoordinatesLabel => 'Coordinate GPS';

  @override
  String get unknownValue => 'Sconosciuto';

  @override
  String get notAvailableValue => 'Non disponibile';

  @override
  String get viewOnMaps => 'Vedi su Maps';

  @override
  String get notCheckedOutYet => 'Non ha ancora effettuato l’uscita';

  @override
  String hoursValue(String hours) {
    return '$hours ore';
  }

  @override
  String get attendanceOnDuty => 'In servizio';

  @override
  String get attendanceOffDuty => 'Fuori servizio';

  @override
  String get attendanceSwipeToCheckIn => 'Scorri per fare check-in';

  @override
  String get attendanceSwipeToCheckOut => 'Scorri per fare check-out';

  @override
  String get attendanceCurrentLocation => 'Posizione attuale';

  @override
  String get attendanceRefresh => 'AGGIORNA';

  @override
  String get attendanceFetchingAddress => 'Recupero indirizzo...';

  @override
  String get attendanceWaitingForGps => 'In attesa del GPS...';

  @override
  String get attendanceUploadSelfie => 'Carica selfie';

  @override
  String get attendanceLocationRequired => 'La posizione è necessaria per procedere.';

  @override
  String get attendanceCheckInSuccess => 'Benvenuto! Check-in registrato.';

  @override
  String get attendanceCheckOutSuccess => 'Turno terminato. Ottimo lavoro!';

  @override
  String get attendanceCheckInFirst => 'Esegui prima il check-in.';

  @override
  String get attendanceSelfieUploaded => 'Selfie caricato';

  @override
  String get attendanceUploadFailed => 'Caricamento non riuscito';

  @override
  String get attendanceCameraError => 'Errore fotocamera';

  @override
  String attendanceStartedAt(String time) {
    return 'Iniziato alle $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Lat: $lat, Lng: $lng';
  }

  @override
  String get attendanceReadyToStart => 'Pronto per iniziare il turno';

  @override
  String get attendanceTitle => 'Presenze';

  @override
  String get attNavAttendance => 'Presenze';

  @override
  String get attNavHistory => 'Cronologia';

  @override
  String get attFiltersTitle => 'Filtri presenze';

  @override
  String get attDateRangeLabel => 'Intervallo date';

  @override
  String get attStatusLabel => 'Stato';

  @override
  String get attFilterTooltip => 'Filtra';

  @override
  String get attClearFilters => 'Cancella filtri';

  @override
  String get attApplyFilters => 'Applica filtri';

  @override
  String get attFilterStatusAll => 'Tutti gli stati';

  @override
  String get attFilterStatusOpen => 'Aperto (Check-in)';

  @override
  String get attFilterStatusClosed => 'Chiuso (Check-out)';

  @override
  String get attFilterRangeToday => 'Oggi';

  @override
  String get attFilterRangeWeek => 'Questa settimana';

  @override
  String get attFilterRangeMonth => 'Questo mese';

  @override
  String get attFilterRangeAll => 'Sempre';

  @override
  String attFilterDescription(String status, String range) {
    return '$status per $range';
  }

  @override
  String get attLoadingAttendance => 'Caricamento presenze…';

  @override
  String get attLoadingMore => 'Caricamento…';

  @override
  String get attFailedToLoad => 'Impossibile caricare le presenze';

  @override
  String get attFailedToLoadMore => 'Impossibile caricare altro';

  @override
  String get attTryAgain => 'Riprova';

  @override
  String get attNoAttendanceTitle => 'Nessuna presenza trovata';

  @override
  String get attNoAttendanceSubtitle => 'Prova a modificare i filtri (date o stato).';

  @override
  String get attNoMoreItems => 'Hai raggiunto la fine della lista.';

  @override
  String employeeFallback(String id) {
    return 'Dipendente #$id';
  }

  @override
  String get attDetailsTitle => 'Dettagli presenza';

  @override
  String get attEmployeeLabel => 'Dipendente';

  @override
  String get attWorkedTimeLabel => 'Tempo lavorato';

  @override
  String get attExtraHoursLabel => 'Ore extra';

  @override
  String get attCheckInSection => 'ENTRATA';

  @override
  String get attCheckOutSection => 'USCITA';

  @override
  String get attIpAddressLabel => 'Indirizzo IP';

  @override
  String get attGpsCoordinatesLabel => 'Coordinate GPS';

  @override
  String get attViewOnMaps => 'Vedi su Maps';

  @override
  String get attUnknownValue => 'Sconosciuto';

  @override
  String get attNotAvailableValue => 'Non disponibile';

  @override
  String get attNotCheckedOutYet => 'Uscita non ancora registrata';

  @override
  String get attZeroHours => '0.00 ore';
}
