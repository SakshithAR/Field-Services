// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get configureOdooServer => '配置 Odoo 服务器';

  @override
  String get jobs => '工单';

  @override
  String get searchJobsHint => '搜索工单...';

  @override
  String get sortBy => '排序方式';

  @override
  String get sortScheduledNearest => '按计划时间（最近优先）';

  @override
  String get sortScheduledFarthest => '按计划时间（最远优先）';

  @override
  String get sortCustomerAZ => '客户（A-Z）';

  @override
  String get sortStatus => '状态';

  @override
  String get tabAssigned => '已分配';

  @override
  String get tabInProgress => '进行中';

  @override
  String get tabDone => '已完成';

  @override
  String get tabAll => '全部';

  @override
  String get emptyJobsTitle => '没有工单';

  @override
  String get emptyJobsSubtitle => '请尝试更改搜索条件或筛选器';

  @override
  String get emptyJobsAddButton => '添加新工单';

  @override
  String get noSchedule => '未安排时间';

  @override
  String get statusDraft => '草稿';

  @override
  String get statusAssigned => '已分配';

  @override
  String get statusInProgress => '进行中';

  @override
  String get statusDone => '已完成';

  @override
  String get statusCancelled => '已取消';

  @override
  String get settingsTitle => '应用设置';

  @override
  String get settingsAppearance => '外观';

  @override
  String get settingsTheme => '主题';

  @override
  String get settingsThemeLight => '浅色';

  @override
  String get settingsThemeDark => '深色';

  @override
  String get settingsThemeSystem => '跟随系统';

  @override
  String get settingsAccentColor => '强调颜色';

  @override
  String get settingsAccentColorPick => '选择颜色';

  @override
  String get settingsAccentColorDialogTitle => '请选择颜色';

  @override
  String get settingsLanguageSection => '语言和文本';

  @override
  String get settingsLanguageLabel => '语言';

  @override
  String get settingsAboutSection => '关于应用';

  @override
  String get settingsVersionLabel => '版本';

  @override
  String get languageEnglish => '英语';

  @override
  String get languageArabic => '阿拉伯语';

  @override
  String get navJobs => '工单';

  @override
  String get navCalendar => '日历';

  @override
  String get navMap => '地图';

  @override
  String get navProfile => '个人资料';

  @override
  String get profileSectionSettingsAndMore => '设置与更多';

  @override
  String get profileSettingsTitle => '设置';

  @override
  String get profileSettingsSubtitle => '应用和主题设置';

  @override
  String get profileLogoutTitle => '退出登录';

  @override
  String get profileLogoutSubtitle => '退出当前账号';

  @override
  String get profileLoggedIn => '已登录';

  @override
  String get jobDetailSchedule => '计划';

  @override
  String get jobDetailStart => '开始';

  @override
  String get jobDetailEnd => '结束';

  @override
  String get jobDetailDuration => '时长';

  @override
  String get jobDetailLocation => '位置';

  @override
  String get jobDetailLatShort => '纬度';

  @override
  String get jobDetailLngShort => '经度';

  @override
  String get jobDetailOpenInMaps => '在地图中打开';

  @override
  String get jobDetailNotes => '备注';

  @override
  String get jobDetailCustomerNotes => '客户备注';

  @override
  String get jobDetailInternalNotes => '内部备注';

  @override
  String get jobDetailPhotos => '照片';

  @override
  String get jobDetailAddPhotos => '添加照片';

  @override
  String get jobDetailPhotosHint => '点击此卡片任意位置，或使用按钮从相机或相册添加照片。';

  @override
  String get jobDetailTakePhotoCamera => '拍照（相机）';

  @override
  String get jobDetailChooseFromGallery => '从相册选择';

  @override
  String get jobDetailAuth => '确认';

  @override
  String get jobDetailAuthTooltip => '打开确认界面';

  @override
  String get jobDetailAuthHint => '点击此卡片以采集客户确认（签名）。';

  @override
  String get jobDetailAuthSavedSignature => '已保存的签名';

  @override
  String get jobDetailNoCustomer => '无客户';

  @override
  String get jobDetailUnassigned => '未分配';

  @override
  String get jobDetailStartButton => '开始';

  @override
  String get jobDetailMarkDone => '标记为完成';

  @override
  String get jobDetailAssign => '分配';

  @override
  String get jobDetailUpdateFailed => '更新工单失败';

  @override
  String get locationServicesDisabled => '定位服务已关闭';

  @override
  String get locationPermissionDenied => '定位权限被拒绝';

  @override
  String get jobDetailStartFailed => '启动工单失败';

  @override
  String get jobDetailNoLocationData => '此工单没有可用的 GPS 或地址信息';

  @override
  String get jobDetailNoAddress => '此工单没有可用地址';

  @override
  String get jobDetailMapOpenFailed => '无法打开地图应用';

  @override
  String get jobDetailMapError => '打开地图失败';

  @override
  String get jobDetailPhotosUploaded => '照片已上传';

  @override
  String get jobDetailPhotosUploadFailed => '上传照片失败';

  @override
  String get authSaved => '确认信息已保存';

  @override
  String get authSaveFailed => '保存签名失败';

  @override
  String get authSignInstruction => '请让客户在下面的框内签名。';

  @override
  String get photoViewerTitle => '照片';

  @override
  String get commonRefresh => '刷新';

  @override
  String get commonClear => '清除';

  @override
  String get commonCancel => '取消';

  @override
  String get commonSave => '保存';

  @override
  String get addJobTitle => '新工单';

  @override
  String get addJobJobTitleLabel => '工单标题';

  @override
  String get addJobJobTitleHint => '例如：空调维护 – 12B 别墅';

  @override
  String get addJobJobTitleRequired => '请输入工单标题';

  @override
  String get addJobScheduledLabel => '计划日期和时间';

  @override
  String get addJobDateTimeNotSet => '未设置';

  @override
  String get addJobCustomerNotesLabel => '客户备注（可选）';

  @override
  String get addJobCustomerNotesHint => '来自客户的备注、门禁信息等。';

  @override
  String get addJobInternalNotesLabel => '内部备注（可选）';

  @override
  String get addJobInternalNotesHint => '仅供团队内部查看的备注';

  @override
  String get addJobCreateButton => '创建工单';

  @override
  String get addJobCreated => '工单已创建';

  @override
  String get addJobCreateFailed => '创建工单失败';

  @override
  String get calendarRefreshTooltip => '刷新工单';

  @override
  String get calendarJobsOnPrefix => '工单日期';

  @override
  String get calendarNoJobsOnDay => '这一天没有工单';

  @override
  String get mapTitle => '工单地图';

  @override
  String get mapEmptyTitle => '没有可在地图上显示的工单';

  @override
  String get mapBottomTitle => '地图上的工单';

  @override
  String get mapJobsLabel => '个工单';

  @override
  String get myJobsTitle => '我的工单';

  @override
  String get mapYouAreHere => '您在这里';

  @override
  String get loginWelcomeBack => '欢迎回来';

  @override
  String get loginSubtitle => '登录以管理您的现场服务工单。';

  @override
  String get loginDetailsTitle => '登录信息';

  @override
  String get loginEmailLabel => '邮箱 / 登录名';

  @override
  String get loginPasswordLabel => '密码';

  @override
  String get loginButton => '登录';

  @override
  String get loginError => '登录失败。请检查凭据和服务器配置。';

  @override
  String get validationRequired => '必填';

  @override
  String get loginConnectedServer => '已连接的服务器';

  @override
  String get loginNoServerConfigured => '尚未配置服务器';

  @override
  String loginServerDb(String dbName) {
    return '数据库：$dbName';
  }

  @override
  String get loginServerDbEmpty => '数据库：-';

  @override
  String get loginChangeServer => '更改服务器';

  @override
  String get loginPoweredBy => '由 Taqnix Field Service 提供支持';

  @override
  String get serverConfigSubtitle => '告诉应用要使用哪台 Odoo 服务器和数据库。';

  @override
  String get serverConfigSectionConnectionDetails => '连接详情';

  @override
  String get serverConfigServerUrlLabel => '服务器 URL';

  @override
  String get serverConfigServerUrlHint => 'https://your-odoo-domain.com';

  @override
  String get serverConfigDbNameLabel => '数据库名称';

  @override
  String get serverConfigSaveButton => '保存并继续';

  @override
  String get serverConfigSaveHint => '您稍后可以随时在登录界面更改这些设置。';

  @override
  String get serverConfigDbAutoDetectError => '无法自动检测数据库。请检查 URL。';

  @override
  String get attendanceDetailsTitle => '出勤详情';

  @override
  String get employeeLabel => '员工';

  @override
  String get statusOpen => '开启';

  @override
  String get statusClosed => '关闭';

  @override
  String get workedTimeLabel => '工作时长';

  @override
  String get extraHoursLabel => '加班时长';

  @override
  String get checkInTitle => '签到';

  @override
  String get checkOutTitle => '签退';

  @override
  String get ipAddressLabel => 'IP 地址';

  @override
  String get gpsCoordinatesLabel => 'GPS 坐标';

  @override
  String get unknownValue => '未知';

  @override
  String get notAvailableValue => '不可用';

  @override
  String get viewOnMaps => '在地图中查看';

  @override
  String get notCheckedOutYet => '尚未签退';

  @override
  String hoursValue(String hours) {
    return '$hours 小时';
  }

  @override
  String get attendanceOnDuty => '上班中';

  @override
  String get attendanceOffDuty => '未上班';

  @override
  String get attendanceSwipeToCheckIn => '滑动签到';

  @override
  String get attendanceSwipeToCheckOut => '滑动签退';

  @override
  String get attendanceCurrentLocation => '当前位置';

  @override
  String get attendanceRefresh => '刷新';

  @override
  String get attendanceFetchingAddress => '正在获取地址...';

  @override
  String get attendanceWaitingForGps => '正在等待 GPS...';

  @override
  String get attendanceUploadSelfie => '上传自拍';

  @override
  String get attendanceLocationRequired => '需要定位才能继续。';

  @override
  String get attendanceCheckInSuccess => '欢迎！已记录签到。';

  @override
  String get attendanceCheckOutSuccess => '已结束班次。干得好！';

  @override
  String get attendanceCheckInFirst => '请先签到。';

  @override
  String get attendanceSelfieUploaded => '自拍已上传';

  @override
  String get attendanceUploadFailed => '上传失败';

  @override
  String get attendanceCameraError => '相机错误';

  @override
  String attendanceStartedAt(String time) {
    return '开始时间：$time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return '纬度：$lat，经度：$lng';
  }

  @override
  String get attendanceReadyToStart => '准备开始上班';

  @override
  String get attendanceTitle => '考勤';

  @override
  String get attNavAttendance => '考勤';

  @override
  String get attNavHistory => '历史记录';

  @override
  String get attFiltersTitle => '考勤筛选';

  @override
  String get attDateRangeLabel => '日期范围';

  @override
  String get attStatusLabel => '状态';

  @override
  String get attFilterTooltip => '筛选';

  @override
  String get attClearFilters => '清除筛选';

  @override
  String get attApplyFilters => '应用筛选';

  @override
  String get attFilterStatusAll => '全部状态';

  @override
  String get attFilterStatusOpen => '开启（已签到）';

  @override
  String get attFilterStatusClosed => '关闭（已签退）';

  @override
  String get attFilterRangeToday => '今天';

  @override
  String get attFilterRangeWeek => '本周';

  @override
  String get attFilterRangeMonth => '本月';

  @override
  String get attFilterRangeAll => '全部时间';

  @override
  String attFilterDescription(String status, String range) {
    return '$range 的 $status';
  }

  @override
  String get attLoadingAttendance => '正在加载考勤…';

  @override
  String get attLoadingMore => '正在加载更多…';

  @override
  String get attFailedToLoad => '加载考勤失败';

  @override
  String get attFailedToLoadMore => '加载更多失败';

  @override
  String get attTryAgain => '重试';

  @override
  String get attNoAttendanceTitle => '未找到考勤记录';

  @override
  String get attNoAttendanceSubtitle => '请尝试调整筛选条件（日期范围或状态）。';

  @override
  String get attNoMoreItems => '已到列表末尾。';

  @override
  String employeeFallback(String id) {
    return '员工 #$id';
  }

  @override
  String get attDetailsTitle => '考勤详情';

  @override
  String get attEmployeeLabel => '员工';

  @override
  String get attWorkedTimeLabel => '工作时长';

  @override
  String get attExtraHoursLabel => '加班时长';

  @override
  String get attCheckInSection => '签到';

  @override
  String get attCheckOutSection => '签退';

  @override
  String get attIpAddressLabel => 'IP 地址';

  @override
  String get attGpsCoordinatesLabel => 'GPS 坐标';

  @override
  String get attViewOnMaps => '在地图中查看';

  @override
  String get attUnknownValue => '未知';

  @override
  String get attNotAvailableValue => '不可用';

  @override
  String get attNotCheckedOutYet => '尚未签退';

  @override
  String get attZeroHours => '0.00 小时';
}
