// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Filipino Pilipino (`fil`).
class AppLocalizationsFil extends AppLocalizations {
  AppLocalizationsFil([String locale = 'fil']) : super(locale);

  @override
  String get configureOdooServer => 'I-configure ang Odoo Server';

  @override
  String get jobs => 'Mga Trabaho';

  @override
  String get searchJobsHint => 'Maghanap ng mga trabaho...';

  @override
  String get sortBy => 'Ayusin ayon sa';

  @override
  String get sortScheduledNearest => 'Naka-iskedyul (pinakamalapit muna)';

  @override
  String get sortScheduledFarthest => 'Naka-iskedyul (pinakamalayo muna)';

  @override
  String get sortCustomerAZ => 'Kliyente (A-Z)';

  @override
  String get sortStatus => 'Status';

  @override
  String get tabAssigned => 'Naka-assign';

  @override
  String get tabInProgress => 'Isinasagawa';

  @override
  String get tabDone => 'Tapos na';

  @override
  String get tabAll => 'Lahat';

  @override
  String get emptyJobsTitle => 'Walang mga trabaho';

  @override
  String get emptyJobsSubtitle => 'Subukang baguhin ang paghahanap o mga filter';

  @override
  String get emptyJobsAddButton => 'Magdagdag ng bagong trabaho';

  @override
  String get noSchedule => 'Walang iskedyul';

  @override
  String get statusDraft => 'Draft';

  @override
  String get statusAssigned => 'Naka-assign';

  @override
  String get statusInProgress => 'Isinasagawa';

  @override
  String get statusDone => 'Tapos na';

  @override
  String get statusCancelled => 'Kanselado';

  @override
  String get settingsTitle => 'Mga setting ng app';

  @override
  String get settingsAppearance => 'Hitsura';

  @override
  String get settingsTheme => 'Tema';

  @override
  String get settingsThemeLight => 'Maliwanag';

  @override
  String get settingsThemeDark => 'Madilim';

  @override
  String get settingsThemeSystem => 'Sistema';

  @override
  String get settingsAccentColor => 'Accent na kulay';

  @override
  String get settingsAccentColorPick => 'Pumili ng kulay';

  @override
  String get settingsAccentColorDialogTitle => 'Pumili ng kulay';

  @override
  String get settingsLanguageSection => 'Wika at teksto';

  @override
  String get settingsLanguageLabel => 'Wika';

  @override
  String get settingsAboutSection => 'Tungkol sa app';

  @override
  String get settingsVersionLabel => 'Bersyon';

  @override
  String get languageEnglish => 'Ingles';

  @override
  String get languageArabic => 'Arabe';

  @override
  String get navJobs => 'Mga Trabaho';

  @override
  String get navCalendar => 'Kalendaryo';

  @override
  String get navMap => 'Mapa';

  @override
  String get navProfile => 'Profile';

  @override
  String get profileSectionSettingsAndMore => 'Mga setting at iba pa';

  @override
  String get profileSettingsTitle => 'Mga setting';

  @override
  String get profileSettingsSubtitle => 'Mga setting ng app at tema';

  @override
  String get profileLogoutTitle => 'Mag-logout';

  @override
  String get profileLogoutSubtitle => 'Lumabas sa iyong account';

  @override
  String get profileLoggedIn => 'Naka-login';

  @override
  String get jobDetailSchedule => 'Iskedyul';

  @override
  String get jobDetailStart => 'Simula';

  @override
  String get jobDetailEnd => 'Wakas';

  @override
  String get jobDetailDuration => 'Tagal';

  @override
  String get jobDetailLocation => 'Lokasyon';

  @override
  String get jobDetailLatShort => 'Lat';

  @override
  String get jobDetailLngShort => 'Lng';

  @override
  String get jobDetailOpenInMaps => 'Buksan sa Maps';

  @override
  String get jobDetailNotes => 'Mga tala';

  @override
  String get jobDetailCustomerNotes => 'Mga tala ng kliyente';

  @override
  String get jobDetailInternalNotes => 'Panloob na mga tala';

  @override
  String get jobDetailPhotos => 'Mga larawan';

  @override
  String get jobDetailAddPhotos => 'Magdagdag ng mga larawan';

  @override
  String get jobDetailPhotosHint => 'I-tap ang kahit saang bahagi ng card na ito o gamitin ang button para magdagdag ng larawan mula sa camera o gallery.';

  @override
  String get jobDetailTakePhotoCamera => 'Kumuha ng larawan (camera)';

  @override
  String get jobDetailChooseFromGallery => 'Pumili mula sa gallery';

  @override
  String get jobDetailAuth => 'Pagpapatunay';

  @override
  String get jobDetailAuthTooltip => 'Buksan ang pagpapatunay';

  @override
  String get jobDetailAuthHint => 'I-tap ang card na ito para kunin ang pagpapatunay ng kliyente (pirma).';

  @override
  String get jobDetailAuthSavedSignature => 'Naka-save na pirma';

  @override
  String get jobDetailNoCustomer => 'Walang kliyente';

  @override
  String get jobDetailUnassigned => 'Hindi naka-assign';

  @override
  String get jobDetailStartButton => 'Simulan';

  @override
  String get jobDetailMarkDone => 'Markahan bilang tapos na';

  @override
  String get jobDetailAssign => 'I-assign';

  @override
  String get jobDetailUpdateFailed => 'Nabigong i-update ang trabaho';

  @override
  String get locationServicesDisabled => 'Hindi naka-on ang mga serbisyo ng lokasyon';

  @override
  String get locationPermissionDenied => 'Tinanggihan ang pahintulot sa lokasyon';

  @override
  String get jobDetailStartFailed => 'Nabigong simulan ang trabaho';

  @override
  String get jobDetailNoLocationData => 'Walang GPS o address na available para sa trabahong ito';

  @override
  String get jobDetailNoAddress => 'Walang address na available para sa trabahong ito';

  @override
  String get jobDetailMapOpenFailed => 'Hindi mabuksan ang app ng mapa';

  @override
  String get jobDetailMapError => 'Nabigong buksan ang mapa';

  @override
  String get jobDetailPhotosUploaded => 'nai-upload na larawan';

  @override
  String get jobDetailPhotosUploadFailed => 'Nabigong i-upload ang mga larawan';

  @override
  String get authSaved => 'Na-save ang pagpapatunay';

  @override
  String get authSaveFailed => 'Nabigong i-save ang pirma';

  @override
  String get authSignInstruction => 'Hilingin sa kliyente na pumirma sa loob ng kahon sa ibaba.';

  @override
  String get photoViewerTitle => 'Larawan';

  @override
  String get commonRefresh => 'I-refresh';

  @override
  String get commonClear => 'I-clear';

  @override
  String get commonCancel => 'Kanselahin';

  @override
  String get commonSave => 'I-save';

  @override
  String get addJobTitle => 'Bagong trabaho';

  @override
  String get addJobJobTitleLabel => 'Pamagat ng trabaho';

  @override
  String get addJobJobTitleHint => 'Hal.: AC Maintenance – Villa 12B';

  @override
  String get addJobJobTitleRequired => 'Pakilagay ang pamagat ng trabaho';

  @override
  String get addJobScheduledLabel => 'Naka-iskedyul na petsa at oras';

  @override
  String get addJobDateTimeNotSet => 'Hindi nakatakda';

  @override
  String get addJobCustomerNotesLabel => 'Mga tala ng kliyente (opsyonal)';

  @override
  String get addJobCustomerNotesHint => 'Mga tala mula sa kliyente, access info, atbp.';

  @override
  String get addJobInternalNotesLabel => 'Panloob na mga tala (opsyonal)';

  @override
  String get addJobInternalNotesHint => 'Mga tala para sa iyong team lamang';

  @override
  String get addJobCreateButton => 'Gumawa ng trabaho';

  @override
  String get addJobCreated => 'Nagawa ang trabaho';

  @override
  String get addJobCreateFailed => 'Nabigong gumawa ng trabaho';

  @override
  String get calendarRefreshTooltip => 'I-refresh ang mga trabaho';

  @override
  String get calendarJobsOnPrefix => 'Mga trabaho noong';

  @override
  String get calendarNoJobsOnDay => 'Walang mga trabaho sa araw na ito';

  @override
  String get mapTitle => 'Mapa ng mga trabaho';

  @override
  String get mapEmptyTitle => 'Walang mga trabaho na ipapakita sa mapa';

  @override
  String get mapBottomTitle => 'Mga trabaho sa mapa';

  @override
  String get mapJobsLabel => 'mga trabaho';

  @override
  String get myJobsTitle => 'Aking mga trabaho';

  @override
  String get mapYouAreHere => 'Nandito ka';

  @override
  String get loginWelcomeBack => 'Maligayang pagbabalik';

  @override
  String get loginSubtitle => 'Mag-sign in upang pamahalaan ang iyong mga field service na trabaho.';

  @override
  String get loginDetailsTitle => 'Mga detalye sa pag-login';

  @override
  String get loginEmailLabel => 'Email / Login';

  @override
  String get loginPasswordLabel => 'Password';

  @override
  String get loginButton => 'Mag-login';

  @override
  String get loginError => 'Nabigong mag-login. Suriin ang kredensyal at server.';

  @override
  String get validationRequired => 'Kailangan';

  @override
  String get loginConnectedServer => 'Nakakonektang server';

  @override
  String get loginNoServerConfigured => 'Wala pang nakaka-configure na server';

  @override
  String loginServerDb(String dbName) {
    return 'DB: $dbName';
  }

  @override
  String get loginServerDbEmpty => 'DB: -';

  @override
  String get loginChangeServer => 'Baguhin ang server';

  @override
  String get loginPoweredBy => 'Pinapagana ng Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Sabihin sa app kung aling Odoo server at database ang gagamitin.';

  @override
  String get serverConfigSectionConnectionDetails => 'Mga detalye ng koneksyon';

  @override
  String get serverConfigServerUrlLabel => 'URL ng server';

  @override
  String get serverConfigServerUrlHint => 'https://your-odoo-domain.com';

  @override
  String get serverConfigDbNameLabel => 'Pangalan ng database';

  @override
  String get serverConfigSaveButton => 'I-save at magpatuloy';

  @override
  String get serverConfigSaveHint => 'Maaari mo itong baguhin anumang oras mula sa login screen.';

  @override
  String get serverConfigDbAutoDetectError => 'Hindi ma-auto-detect ang database. Pakisuri ang URL.';

  @override
  String get attendanceDetailsTitle => 'Detalye ng Attendance';

  @override
  String get employeeLabel => 'Empleyado';

  @override
  String get statusOpen => 'BUKAS';

  @override
  String get statusClosed => 'SARADO';

  @override
  String get workedTimeLabel => 'Oras na Nagtrabaho';

  @override
  String get extraHoursLabel => 'Dagdag na Oras';

  @override
  String get checkInTitle => 'CHECK IN';

  @override
  String get checkOutTitle => 'CHECK OUT';

  @override
  String get ipAddressLabel => 'IP Address';

  @override
  String get gpsCoordinatesLabel => 'GPS Coordinates';

  @override
  String get unknownValue => 'Hindi alam';

  @override
  String get notAvailableValue => 'Hindi available';

  @override
  String get viewOnMaps => 'Tingnan sa Maps';

  @override
  String get notCheckedOutYet => 'Hindi pa naka-check out';

  @override
  String hoursValue(String hours) {
    return '$hours oras';
  }

  @override
  String get attendanceOnDuty => 'Naka-duty';

  @override
  String get attendanceOffDuty => 'Off duty';

  @override
  String get attendanceSwipeToCheckIn => 'I-swipe para mag-check in';

  @override
  String get attendanceSwipeToCheckOut => 'I-swipe para mag-check out';

  @override
  String get attendanceCurrentLocation => 'Kasalukuyang Lokasyon';

  @override
  String get attendanceRefresh => 'I-REFRESH';

  @override
  String get attendanceFetchingAddress => 'Kinukuha ang address...';

  @override
  String get attendanceWaitingForGps => 'Naghihintay ng GPS...';

  @override
  String get attendanceUploadSelfie => 'Mag-upload ng selfie';

  @override
  String get attendanceLocationRequired => 'Kailangan ang lokasyon para magpatuloy.';

  @override
  String get attendanceCheckInSuccess => 'Welcome! Na-record ang check-in.';

  @override
  String get attendanceCheckOutSuccess => 'Tapos na ang shift. Good job!';

  @override
  String get attendanceCheckInFirst => 'Mag-check in muna.';

  @override
  String get attendanceSelfieUploaded => 'Na-upload ang selfie';

  @override
  String get attendanceUploadFailed => 'Nabigo ang pag-upload';

  @override
  String get attendanceCameraError => 'Error sa camera';

  @override
  String attendanceStartedAt(String time) {
    return 'Nagsimula ng $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Lat: $lat, Lng: $lng';
  }

  @override
  String get attendanceReadyToStart => 'Handa nang magsimula ng shift';

  @override
  String get attendanceTitle => 'Attendance';

  @override
  String get attNavAttendance => 'Pagpasok';

  @override
  String get attNavHistory => 'Kasaysayan';

  @override
  String get attFiltersTitle => 'Mga Filter ng Attendance';

  @override
  String get attDateRangeLabel => 'Saklaw ng Petsa';

  @override
  String get attStatusLabel => 'Status';

  @override
  String get attFilterTooltip => 'Filter';

  @override
  String get attClearFilters => 'I-clear ang Filters';

  @override
  String get attApplyFilters => 'I-apply ang Filters';

  @override
  String get attFilterStatusAll => 'Lahat ng status';

  @override
  String get attFilterStatusOpen => 'Bukas (Naka-check in)';

  @override
  String get attFilterStatusClosed => 'Sarado (Naka-check out)';

  @override
  String get attFilterRangeToday => 'Ngayon';

  @override
  String get attFilterRangeWeek => 'Ngayong linggo';

  @override
  String get attFilterRangeMonth => 'Ngayong buwan';

  @override
  String get attFilterRangeAll => 'Lahat ng oras';

  @override
  String attFilterDescription(String status, String range) {
    return '$status para sa $range';
  }

  @override
  String get attLoadingAttendance => 'Nilo-load ang attendance…';

  @override
  String get attLoadingMore => 'Nilo-load pa…';

  @override
  String get attFailedToLoad => 'Hindi ma-load ang attendance';

  @override
  String get attFailedToLoadMore => 'Hindi ma-load pa';

  @override
  String get attTryAgain => 'Subukan ulit';

  @override
  String get attNoAttendanceTitle => 'Walang nahanap na attendance';

  @override
  String get attNoAttendanceSubtitle => 'Subukang ayusin ang filters (saklaw ng petsa o status).';

  @override
  String get attNoMoreItems => 'Naabot mo na ang dulo ng listahan.';

  @override
  String employeeFallback(String id) {
    return 'Employee #$id';
  }

  @override
  String get attDetailsTitle => 'Detalye ng Attendance';

  @override
  String get attEmployeeLabel => 'Empleyado';

  @override
  String get attWorkedTimeLabel => 'Oras na Nagtrabaho';

  @override
  String get attExtraHoursLabel => 'Dagdag na Oras';

  @override
  String get attCheckInSection => 'CHECK IN';

  @override
  String get attCheckOutSection => 'CHECK OUT';

  @override
  String get attIpAddressLabel => 'IP Address';

  @override
  String get attGpsCoordinatesLabel => 'GPS Coordinates';

  @override
  String get attViewOnMaps => 'Tingnan sa Maps';

  @override
  String get attUnknownValue => 'Hindi alam';

  @override
  String get attNotAvailableValue => 'Hindi available';

  @override
  String get attNotCheckedOutYet => 'Hindi pa naka-check out';

  @override
  String get attZeroHours => '0.00 oras';
}
