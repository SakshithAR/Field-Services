// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get configureOdooServer => 'Configurer le serveur Odoo';

  @override
  String get jobs => 'Interventions';

  @override
  String get searchJobsHint => 'Rechercher des interventions...';

  @override
  String get sortBy => 'Trier par';

  @override
  String get sortScheduledNearest => 'Planifiées (les plus proches d\'abord)';

  @override
  String get sortScheduledFarthest => 'Planifiées (les plus éloignées d\'abord)';

  @override
  String get sortCustomerAZ => 'Client (A-Z)';

  @override
  String get sortStatus => 'Statut';

  @override
  String get tabAssigned => 'Affectées';

  @override
  String get tabInProgress => 'En cours';

  @override
  String get tabDone => 'Terminées';

  @override
  String get tabAll => 'Toutes';

  @override
  String get emptyJobsTitle => 'Aucune intervention';

  @override
  String get emptyJobsSubtitle => 'Essayez de modifier la recherche ou les filtres';

  @override
  String get emptyJobsAddButton => 'Ajouter une nouvelle intervention';

  @override
  String get noSchedule => 'Aucune planification';

  @override
  String get statusDraft => 'Brouillon';

  @override
  String get statusAssigned => 'Affectée';

  @override
  String get statusInProgress => 'En cours';

  @override
  String get statusDone => 'Terminée';

  @override
  String get statusCancelled => 'Annulée';

  @override
  String get settingsTitle => 'Paramètres de l\'application';

  @override
  String get settingsAppearance => 'Apparence';

  @override
  String get settingsTheme => 'Thème';

  @override
  String get settingsThemeLight => 'Clair';

  @override
  String get settingsThemeDark => 'Sombre';

  @override
  String get settingsThemeSystem => 'Système';

  @override
  String get settingsAccentColor => 'Couleur d\'accentuation';

  @override
  String get settingsAccentColorPick => 'Choisir une couleur';

  @override
  String get settingsAccentColorDialogTitle => 'Choisissez une couleur';

  @override
  String get settingsLanguageSection => 'Langue et texte';

  @override
  String get settingsLanguageLabel => 'Langue';

  @override
  String get settingsAboutSection => 'À propos de l\'application';

  @override
  String get settingsVersionLabel => 'Version';

  @override
  String get languageEnglish => 'Anglais';

  @override
  String get languageArabic => 'Arabe';

  @override
  String get navJobs => 'Interventions';

  @override
  String get navCalendar => 'Calendrier';

  @override
  String get navMap => 'Carte';

  @override
  String get navProfile => 'Profil';

  @override
  String get profileSectionSettingsAndMore => 'Paramètres et plus';

  @override
  String get profileSettingsTitle => 'Paramètres';

  @override
  String get profileSettingsSubtitle => 'Paramètres de l\'application et du thème';

  @override
  String get profileLogoutTitle => 'Déconnexion';

  @override
  String get profileLogoutSubtitle => 'Se déconnecter de votre compte';

  @override
  String get profileLoggedIn => 'Connecté';

  @override
  String get jobDetailSchedule => 'Planification';

  @override
  String get jobDetailStart => 'Début';

  @override
  String get jobDetailEnd => 'Fin';

  @override
  String get jobDetailDuration => 'Durée';

  @override
  String get jobDetailLocation => 'Emplacement';

  @override
  String get jobDetailLatShort => 'Lat.';

  @override
  String get jobDetailLngShort => 'Long.';

  @override
  String get jobDetailOpenInMaps => 'Ouvrir dans Maps';

  @override
  String get jobDetailNotes => 'Notes';

  @override
  String get jobDetailCustomerNotes => 'Notes client';

  @override
  String get jobDetailInternalNotes => 'Notes internes';

  @override
  String get jobDetailPhotos => 'Photos';

  @override
  String get jobDetailAddPhotos => 'Ajouter des photos';

  @override
  String get jobDetailPhotosHint => 'Touchez n\'importe où sur cette carte ou utilisez le bouton pour ajouter des photos depuis la caméra ou la galerie.';

  @override
  String get jobDetailTakePhotoCamera => 'Prendre une photo (caméra)';

  @override
  String get jobDetailChooseFromGallery => 'Choisir depuis la galerie';

  @override
  String get jobDetailAuth => 'Authentification';

  @override
  String get jobDetailAuthTooltip => 'Ouvrir l\'écran d\'authentification';

  @override
  String get jobDetailAuthHint => 'Touchez cette carte pour capturer l\'authentification du client (signature).';

  @override
  String get jobDetailAuthSavedSignature => 'Signature enregistrée';

  @override
  String get jobDetailNoCustomer => 'Aucun client';

  @override
  String get jobDetailUnassigned => 'Non affectée';

  @override
  String get jobDetailStartButton => 'Démarrer';

  @override
  String get jobDetailMarkDone => 'Marquer comme terminée';

  @override
  String get jobDetailAssign => 'Affecter';

  @override
  String get jobDetailUpdateFailed => 'Échec de la mise à jour de l\'intervention';

  @override
  String get locationServicesDisabled => 'Les services de localisation sont désactivés';

  @override
  String get locationPermissionDenied => 'Autorisation de localisation refusée';

  @override
  String get jobDetailStartFailed => 'Échec du démarrage de l\'intervention';

  @override
  String get jobDetailNoLocationData => 'Aucune coordonnée GPS ou adresse disponible pour cette intervention';

  @override
  String get jobDetailNoAddress => 'Aucune adresse disponible pour cette intervention';

  @override
  String get jobDetailMapOpenFailed => 'Impossible d\'ouvrir l\'application de cartes';

  @override
  String get jobDetailMapError => 'Échec de l\'ouverture des cartes';

  @override
  String get jobDetailPhotosUploaded => 'photo(s) téléversée(s)';

  @override
  String get jobDetailPhotosUploadFailed => 'Échec du téléversement des photos';

  @override
  String get authSaved => 'Authentification enregistrée';

  @override
  String get authSaveFailed => 'Échec de l\'enregistrement de la signature';

  @override
  String get authSignInstruction => 'Demandez au client de signer dans le cadre ci-dessous.';

  @override
  String get photoViewerTitle => 'Photo';

  @override
  String get commonRefresh => 'Actualiser';

  @override
  String get commonClear => 'Effacer';

  @override
  String get commonCancel => 'Annuler';

  @override
  String get commonSave => 'Enregistrer';

  @override
  String get addJobTitle => 'Nouvelle intervention';

  @override
  String get addJobJobTitleLabel => 'Titre de l\'intervention';

  @override
  String get addJobJobTitleHint => 'Ex. : Maintenance de climatiseur – Villa 12B';

  @override
  String get addJobJobTitleRequired => 'Veuillez saisir le titre de l\'intervention';

  @override
  String get addJobScheduledLabel => 'Date et heure planifiées';

  @override
  String get addJobDateTimeNotSet => 'Non défini';

  @override
  String get addJobCustomerNotesLabel => 'Notes client (facultatif)';

  @override
  String get addJobCustomerNotesHint => 'Notes du client, informations d\'accès, etc.';

  @override
  String get addJobInternalNotesLabel => 'Notes internes (facultatif)';

  @override
  String get addJobInternalNotesHint => 'Notes pour votre équipe uniquement';

  @override
  String get addJobCreateButton => 'Créer l\'intervention';

  @override
  String get addJobCreated => 'Intervention créée';

  @override
  String get addJobCreateFailed => 'Échec de la création de l\'intervention';

  @override
  String get calendarRefreshTooltip => 'Actualiser les interventions';

  @override
  String get calendarJobsOnPrefix => 'Interventions le';

  @override
  String get calendarNoJobsOnDay => 'Aucune intervention ce jour-là';

  @override
  String get mapTitle => 'Carte des interventions';

  @override
  String get mapEmptyTitle => 'Aucune intervention à afficher sur la carte';

  @override
  String get mapBottomTitle => 'Interventions sur la carte';

  @override
  String get mapJobsLabel => 'interventions';

  @override
  String get myJobsTitle => 'Mes interventions';

  @override
  String get mapYouAreHere => 'Vous êtes ici';

  @override
  String get loginWelcomeBack => 'Bienvenue';

  @override
  String get loginSubtitle => 'Connectez-vous pour gérer vos interventions de service sur site.';

  @override
  String get loginDetailsTitle => 'Informations de connexion';

  @override
  String get loginEmailLabel => 'E-mail / Identifiant';

  @override
  String get loginPasswordLabel => 'Mot de passe';

  @override
  String get loginButton => 'Se connecter';

  @override
  String get loginError => 'Échec de la connexion. Vérifiez vos identifiants et le serveur.';

  @override
  String get validationRequired => 'Obligatoire';

  @override
  String get loginConnectedServer => 'Serveur connecté';

  @override
  String get loginNoServerConfigured => 'Aucun serveur configuré pour le moment';

  @override
  String loginServerDb(String dbName) {
    return 'BD : $dbName';
  }

  @override
  String get loginServerDbEmpty => 'BD : -';

  @override
  String get loginChangeServer => 'Changer de serveur';

  @override
  String get loginPoweredBy => 'Propulsé par Taqnix Field Service';

  @override
  String get serverConfigSubtitle => 'Indiquez à l\'application quel serveur Odoo et quelle base de données utiliser.';

  @override
  String get serverConfigSectionConnectionDetails => 'Détails de connexion';

  @override
  String get serverConfigServerUrlLabel => 'URL du serveur';

  @override
  String get serverConfigServerUrlHint => 'https://your-odoo-domain.com';

  @override
  String get serverConfigDbNameLabel => 'Nom de la base de données';

  @override
  String get serverConfigSaveButton => 'Enregistrer et continuer';

  @override
  String get serverConfigSaveHint => 'Vous pourrez toujours modifier ceci plus tard depuis l\'écran de connexion.';

  @override
  String get serverConfigDbAutoDetectError => 'Impossible de détecter la base de données automatiquement. Veuillez vérifier l\'URL.';

  @override
  String get attendanceDetailsTitle => 'Détails de présence';

  @override
  String get employeeLabel => 'Employé';

  @override
  String get statusOpen => 'OUVERT';

  @override
  String get statusClosed => 'FERMÉ';

  @override
  String get workedTimeLabel => 'Temps travaillé';

  @override
  String get extraHoursLabel => 'Heures supplémentaires';

  @override
  String get checkInTitle => 'ENTRÉE';

  @override
  String get checkOutTitle => 'SORTIE';

  @override
  String get ipAddressLabel => 'Adresse IP';

  @override
  String get gpsCoordinatesLabel => 'Coordonnées GPS';

  @override
  String get unknownValue => 'Inconnu';

  @override
  String get notAvailableValue => 'Non disponible';

  @override
  String get viewOnMaps => 'Voir sur Maps';

  @override
  String get notCheckedOutYet => 'Pas encore pointé la sortie';

  @override
  String hoursValue(String hours) {
    return '$hours h';
  }

  @override
  String get attendanceOnDuty => 'En service';

  @override
  String get attendanceOffDuty => 'Hors service';

  @override
  String get attendanceSwipeToCheckIn => 'Glisser pour pointer l’entrée';

  @override
  String get attendanceSwipeToCheckOut => 'Glisser pour pointer la sortie';

  @override
  String get attendanceCurrentLocation => 'Position actuelle';

  @override
  String get attendanceRefresh => 'ACTUALISER';

  @override
  String get attendanceFetchingAddress => 'Récupération de l’adresse...';

  @override
  String get attendanceWaitingForGps => 'En attente du GPS...';

  @override
  String get attendanceUploadSelfie => 'Téléverser un selfie';

  @override
  String get attendanceLocationRequired => 'La localisation est requise pour continuer.';

  @override
  String get attendanceCheckInSuccess => 'Bienvenue ! Entrée enregistrée.';

  @override
  String get attendanceCheckOutSuccess => 'Fin de service. Bon travail !';

  @override
  String get attendanceCheckInFirst => 'Veuillez d’abord pointer l’entrée.';

  @override
  String get attendanceSelfieUploaded => 'Selfie téléversé';

  @override
  String get attendanceUploadFailed => 'Échec du téléversement';

  @override
  String get attendanceCameraError => 'Erreur de caméra';

  @override
  String attendanceStartedAt(String time) {
    return 'Commencé à $time';
  }

  @override
  String attendanceLatLng(String lat, String lng) {
    return 'Lat : $lat, Lng : $lng';
  }

  @override
  String get attendanceReadyToStart => 'Prêt à commencer le service';

  @override
  String get attendanceTitle => 'Présence';

  @override
  String get attNavAttendance => 'Présence';

  @override
  String get attNavHistory => 'Historique';

  @override
  String get attFiltersTitle => 'Filtres de présence';

  @override
  String get attDateRangeLabel => 'Plage de dates';

  @override
  String get attStatusLabel => 'Statut';

  @override
  String get attFilterTooltip => 'Filtrer';

  @override
  String get attClearFilters => 'Effacer les filtres';

  @override
  String get attApplyFilters => 'Appliquer';

  @override
  String get attFilterStatusAll => 'Tous les statuts';

  @override
  String get attFilterStatusOpen => 'Ouvert (Entrée)';

  @override
  String get attFilterStatusClosed => 'Fermé (Sortie)';

  @override
  String get attFilterRangeToday => 'Aujourd’hui';

  @override
  String get attFilterRangeWeek => 'Cette semaine';

  @override
  String get attFilterRangeMonth => 'Ce mois-ci';

  @override
  String get attFilterRangeAll => 'Tout le temps';

  @override
  String attFilterDescription(String status, String range) {
    return '$status pour $range';
  }

  @override
  String get attLoadingAttendance => 'Chargement de la présence…';

  @override
  String get attLoadingMore => 'Chargement…';

  @override
  String get attFailedToLoad => 'Impossible de charger la présence';

  @override
  String get attFailedToLoadMore => 'Impossible de charger plus';

  @override
  String get attTryAgain => 'Réessayer';

  @override
  String get attNoAttendanceTitle => 'Aucune présence trouvée';

  @override
  String get attNoAttendanceSubtitle => 'Essayez de modifier vos filtres (dates ou statut).';

  @override
  String get attNoMoreItems => 'Vous avez atteint la fin de la liste.';

  @override
  String employeeFallback(String id) {
    return 'Employé #$id';
  }

  @override
  String get attDetailsTitle => 'Détails de présence';

  @override
  String get attEmployeeLabel => 'Employé';

  @override
  String get attWorkedTimeLabel => 'Temps travaillé';

  @override
  String get attExtraHoursLabel => 'Heures supplémentaires';

  @override
  String get attCheckInSection => 'ENTRÉE';

  @override
  String get attCheckOutSection => 'SORTIE';

  @override
  String get attIpAddressLabel => 'Adresse IP';

  @override
  String get attGpsCoordinatesLabel => 'Coordonnées GPS';

  @override
  String get attViewOnMaps => 'Voir sur Maps';

  @override
  String get attUnknownValue => 'Inconnu';

  @override
  String get attNotAvailableValue => 'Non disponible';

  @override
  String get attNotCheckedOutYet => 'Pas encore pointé en sortie';

  @override
  String get attZeroHours => '0.00 h';
}
