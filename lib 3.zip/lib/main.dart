import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:hive_flutter/hive_flutter.dart';

// Firebase
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

// App
import 'package:field_service/src/config/app_theme.dart';
import 'package:field_service/l10n/app_localizations.dart';
import 'package:field_service/odoo_kv_hive_impl.dart';
import 'package:field_service/src/controllers/settings_controller.dart';
import 'package:field_service/src/features/pages/auth/login_page.dart';
import 'package:field_service/src/features/pages/auth/server_config_screen.dart';
import 'package:field_service/src/odoo/network_connectivity.dart';

// ✅ Bottom nav home
import 'package:field_service/src/features/shell/home_shell.dart';

// Odoo
import 'package:field_service/src/odoo/odoo_repository/lib/odoo_repository.dart';
import 'package:odoo_rpc/odoo_rpc.dart';

// Controllers
import 'src/config/app_config.dart';
import 'src/controllers/auth_controller.dart';

/// ---------- GLOBAL NAVIGATOR KEY ----------
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

/// ✅ Single source of truth for session key (use AppConfig)
String get _sessionKey => AppConfig.instance.cacheSessionKey;

/// ---------- FCM BACKGROUND HANDLER ----------
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  try {
    await Firebase.initializeApp();
  } catch (_) {}
}

/// ---------- NOTIFICATION SERVICE ----------
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;

    try {
      await Firebase.initializeApp();
    } catch (_) {}

    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );

    final token = await FirebaseMessaging.instance.getToken();
    if (kDebugMode) debugPrint('🔐 [FieldService] FCM TOKEN: $token');

    FirebaseMessaging.instance.onTokenRefresh.listen((newToken) {
      if (kDebugMode) debugPrint('🔁 [FieldService] FCM token refreshed: $newToken');
    });

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      final ctx = navigatorKey.currentContext;
      final title = message.notification?.title ?? 'Notification';
      final body = message.notification?.body ?? '';
      if (ctx != null && body.isNotEmpty) {
        ScaffoldMessenger.of(ctx).showSnackBar(
          SnackBar(
            content: Text('$title\n$body'),
            duration: const Duration(seconds: 4),
          ),
        );
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      if (kDebugMode) debugPrint('📨 Notification opened app: ${message.data}');
    });

    final initialMsg = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMsg != null && kDebugMode) {
      debugPrint('🚀 Opened from terminated via notification: ${initialMsg.data}');
    }

    _initialized = true;
  }

  Future<void> requestPermissionsIfNeeded() async {
    final prefs = await SharedPreferences.getInstance();
    const askedKey = 'notif_permission_asked';
    if (prefs.getBool(askedKey) == true) return;

    try {
      await FirebaseMessaging.instance.requestPermission(alert: true, badge: true, sound: true);
    } catch (_) {}

    if (Platform.isAndroid) {
      final status = await Permission.notification.status;
      if (!status.isGranted) await Permission.notification.request();
    }

    await prefs.setBool(askedKey, true);
  }
}

/// Gate widget: after first frame, ask for notification permission once
class NotificationPermissionGate extends StatefulWidget {
  final Widget child;
  const NotificationPermissionGate({super.key, required this.child});

  @override
  State<NotificationPermissionGate> createState() => _NotificationPermissionGateState();
}

class _NotificationPermissionGateState extends State<NotificationPermissionGate> {
  bool _asked = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (_asked) return;
      _asked = true;
      await NotificationService.instance.requestPermissionsIfNeeded();
    });
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

/// ---------- MAIN ----------
Future<void> main() async {
  final widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);

  try {
    await Hive.initFlutter();
    await AppConfig.instance.init();

    final settings = SettingsController();
    await settings.init();

    final cache = OdooKvHive();
    await cache.init();

    try {
      await NotificationService.instance.init();
    } catch (e) {
      debugPrint("⚠️ Firebase init failed: $e");
    }

    runApp(FieldServiceRoot(settings: settings, cache: cache));
  } catch (e, stack) {
    debugPrint("🔥 FATAL ERROR IN MAIN: $e\n$stack");
  } finally {
    FlutterNativeSplash.remove();
  }
}

/// ✅ Root Switcher Widget
class FieldServiceRoot extends StatefulWidget {
  final SettingsController settings;
  final OdooKvHive cache;

  const FieldServiceRoot({
    super.key,
    required this.settings,
    required this.cache,
  });

  @override
  State<FieldServiceRoot> createState() => _FieldServiceRootState();
}

class _FieldServiceRootState extends State<FieldServiceRoot> {
  late bool _isConfigured;

  @override
  void initState() {
    super.initState();
    _isConfigured = AppConfig.instance.isConfigured;
  }

  void _onConfigured() => setState(() => _isConfigured = true);

  @override
  Widget build(BuildContext context) {
    if (!_isConfigured) {
      return ServerConfigApp(
        settings: widget.settings,
        onConfigSuccess: _onConfigured,
      );
    }
    return MainOdooApp(settings: widget.settings, cache: widget.cache);
  }
}

/// App that shows only the "Configure Server" screen.
class ServerConfigApp extends StatelessWidget {
  final SettingsController settings;
  final VoidCallback onConfigSuccess;

  const ServerConfigApp({
    super.key,
    required this.settings,
    required this.onConfigSuccess,
  });

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<SettingsController>.value(value: settings),
        Provider<AppConfig>.value(value: AppConfig.instance),
      ],
      child: Consumer<SettingsController>(
        builder: (context, settings, _) {
          final s = settings.state;
          final seed = _parseHex(s.seedColorHex);

          return MaterialApp(
            title: 'Field Service – Server Setup',
            debugShowCheckedModeBanner: false,
            localizationsDelegates: const [
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            supportedLocales: AppLocalizations.supportedLocales,
            locale: _localeFromCode(s.localeCode),
            themeMode: s.themeMode,
            theme: ThemeData(colorSchemeSeed: seed, brightness: Brightness.light, useMaterial3: true),
            darkTheme: ThemeData(colorSchemeSeed: seed, brightness: Brightness.dark, useMaterial3: true),
            home: ServerConfigScreen(onConfigured: onConfigSuccess),
          );
        },
      ),
    );
  }
}

/// The main Odoo app – only used AFTER URL/DB are configured.
class MainOdooApp extends StatefulWidget {
  final SettingsController settings;
  final OdooKvHive cache;

  const MainOdooApp({
    super.key,
    required this.settings,
    required this.cache,
  });

  static void rebuild(BuildContext context) {
    context.findAncestorStateOfType<_MainOdooAppState>()?.rebuild();
  }

  @override
  State<MainOdooApp> createState() => _MainOdooAppState();
}

class _MainOdooAppState extends State<MainOdooApp> {
  Key _providerKey = UniqueKey();

  void rebuild() {
    setState(() {
      _providerKey = UniqueKey();
      debugPrint("🔄 MainOdooApp: Re-initializing Odoo Client & Providers...");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      key: _providerKey,
      child: Builder(
        builder: (_) {
          final cfg = AppConfig.instance;

          // ✅ FIX: restore session using SAME KEY used by AuthController
          final prevSession = widget.cache.get(_sessionKey, defaultValue: null) as OdooSession?;
          final sessionForClient = (prevSession?.id.toString().isEmpty ?? true) ? null : prevSession;

          if (kDebugMode) {
            debugPrint("🔌 Initializing Client with Session: ${sessionForClient?.id}");
          }

          final client = OdooClient(cfg.baseUrl, sessionId: sessionForClient);

          final netConn = NetworkConnectivity();
          final env = OdooEnvironment(client, cfg.dbName, widget.cache, netConn);

          return MultiProvider(
            providers: [
              Provider<AppConfig>.value(value: cfg),
              Provider<OdooEnvironment>.value(value: env),

              // ✅ Auth provider - use SAME _sessionKey
              ChangeNotifierProvider<AuthController>(
                create: (_) => AuthController(env, _sessionKey)..init(),
              ),

              ChangeNotifierProvider<SettingsController>.value(value: widget.settings),
            ],
            child: Consumer<SettingsController>(
              builder: (context, settings, _) {
                final s = settings.state;
                final seed = _parseHex(s.seedColorHex);

                return MaterialApp(
                  navigatorKey: navigatorKey,
                  localizationsDelegates: const [
                    AppLocalizations.delegate,
                    GlobalMaterialLocalizations.delegate,
                    GlobalWidgetsLocalizations.delegate,
                    GlobalCupertinoLocalizations.delegate,
                  ],
                  supportedLocales: AppLocalizations.supportedLocales,
                  locale: _localeFromCode(s.localeCode),
                  title: 'Field Service',
                  debugShowCheckedModeBanner: false,
                  themeMode: s.themeMode,
                  theme: AppTheme.light(seed: seed),
                  darkTheme: AppTheme.dark(seed: seed),
                  home: const NotificationPermissionGate(
                    child: _AuthGate(),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

/// ✅ Auth gate decides Login vs Home
class _AuthGate extends StatelessWidget {
  const _AuthGate();

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();

    if (!auth.initialized) {
      return const _AuthLoadingScreen();
    }

    return auth.isAuthenticated ? const FieldServiceHome() : const LoginPage();
  }
}

class _AuthLoadingScreen extends StatelessWidget {
  const _AuthLoadingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF16568C),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              'assets/images/icon.png',
              fit: BoxFit.contain,
              errorBuilder: (context, error, stack) {
                return const Icon(Icons.error, color: Colors.white, size: 40);
              },
            ),
            const SizedBox(height: 24),
            const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}

// Utility
Locale _localeFromCode(String code) {
  final p = code.split('_');
  if (p.length == 2) return Locale(p[0], p[1]);
  return Locale(p[0]);
}

Color _parseHex(String hex) {
  final h = hex.replaceAll('#', '');
  final v = int.parse('FF$h', radix: 16);
  return Color(v);
}
