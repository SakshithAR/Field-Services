import 'package:field_service/src/attendance/attendance_record.dart';
import 'package:field_service/src/expenses/expense_list/expense_record.dart';
import 'package:field_service/src/features/jobs/job_record.dart';
import 'package:flutter/foundation.dart' hide Category;
import 'package:hive_flutter/hive_flutter.dart';
import 'package:field_service/src/odoo/odoo_repository/lib/odoo_repository.dart';
import 'package:odoo_rpc/odoo_rpc.dart';
import 'package:field_service/src/config/app_config.dart';

typedef SessionChangedCallback = void Function(OdooSession sessionId);

/// ✅ Safe fallback JSON for OdooSession.fromJson()
Map<String, dynamic> _emptySessionJson() => <String, dynamic>{
  // Common
  'id': '',
  'dbName': '',
  'companyId': 0,

  // IMPORTANT: your OdooSession expects List<Company>
  // fromJson will convert [] properly
  'allowedCompanies': <dynamic>[],

  // Odoo session info fields (required in your version)
  'isSystem': false,
  'partnerId': 0,
  'serverVersion': '',
  'userId': 0,
  'userLang': 'en_US',
  'userLogin': '',
  'userName': '',
  'userTz': 'UTC',
};

/// Implements persistent key-value storage for Odoo records and session persistence with Hive
class OdooKvHive implements OdooKv {
  late Box box;

  OdooKvHive();

  @override
  Future<void> init() async {
    // ✅ IMPORTANT: Hive.initFlutter() must be called ONCE in main.dart, NOT here.
    _registerAdaptersOnce();
    box = await _openBoxSafely(hiveBoxName);
  }

  static bool _adaptersRegistered = false;

  void _registerAdaptersOnce() {
    if (_adaptersRegistered) return;
    _adaptersRegistered = true;

    // ✅ Only adapters that are safe/needed
    if (!Hive.isAdapterRegistered(0)) Hive.registerAdapter(OdooSessionAdapter());
    if (!Hive.isAdapterRegistered(2)) Hive.registerAdapter(OdooRpcCallAdapter());
    if (!Hive.isAdapterRegistered(3)) Hive.registerAdapter(OdooIdAdapter());
    if (!Hive.isAdapterRegistered(4)) Hive.registerAdapter(JobRecordAdapter());
    if (!Hive.isAdapterRegistered(5)) Hive.registerAdapter(ExpenseRecordAdapter());
    if (!Hive.isAdapterRegistered(6)) Hive.registerAdapter(AttendanceRecordAdapter());
  }

  Future<Box> _openBoxSafely(String name) async {
    try {
      return await Hive.openBox(name);
    } catch (e, st) {
      debugPrint('Hive openBox failed ($name): $e\n$st');
      // 🔥 if corrupted, recreate
      try {
        await Hive.deleteBoxFromDisk(name);
      } catch (e2) {
        debugPrint('Hive deleteBoxFromDisk failed ($name): $e2');
      }
      return await Hive.openBox(name);
    }
  }

  @override
  Future<void> close() => box.close();

  @override
  dynamic get(dynamic key, {dynamic defaultValue}) =>
      box.get(key, defaultValue: defaultValue);

  @override
  Future<void> put(dynamic key, dynamic value) => box.put(key, value);

  @override
  Future<void> delete(dynamic key) => box.delete(key);

  @override
  Iterable<dynamic> get keys => box.keys;

  /// ✅ Safe session getter for startup (prevents crash/stuck after relaunch)
  OdooSession safeGetSession() {
    try {
      final v = box.get(cacheSessionKey);
      if (v is OdooSession) return v;

      // If stored type is wrong/corrupt
      return OdooSession.fromJson(_emptySessionJson());
    } catch (e, st) {
      debugPrint('safeGetSession failed: $e\n$st');
      try {
        box.delete(cacheSessionKey);
      } catch (_) {}
      return OdooSession.fromJson(_emptySessionJson());
    }
  }
}

/// Callback for session changed events
SessionChangedCallback storeSession(OdooKv cache) {
  void sessionChanged(OdooSession sessionId) {
    // if empty id, delete session
    if ((sessionId.id).toString().isEmpty) {
      cache.delete(cacheSessionKey);
    } else {
      cache.put(cacheSessionKey, sessionId);
    }
  }

  return sessionChanged;
}

/// ✅ Adapter to store and read OdooSession from persistent storage
/// IMPORTANT: Do NOT call OdooSession(...) constructor here.
/// Always use fromJson to avoid required params changes.
class OdooSessionAdapter extends TypeAdapter<OdooSession> {
  @override
  final typeId = 0;

  @override
  OdooSession read(BinaryReader reader) {
    try {
      final raw = reader.read();
      if (raw is Map) {
        return OdooSession.fromJson(Map<String, dynamic>.from(raw));
      }
    } catch (_) {}

    return OdooSession.fromJson(_emptySessionJson());
  }

  @override
  void write(BinaryWriter writer, OdooSession obj) {
    writer.write(obj.toJson());
  }
}

/// Adapter to store and read OdooRpcCall to/from Hive
class OdooRpcCallAdapter extends TypeAdapter<OdooRpcCall> {
  @override
  final typeId = 2;

  @override
  OdooRpcCall read(BinaryReader reader) {
    try {
      final raw = reader.read();
      if (raw is Map) {
        return OdooRpcCall.fromJson(Map<String, dynamic>.from(raw));
      }
    } catch (_) {}
    return OdooRpcCall.fromJson(const <String, dynamic>{});
  }

  @override
  void write(BinaryWriter writer, OdooRpcCall obj) {
    writer.write(obj.toJson());
  }
}

/// Adapter to store and read OdooId to/from Hive
class OdooIdAdapter extends TypeAdapter<OdooId> {
  @override
  final typeId = 3;

  @override
  OdooId read(BinaryReader reader) {
    try {
      final raw = reader.read();
      if (raw is Map) {
        return OdooId.fromJson(Map<String, dynamic>.from(raw));
      }
    } catch (_) {}
    return OdooId.fromJson(const <String, dynamic>{'id': 0});
  }

  @override
  void write(BinaryWriter writer, OdooId obj) {
    writer.write(obj.toJson());
  }
}

class JobRecordAdapter extends TypeAdapter<JobRecord> {
  @override
  final typeId = 4;

  @override
  JobRecord read(BinaryReader reader) {
    try {
      final raw = reader.read();
      if (raw is Map) {
        return JobRecord.fromJson(Map<String, dynamic>.from(raw));
      }
    } catch (_) {}
    return JobRecord.fromJson(<String, dynamic>{'id': 0, 'name': ''});
  }

  @override
  void write(BinaryWriter writer, JobRecord obj) {
    writer.write(obj.toJson());
  }
}

class ExpenseRecordAdapter extends TypeAdapter<ExpenseRecord> {
  @override
  final typeId = 5;

  @override
  ExpenseRecord read(BinaryReader reader) {
    try {
      final raw = reader.read();
      if (raw is Map) {
        return ExpenseRecord.fromJson(Map<String, dynamic>.from(raw));
      }
    } catch (_) {}
    return ExpenseRecord.fromJson(<String, dynamic>{'id': 0});
  }

  @override
  void write(BinaryWriter writer, ExpenseRecord obj) {
    writer.write(obj.toJson());
  }
}

class AttendanceRecordAdapter extends TypeAdapter<AttendanceRecord> {
  @override
  final typeId = 6;

  @override
  AttendanceRecord read(BinaryReader reader) {
    try {
      final raw = reader.read();
      if (raw is Map) {
        return AttendanceRecord.fromJson(Map<String, dynamic>.from(raw));
      }
    } catch (_) {}
    return AttendanceRecord.fromJson(<String, dynamic>{'id': 0});
  }

  @override
  void write(BinaryWriter writer, AttendanceRecord obj) {
    writer.write(obj.toJson());
  }
}
